"""Chat endpoint -- the entry point into the AI agent, nested under a
specific business. This is the web-widget path (owner-authenticated
caller acting on behalf of their business's public chat). Phase 8's
WhatsApp webhook will call AgentService directly with a business_id
resolved from the inbound number instead of going through this
owner-authenticated route.
"""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends

from app.api.deps import OwnedBusinessDep, get_agent_service
from app.schemas.chat_schema import ChatRequest, ChatResponse
from app.services.agent_service import AgentService

router = APIRouter(prefix="/businesses/{business_id}/chat", tags=["chat"])

AgentServiceDep = Annotated[AgentService, Depends(get_agent_service)]


@router.post("", response_model=ChatResponse)
async def send_message(
    business_id: UUID,
    payload: ChatRequest,
    owned_business: OwnedBusinessDep,
    agent_service: AgentServiceDep,
) -> ChatResponse:
    return await agent_service.handle_message(
        business=owned_business,
        external_user_ref=payload.external_user_ref,
        user_message=payload.message,
    )
