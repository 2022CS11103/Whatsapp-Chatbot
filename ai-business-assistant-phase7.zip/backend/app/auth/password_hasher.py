"""Password hashing. Single responsibility: hash and verify only."""

from passlib.context import CryptContext

_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class PasswordHasher:
    @staticmethod
    def hash(plain_password: str) -> str:
        return str(_pwd_context.hash(plain_password))

    @staticmethod
    def verify(plain_password: str, hashed_password: str) -> bool:
        return bool(_pwd_context.verify(plain_password, hashed_password))
