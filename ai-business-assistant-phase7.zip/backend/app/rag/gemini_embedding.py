"""Google Gemini embedding provider using text-embedding-004."""

import google.generativeai as genai

from app.rag.embedding_provider import EmbeddingProvider

_GEMINI_DIMENSION = 768  # text-embedding-004 fixed output dimension


class GeminiEmbeddingProvider(EmbeddingProvider):
    def __init__(self, api_key: str, model: str) -> None:
        genai.configure(api_key=api_key)
        self._model = model
        self._dimension = _GEMINI_DIMENSION

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        # Gemini embedding SDK is synchronous; run in thread pool to
        # avoid blocking the event loop during document ingestion.
        import asyncio

        loop = asyncio.get_event_loop()
        results = await loop.run_in_executor(
            None,
            lambda: [
                genai.embed_content(model=self._model, content=text)["embedding"] for text in texts
            ],
        )
        return results

    @property
    def dimension(self) -> int:
        return self._dimension
