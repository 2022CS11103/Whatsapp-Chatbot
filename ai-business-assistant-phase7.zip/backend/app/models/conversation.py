"""Conversation and Message models -- persisted chat history for the
AI agent (Phase 6).

Conversation is business-scoped directly (business_id column), same
pattern as FAQ/Document. Message has no business_id of its own -- it
only knows its conversation_id -- so its RLS policy uses an EXISTS
subquery against conversations, exactly like DocumentChunk does
against Document (see migrations/versions/0004).

Redis (app/memory/short_term_memory.py) holds the last few turns for
fast per-request context; these tables are the durable source of
truth the AI agent falls back to (and what Phase 8's WhatsApp
integration and Phase 10's analytics will read from).
"""

import enum
import uuid
from typing import Any

from sqlalchemy import JSON, Enum, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base_class import Base
from app.models.mixins import TimestampMixin, UUIDPrimaryKeyMixin


class ConversationChannel(str, enum.Enum):
    WEB = "web"
    WHATSAPP = "whatsapp"


class ConversationStatus(str, enum.Enum):
    OPEN = "open"
    HANDED_OFF = "handed_off"
    CLOSED = "closed"


class MessageRole(str, enum.Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class Conversation(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "conversations"

    business_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False
    )
    # Phone number for WhatsApp, opaque session id for the web widget.
    # This -- not conversation.id -- is what a returning user is
    # identified by, so the agent can resume an existing conversation.
    external_user_ref: Mapped[str] = mapped_column(Text, nullable=False)
    channel: Mapped[ConversationChannel] = mapped_column(
        Enum(ConversationChannel, name="conversation_channel", native_enum=False, length=16),
        default=ConversationChannel.WEB,
        nullable=False,
    )
    status: Mapped[ConversationStatus] = mapped_column(
        Enum(ConversationStatus, name="conversation_status", native_enum=False, length=16),
        default=ConversationStatus.OPEN,
        nullable=False,
    )

    messages: Mapped[list["Message"]] = relationship(
        back_populates="conversation", cascade="all, delete-orphan", order_by="Message.created_at"
    )

    def __repr__(self) -> str:
        return f"<Conversation id={self.id} business_id={self.business_id}>"


class Message(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "messages"

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False
    )
    role: Mapped[MessageRole] = mapped_column(
        Enum(MessageRole, name="message_role", native_enum=False, length=16), nullable=False
    )
    content: Mapped[str] = mapped_column(Text, nullable=False)
    # Set on assistant messages only: which graph branch produced this
    # reply (faq / rag / chitchat / handoff / ...), for analytics.
    intent: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Serialized list[dict] of {document_id, chunk_index, score} for
    # RAG-grounded answers -- lets the frontend show "sources".
    citations: Mapped[list[dict[str, Any]] | None] = mapped_column(JSON, nullable=True)

    conversation: Mapped["Conversation"] = relationship(back_populates="messages")

    def __repr__(self) -> str:
        return f"<Message id={self.id} conversation_id={self.conversation_id} role={self.role}>"
