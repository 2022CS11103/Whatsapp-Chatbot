"""Selects the correct DocumentParser implementation by content type."""

from app.rag.document_parsers.base_parser import DocumentParser
from app.rag.document_parsers.pdf_parser import PDFParser
from app.rag.document_parsers.text_parser import TextParser

SUPPORTED_CONTENT_TYPES: dict[str, type[DocumentParser]] = {
    "application/pdf": PDFParser,
    "text/plain": TextParser,
}


def get_parser_for_content_type(content_type: str) -> DocumentParser:
    parser_cls = SUPPORTED_CONTENT_TYPES.get(content_type)
    if parser_cls is None:
        raise ValueError(
            f"Unsupported content type: {content_type!r}. "
            f"Supported types: {sorted(SUPPORTED_CONTENT_TYPES)}"
        )
    return parser_cls()
