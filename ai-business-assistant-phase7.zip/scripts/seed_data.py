"""Seed a demo user for local development.

Usage (from backend/ with venv active):
    python ../scripts/seed_data.py
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from app.auth.password_hasher import PasswordHasher  # noqa: E402
from app.database.session import AsyncSessionFactory  # noqa: E402
from app.models.user import User, UserRole  # noqa: E402
from app.repositories.user_repository import UserRepository  # noqa: E402

DEMO_USERS = [
    {
        "email": "owner@demo-restaurant.com",
        "password": "demo-password-123",
        "full_name": "Demo Restaurant Owner",
        "role": UserRole.OWNER,
    },
    {
        "email": "admin@aibusinessassistant.com",
        "password": "admin-password-123",
        "full_name": "Platform Admin",
        "role": UserRole.ADMIN,
    },
]


async def seed() -> None:
    hasher = PasswordHasher()
    async with AsyncSessionFactory() as session:
        repo = UserRepository(session)
        for entry in DEMO_USERS:
            existing = await repo.get_by_email(entry["email"])
            if existing:
                print(f"skip (exists): {entry['email']}")
                continue
            user = User(
                email=entry["email"],
                hashed_password=hasher.hash(entry["password"]),
                full_name=entry["full_name"],
                role=entry["role"],
            )
            await repo.add(user)
            print(f"created: {entry['email']} / {entry['password']}")
        await session.commit()


if __name__ == "__main__":
    asyncio.run(seed())
