"""Business and business-settings endpoints."""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, status

from app.api.deps import CurrentUserDep, get_business_service
from app.models.business import Business
from app.models.business_settings import BusinessSettings
from app.schemas.business_schema import (
    BusinessCreateRequest,
    BusinessResponse,
    BusinessSettingsResponse,
    BusinessSettingsUpdateRequest,
    BusinessUpdateRequest,
)
from app.schemas.common_schema import PaginatedResponse
from app.services.business_service import BusinessService
from app.utils.pagination import PaginationParams, pagination_params

router = APIRouter(prefix="/businesses", tags=["businesses"])

BusinessServiceDep = Annotated[BusinessService, Depends(get_business_service)]
PaginationDep = Annotated[PaginationParams, Depends(pagination_params)]


@router.post("", response_model=BusinessResponse, status_code=status.HTTP_201_CREATED)
async def create_business(
    payload: BusinessCreateRequest,
    current_user: CurrentUserDep,
    business_service: BusinessServiceDep,
) -> Business:
    return await business_service.create(current_user, payload)


@router.get("", response_model=PaginatedResponse[BusinessResponse])
async def list_businesses(
    current_user: CurrentUserDep,
    business_service: BusinessServiceDep,
    pagination: PaginationDep,
) -> PaginatedResponse[BusinessResponse]:
    items, total = await business_service.list_for_user(
        current_user, pagination.offset, pagination.page_size
    )
    return PaginatedResponse(
        items=[BusinessResponse.model_validate(item) for item in items],
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
    )


@router.get("/{business_id}", response_model=BusinessResponse)
async def get_business(
    business_id: UUID,
    current_user: CurrentUserDep,
    business_service: BusinessServiceDep,
) -> Business:
    return await business_service.get(current_user, business_id)


@router.patch("/{business_id}", response_model=BusinessResponse)
async def update_business(
    business_id: UUID,
    payload: BusinessUpdateRequest,
    current_user: CurrentUserDep,
    business_service: BusinessServiceDep,
) -> Business:
    return await business_service.update(current_user, business_id, payload)


@router.delete("/{business_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_business(
    business_id: UUID,
    current_user: CurrentUserDep,
    business_service: BusinessServiceDep,
) -> None:
    await business_service.delete(current_user, business_id)


@router.get("/{business_id}/settings", response_model=BusinessSettingsResponse)
async def get_business_settings(
    business_id: UUID,
    current_user: CurrentUserDep,
    business_service: BusinessServiceDep,
) -> BusinessSettings:
    return await business_service.get_settings(current_user, business_id)


@router.patch("/{business_id}/settings", response_model=BusinessSettingsResponse)
async def update_business_settings(
    business_id: UUID,
    payload: BusinessSettingsUpdateRequest,
    current_user: CurrentUserDep,
    business_service: BusinessServiceDep,
) -> BusinessSettings:
    return await business_service.update_settings(current_user, business_id, payload)
