"""Parser for .txt files."""

from app.rag.document_parsers.base_parser import DocumentParser


class TextParser(DocumentParser):
    def extract_text(self, file_bytes: bytes) -> str:
        try:
            return file_bytes.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("File is not valid UTF-8 text") from exc
