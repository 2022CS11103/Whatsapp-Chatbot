"""index + unique constraint on businesses.whatsapp_number

Revision ID: 0006
Revises: 0005
Create Date: 2026-07-08

Phase 7 (WhatsApp) resolves which business owns an inbound message by
looking up Business.whatsapp_number -- a query pattern this table
never needed before (every prior lookup went through the owner_id
index). Postgres unique indexes permit any number of NULL entries, so
this doesn't force every business to have a WhatsApp number; it just
guarantees two businesses can't both claim the same one.
"""
from collections.abc import Sequence

from alembic import op

revision: str = "0006"
down_revision: str | None = "0005"
branch_labels: Sequence[str] | None = None
depends_on: Sequence[str] | None = None


def upgrade() -> None:
    op.create_index(
        "ix_businesses_whatsapp_number",
        "businesses",
        ["whatsapp_number"],
        unique=True,
    )


def downgrade() -> None:
    op.drop_index("ix_businesses_whatsapp_number", table_name="businesses")
