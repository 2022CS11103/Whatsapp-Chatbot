"""Qdrant vector database client wrapper.

One Qdrant collection per business: `{prefix}_{business_id}`.
This keeps vector search automatically tenant-scoped -- a search
call on business A's collection can never return chunks from
business B, even if the app-layer RLS context were missing.

Lazy collection creation: create_collection_if_not_exists() is called
before any upsert, so a business's first document upload triggers
collection creation transparently.
"""

import uuid

from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance,
    PointStruct,
    ScoredPoint,
    VectorParams,
)

from app.config.settings import Settings


class QdrantVectorStore:
    def __init__(self, settings: Settings) -> None:
        self._client = AsyncQdrantClient(url=settings.QDRANT_URL)
        self._prefix = settings.QDRANT_COLLECTION_PREFIX
        self._dimension = settings.EMBEDDING_DIMENSION

    def collection_name(self, business_id: uuid.UUID) -> str:
        return f"{self._prefix}_{str(business_id).replace('-', '_')}"

    async def create_collection_if_not_exists(self, business_id: uuid.UUID) -> None:
        name = self.collection_name(business_id)
        existing = await self._client.collection_exists(name)
        if not existing:
            await self._client.create_collection(
                collection_name=name,
                vectors_config=VectorParams(
                    size=self._dimension,
                    distance=Distance.COSINE,
                ),
            )

    async def upsert(
        self,
        business_id: uuid.UUID,
        points: list[PointStruct],
    ) -> None:
        name = self.collection_name(business_id)
        await self._client.upsert(collection_name=name, points=points, wait=True)

    async def search(
        self,
        business_id: uuid.UUID,
        query_vector: list[float],
        top_k: int = 5,
    ) -> list[ScoredPoint]:
        name = self.collection_name(business_id)
        return await self._client.search(
            collection_name=name,
            query_vector=query_vector,
            limit=top_k,
            with_payload=True,
        )

    async def delete_points(self, business_id: uuid.UUID, point_ids: list[str]) -> None:
        """Remove specific points (used when a document is deleted)."""
        from qdrant_client.models import PointIdsList

        name = self.collection_name(business_id)
        await self._client.delete(
            collection_name=name,
            points_selector=PointIdsList(points=point_ids),
        )

    async def delete_collection(self, business_id: uuid.UUID) -> None:
        """Remove entire collection (used when a business is deleted)."""
        name = self.collection_name(business_id)
        exists = await self._client.collection_exists(name)
        if exists:
            await self._client.delete_collection(name)
