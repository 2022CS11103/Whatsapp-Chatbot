"""File storage abstraction.

LocalStorageService is the dev/default implementation, writing to
STORAGE_DIR on local disk. The StorageService interface is what the
rest of the app depends on, so swapping to S3 in production (Phase 11
deployment) means writing one new class, not touching callers.
"""

import uuid
from abc import ABC, abstractmethod
from pathlib import Path


class StorageService(ABC):
    @abstractmethod
    async def save(self, business_id: uuid.UUID, filename: str, content: bytes) -> str:
        """Persists content, returns an opaque storage path/key to
        pass to read()/delete() later."""
        raise NotImplementedError

    @abstractmethod
    async def read(self, storage_path: str) -> bytes:
        raise NotImplementedError

    @abstractmethod
    async def delete(self, storage_path: str) -> None:
        raise NotImplementedError


class LocalStorageService(StorageService):
    def __init__(self, storage_dir: str) -> None:
        self._storage_dir = storage_dir

    async def save(self, business_id: uuid.UUID, filename: str, content: bytes) -> str:
        from app.utils.file_utils import build_storage_path

        path = build_storage_path(self._storage_dir, business_id, filename)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return str(path)

    async def read(self, storage_path: str) -> bytes:
        return Path(storage_path).read_bytes()

    async def delete(self, storage_path: str) -> None:
        path = Path(storage_path)
        path.unlink(missing_ok=True)
