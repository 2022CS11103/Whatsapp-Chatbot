"""guardrail_node: the last stop before a reply reaches the user.

Deliberately implemented as plain code, not another LLM call --
"trust the LLM to police itself" is exactly the failure mode this
node exists to catch. Two checks:

1. Hallucination guard: a "rag" answer with zero retrieved chunks
   means there was nothing to ground the LLM's answer in, so its
   draft is discarded in favor of an honest fallback (and the
   conversation is flagged for handoff).
2. Content filter: a small deny-list of phrases that should never
   reach a customer verbatim (competitor bashing, discount promises
   the business didn't authorize, etc). This list is intentionally
   short and will grow based on real flagged transcripts rather than
   guessed upfront -- an overlong list mostly produces false positives.
"""

from typing import Any

from app.agents.state import AgentState
from app.prompts.system_prompts import FALLBACK_NO_CONTEXT_MESSAGE, HANDOFF_MESSAGE

_DENYLIST_PHRASES = (
    "i guarantee",
    "100% guaranteed",
    "free discount code",
)

_HANDOFF_INTENTS = frozenset({"booking", "lead", "handoff"})


class GuardrailNode:
    async def __call__(self, state: AgentState) -> dict[str, Any]:
        intent = state.get("intent", "chitchat")
        flags: list[str] = []
        needs_handoff = intent in _HANDOFF_INTENTS

        if intent in _HANDOFF_INTENTS:
            answer = HANDOFF_MESSAGE
        elif intent == "faq" and state.get("faq_answer"):
            answer = state["faq_answer"] or FALLBACK_NO_CONTEXT_MESSAGE
        elif intent == "rag" and not state.get("retrieved_chunks"):
            flags.append("no_context_for_rag")
            answer = FALLBACK_NO_CONTEXT_MESSAGE
            needs_handoff = True
        else:
            answer = state.get("draft_answer") or FALLBACK_NO_CONTEXT_MESSAGE

        if self._violates_content_policy(answer):
            flags.append("content_filter")
            answer = FALLBACK_NO_CONTEXT_MESSAGE
            needs_handoff = True

        return {"final_answer": answer, "needs_handoff": needs_handoff, "guardrail_flags": flags}

    @staticmethod
    def _violates_content_policy(answer: str) -> bool:
        lowered = answer.lower()
        return any(phrase in lowered for phrase in _DENYLIST_PHRASES)
