"""Pydantic v2 schemas for the FAQ API."""

from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class FAQCreateRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    answer: str = Field(min_length=1, max_length=4000)
    category: str | None = Field(default=None, max_length=100)


class FAQBulkCreateRequest(BaseModel):
    faqs: list[FAQCreateRequest] = Field(min_length=1, max_length=100)


class FAQUpdateRequest(BaseModel):
    question: str | None = Field(default=None, min_length=1, max_length=2000)
    answer: str | None = Field(default=None, min_length=1, max_length=4000)
    category: str | None = Field(default=None, max_length=100)


class FAQResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    business_id: UUID
    question: str
    answer: str
    category: str | None
