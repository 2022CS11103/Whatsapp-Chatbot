"""Integration tests for /api/v1/businesses/{id}/faqs/* against real Postgres."""

import pytest
from httpx import ASGITransport, AsyncClient

from app.database.base_class import Base
from app.database.session import engine
from app.main import app

pytestmark = pytest.mark.integration


@pytest.fixture(autouse=True)
async def _setup_database():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


async def _register_login_and_create_business(
    client: AsyncClient, email: str, business_name: str
) -> tuple[str, str]:
    await client.post("/api/v1/auth/register", json={"email": email, "password": "supersecure123"})
    login_resp = await client.post(
        "/api/v1/auth/login", json={"email": email, "password": "supersecure123"}
    )
    token: str = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    biz_resp = await client.post(
        "/api/v1/businesses",
        json={"name": business_name, "industry_type": "clinic"},
        headers=headers,
    )
    business_id: str = biz_resp.json()["id"]
    return token, business_id


@pytest.mark.asyncio
async def test_create_and_list_faqs(client: AsyncClient) -> None:
    token, business_id = await _register_login_and_create_business(
        client, "faq-owner@example.com", "FAQ Clinic"
    )
    headers = {"Authorization": f"Bearer {token}"}

    create_resp = await client.post(
        f"/api/v1/businesses/{business_id}/faqs",
        json={"question": "What are your hours?", "answer": "9-6 daily"},
        headers=headers,
    )
    assert create_resp.status_code == 201

    list_resp = await client.get(f"/api/v1/businesses/{business_id}/faqs", headers=headers)
    assert list_resp.status_code == 200
    assert list_resp.json()["total"] == 1


@pytest.mark.asyncio
async def test_bulk_create_faqs(client: AsyncClient) -> None:
    token, business_id = await _register_login_and_create_business(
        client, "bulk-owner@example.com", "Bulk Clinic"
    )
    headers = {"Authorization": f"Bearer {token}"}

    bulk_resp = await client.post(
        f"/api/v1/businesses/{business_id}/faqs/bulk",
        json={
            "faqs": [
                {"question": "Q1", "answer": "A1"},
                {"question": "Q2", "answer": "A2"},
                {"question": "Q3", "answer": "A3"},
            ]
        },
        headers=headers,
    )
    assert bulk_resp.status_code == 201
    assert len(bulk_resp.json()) == 3

    list_resp = await client.get(f"/api/v1/businesses/{business_id}/faqs", headers=headers)
    assert list_resp.json()["total"] == 3


@pytest.mark.asyncio
async def test_owner_cannot_access_faqs_of_another_owners_business(client: AsyncClient) -> None:
    token_a, business_a = await _register_login_and_create_business(
        client, "faq-victim@example.com", "Victim Clinic"
    )
    token_b, _ = await _register_login_and_create_business(
        client, "faq-intruder@example.com", "Intruder Gym"
    )

    await client.post(
        f"/api/v1/businesses/{business_a}/faqs",
        json={"question": "Private Q", "answer": "Private A"},
        headers={"Authorization": f"Bearer {token_a}"},
    )

    list_resp = await client.get(
        f"/api/v1/businesses/{business_a}/faqs",
        headers={"Authorization": f"Bearer {token_b}"},
    )
    assert list_resp.status_code == 403

    create_resp = await client.post(
        f"/api/v1/businesses/{business_a}/faqs",
        json={"question": "Hijack", "answer": "Attempt"},
        headers={"Authorization": f"Bearer {token_b}"},
    )
    assert create_resp.status_code == 403


@pytest.mark.asyncio
async def test_update_and_delete_faq(client: AsyncClient) -> None:
    token, business_id = await _register_login_and_create_business(
        client, "faq-editor@example.com", "Editor Clinic"
    )
    headers = {"Authorization": f"Bearer {token}"}

    create_resp = await client.post(
        f"/api/v1/businesses/{business_id}/faqs",
        json={"question": "Old Q", "answer": "Old A"},
        headers=headers,
    )
    faq_id = create_resp.json()["id"]

    update_resp = await client.patch(
        f"/api/v1/businesses/{business_id}/faqs/{faq_id}",
        json={"answer": "New A"},
        headers=headers,
    )
    assert update_resp.status_code == 200
    assert update_resp.json()["answer"] == "New A"
    assert update_resp.json()["question"] == "Old Q"

    delete_resp = await client.delete(
        f"/api/v1/businesses/{business_id}/faqs/{faq_id}", headers=headers
    )
    assert delete_resp.status_code == 204

    get_resp = await client.get(f"/api/v1/businesses/{business_id}/faqs/{faq_id}", headers=headers)
    assert get_resp.status_code == 404
