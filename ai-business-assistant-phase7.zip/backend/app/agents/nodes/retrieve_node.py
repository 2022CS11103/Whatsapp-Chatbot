"""retrieve_node: runs Qdrant semantic search via the Phase 5
Retriever. Only reached when the graph routes to "rag" (see
app/agents/graph.py:route_after_intent) -- FAQ and chitchat never hit
the vector store at all.
"""

import uuid
from dataclasses import asdict
from typing import Any

from app.agents.state import AgentState
from app.rag.retriever import Retriever


class RetrieveNode:
    def __init__(
        self,
        retriever: Retriever,
        business_id: uuid.UUID,
        top_k: int,
        score_threshold: float,
    ) -> None:
        self._retriever = retriever
        self._business_id = business_id
        self._top_k = top_k
        self._score_threshold = score_threshold

    async def __call__(self, state: AgentState) -> dict[str, Any]:
        chunks = await self._retriever.retrieve(
            query=state["user_message"],
            business_id=self._business_id,
            top_k=self._top_k,
            score_threshold=self._score_threshold,
        )
        return {"retrieved_chunks": [asdict(chunk) for chunk in chunks]}
