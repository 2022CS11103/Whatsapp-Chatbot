"""Splits extracted document text into overlapping chunks.

A simple fixed-size character chunker, not token-aware. This keeps it
dependency-free and deterministic for testing. Phase 5 (Vector
Database) may swap this for a token-aware splitter if embedding model
context limits make that necessary -- this function is the single
seam where that change would happen.
"""


def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 150) -> list[str]:
    """Splits text into chunks of `chunk_size` characters, each chunk
    overlapping the previous by `overlap` characters so semantic
    context isn't lost at chunk boundaries.

    Whitespace-only text returns an empty list. Text shorter than
    chunk_size returns a single chunk.
    """
    if chunk_size <= overlap:
        raise ValueError("chunk_size must be greater than overlap")

    stripped = text.strip()
    if not stripped:
        return []

    chunks: list[str] = []
    start = 0
    text_length = len(stripped)
    step = chunk_size - overlap

    while start < text_length:
        end = start + chunk_size
        chunk = stripped[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start += step

    return chunks
