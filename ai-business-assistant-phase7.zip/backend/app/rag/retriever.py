"""Semantic retriever for RAG.

Given a query string and a business_id, embeds the query and searches
the business's Qdrant collection for the most relevant chunks.
Returns RetrievedChunk objects that include the source document_id and
chunk_index so Phase 6 (RAG agent) can build citations.

The agent in Phase 6 depends only on this class, never on Qdrant or
the embedding provider directly -- so the underlying store can be
swapped (e.g. pgvector for simpler deployments) without touching
agent logic.
"""

import uuid
from dataclasses import dataclass

from app.rag.embedding_provider import EmbeddingProvider
from app.rag.qdrant_store import QdrantVectorStore


@dataclass
class RetrievedChunk:
    chunk_id: str  # Qdrant point id
    document_id: str  # for citation back to source document
    chunk_index: int  # position in original document
    content: str  # the actual text
    score: float  # cosine similarity score (0-1)


class Retriever:
    def __init__(
        self,
        embedding_provider: EmbeddingProvider,
        vector_store: QdrantVectorStore,
    ) -> None:
        self._embedder = embedding_provider
        self._store = vector_store

    async def retrieve(
        self,
        query: str,
        business_id: uuid.UUID,
        top_k: int = 5,
        score_threshold: float = 0.3,
    ) -> list[RetrievedChunk]:
        """Embed the query, search Qdrant, filter by score threshold,
        and return ranked RetrievedChunk objects.

        score_threshold: chunks below this cosine similarity are
        discarded -- prevents returning irrelevant context to the LLM,
        which is a leading cause of hallucination in RAG systems.
        """
        vectors = await self._embedder.embed([query])
        if not vectors:
            return []

        results = await self._store.search(
            business_id=business_id,
            query_vector=vectors[0],
            top_k=top_k,
        )

        chunks = []
        for point in results:
            if point.score < score_threshold:
                continue
            payload = point.payload or {}
            chunks.append(
                RetrievedChunk(
                    chunk_id=str(point.id),
                    document_id=payload.get("document_id", ""),
                    chunk_index=payload.get("chunk_index", 0),
                    content=payload.get("content", ""),
                    score=point.score,
                )
            )

        return chunks
