#!/usr/bin/env bash
# Smoke-test / documentation script for the AI Agent chat API (Phase 6).
# Requires OPENAI_API_KEY (or the business's configured provider key) set
# in the backend's environment, and at least one FAQ seeded for the FAQ
# branch to short-circuit.
# Usage: ./scripts/curl_examples_chat.sh [base_url]
set -euo pipefail

BASE_URL="${1:-http://localhost:8000}/api/v1"
STAMP=$(date +%s)
EMAIL="chatowner-$STAMP@example.com"
PASSWORD="securepass123"

echo "==> Register + login"
curl -s -X POST "$BASE_URL/auth/register" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}" > /dev/null
TOKEN=$(curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}" | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

echo "==> Create business"
BIZ_ID=$(curl -s -X POST "$BASE_URL/businesses" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"Chat Test Cafe","industry_type":"restaurant"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

echo "==> Seed an FAQ so the faq branch has something to match"
curl -s -X POST "$BASE_URL/businesses/$BIZ_ID/faqs" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"question":"What are your opening hours?","answer":"We are open 9am to 9pm every day."}' > /dev/null

echo "==> Chat: FAQ-matching question (should short-circuit, no LLM call for the answer)"
curl -s -X POST "$BASE_URL/businesses/$BIZ_ID/chat" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"external_user_ref":"web-session-1","message":"What are your opening hours?"}'
echo -e "\n"

echo "==> Chat: chitchat"
curl -s -X POST "$BASE_URL/businesses/$BIZ_ID/chat" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"external_user_ref":"web-session-1","message":"Hey there!"}'
echo -e "\n"

echo "==> Chat: booking intent (should trigger a handoff, no LLM call)"
curl -s -X POST "$BASE_URL/businesses/$BIZ_ID/chat" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"external_user_ref":"web-session-1","message":"I would like to book a table for 4 tonight"}'
echo -e "\n"

echo "==> Chat: same conversation continues (external_user_ref reused -> same conversation_id)"
curl -s -X POST "$BASE_URL/businesses/$BIZ_ID/chat" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"external_user_ref":"web-session-1","message":"Actually never mind, thanks"}'
echo -e "\n"
