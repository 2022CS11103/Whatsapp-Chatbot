"""Integration tests for /api/v1/auth/* against a real Postgres instance.

Requires a running test database — see docker/docker-compose.yml.
Run with: docker compose up -d postgres && pytest tests/integration -m integration
"""

import pytest
from httpx import ASGITransport, AsyncClient

from app.database.base_class import Base
from app.database.session import engine
from app.main import app

pytestmark = pytest.mark.integration


@pytest.fixture(autouse=True)
async def _setup_database():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    # Each pytest-asyncio test function gets its own event loop, but the
    # SQLAlchemy engine's connection pool is a module-level singleton whose
    # pooled connections are bound to whichever loop created them. Without
    # disposing here, the next test's loop tries to reuse a connection from
    # a now-closed loop and asyncpg raises "Event loop is closed".
    await engine.dispose()


@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest.mark.asyncio
async def test_register_then_login_then_me(client: AsyncClient) -> None:
    register_resp = await client.post(
        "/api/v1/auth/register",
        json={"email": "integration@example.com", "password": "supersecure123"},
    )
    assert register_resp.status_code == 201
    assert register_resp.json()["email"] == "integration@example.com"

    login_resp = await client.post(
        "/api/v1/auth/login",
        json={"email": "integration@example.com", "password": "supersecure123"},
    )
    assert login_resp.status_code == 200
    access_token = login_resp.json()["access_token"]

    me_resp = await client.get(
        "/api/v1/auth/me", headers={"Authorization": f"Bearer {access_token}"}
    )
    assert me_resp.status_code == 200
    assert me_resp.json()["email"] == "integration@example.com"


@pytest.mark.asyncio
async def test_duplicate_register_returns_409(client: AsyncClient) -> None:
    payload = {"email": "dup-integration@example.com", "password": "supersecure123"}
    await client.post("/api/v1/auth/register", json=payload)
    second = await client.post("/api/v1/auth/register", json=payload)

    assert second.status_code == 409
    assert second.json()["error_code"] == "duplicate_resource"


@pytest.mark.asyncio
async def test_me_without_token_returns_401(client: AsyncClient) -> None:
    resp = await client.get("/api/v1/auth/me")
    assert resp.status_code == 401
