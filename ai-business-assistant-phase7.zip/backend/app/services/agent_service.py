"""AgentService: thin orchestrator that wires short-term memory, the
LangGraph agent, and persistence together. Per the design decision
recorded in docs/architecture.md, this class contains no business
logic of its own -- classification, retrieval, generation, and
guardrails all live in their respective nodes. This class only:

1. Resolves (or creates) the Conversation for the caller
2. Loads recent history (Redis first, DB fallback)
3. Builds a request-scoped agent graph and runs it
4. Persists the new user + assistant messages
5. Updates short-term memory
"""

import uuid
from typing import cast

from langgraph.graph.state import CompiledStateGraph

from app.agents.graph import build_agent_graph
from app.agents.nodes.guardrail_node import GuardrailNode
from app.agents.nodes.intent_node import IntentNode
from app.agents.nodes.response_node import ResponseNode
from app.agents.nodes.retrieve_node import RetrieveNode
from app.agents.providers.base_provider import LLMProvider
from app.agents.state import AgentState
from app.memory.short_term_memory import ShortTermMemory, TurnDict
from app.models.business import Business
from app.models.conversation import Conversation, ConversationChannel, Message, MessageRole
from app.rag.retriever import Retriever
from app.repositories.conversation_repository import ConversationRepository
from app.repositories.faq_repository import FAQRepository
from app.schemas.chat_schema import ChatResponse, CitationResponse


class AgentService:
    def __init__(
        self,
        llm_provider: LLMProvider,
        retriever: Retriever,
        faq_repository: FAQRepository,
        conversation_repository: ConversationRepository,
        memory: ShortTermMemory,
        agent_max_output_tokens: int,
        agent_rag_top_k: int,
        agent_rag_score_threshold: float,
    ) -> None:
        self._llm = llm_provider
        self._retriever = retriever
        self._faqs = faq_repository
        self._conversations = conversation_repository
        self._memory = memory
        self._max_output_tokens = agent_max_output_tokens
        self._rag_top_k = agent_rag_top_k
        self._rag_score_threshold = agent_rag_score_threshold

    async def handle_message(
        self,
        business: Business,
        external_user_ref: str,
        user_message: str,
        channel: ConversationChannel = ConversationChannel.WEB,
    ) -> ChatResponse:
        """Entry point for every inbound channel (web widget, WhatsApp,
        ...). `channel` only affects which Conversation gets created
        the first time this external_user_ref writes in -- an already
        -open conversation keeps its original channel regardless of
        what's passed here.
        """
        conversation = await self._conversations.get_or_create(
            business.id, external_user_ref, channel
        )
        history = await self._load_history(conversation.id)

        graph = self._build_graph(business)
        initial_state: AgentState = {
            "business_id": str(business.id),
            "conversation_id": str(conversation.id),
            "user_message": user_message,
            "history": history,  # type: ignore[typeddict-item]
        }
        raw_final_state = await graph.ainvoke(initial_state)
        final_state: AgentState = cast(AgentState, raw_final_state)

        await self._persist_turn(conversation, user_message, final_state)
        await self._memory.append_turn(str(conversation.id), "user", user_message)
        await self._memory.append_turn(
            str(conversation.id), "assistant", final_state["final_answer"]
        )

        return ChatResponse(
            conversation_id=conversation.id,
            reply=final_state["final_answer"],
            intent=final_state.get("intent", "chitchat"),
            citations=[
                CitationResponse(**citation) for citation in final_state.get("citations", [])
            ],
            needs_handoff=final_state.get("needs_handoff", False),
        )

    async def _load_history(self, conversation_id: uuid.UUID) -> list[TurnDict]:
        history = await self._memory.get_history(str(conversation_id))
        if history:
            return history

        # Redis window missing or expired -- fall back to the durable
        # store and repopulate the cache for subsequent turns.
        messages = await self._conversations.get_recent_messages(conversation_id, limit=20)
        turns: list[TurnDict] = [
            {"role": message.role.value, "content": message.content}
            for message in messages
            if message.role in (MessageRole.USER, MessageRole.ASSISTANT)
        ]
        if turns:
            await self._memory.seed(str(conversation_id), turns)
        return turns

    async def _persist_turn(
        self, conversation: Conversation, user_message: str, final_state: AgentState
    ) -> None:
        await self._conversations.add_message(
            Message(
                conversation_id=conversation.id,
                role=MessageRole.USER,
                content=user_message,
            )
        )
        await self._conversations.add_message(
            Message(
                conversation_id=conversation.id,
                role=MessageRole.ASSISTANT,
                content=final_state["final_answer"],
                intent=final_state.get("intent"),
                citations=final_state.get("citations") or None,
            )
        )
        await self._conversations.commit()

    def _build_graph(self, business: Business) -> CompiledStateGraph:
        intent_node = IntentNode(self._llm, self._faqs, business.id)
        retrieve_node = RetrieveNode(
            self._retriever, business.id, self._rag_top_k, self._rag_score_threshold
        )
        response_node = ResponseNode(
            self._llm,
            business_name=business.name,
            industry_type=business.industry_type.value,
            max_output_tokens=self._max_output_tokens,
        )
        guardrail_node = GuardrailNode()
        return build_agent_graph(intent_node, retrieve_node, response_node, guardrail_node)
