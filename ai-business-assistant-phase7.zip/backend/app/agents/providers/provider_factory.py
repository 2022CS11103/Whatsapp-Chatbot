"""Factory that returns the LLMProvider matching a business's chosen
provider (BusinessSettings.llm_provider), mirroring
app/rag/embedding_factory.py's pattern for embeddings.
"""

from app.agents.providers.base_provider import LLMProvider
from app.config.settings import Settings
from app.models.business_settings import LLMProviderChoice


def get_llm_provider(settings: Settings, choice: LLMProviderChoice) -> LLMProvider:
    if choice == LLMProviderChoice.OPENAI:
        from app.agents.providers.openai_provider import OpenAIChatProvider

        if not settings.OPENAI_API_KEY:
            raise RuntimeError("OPENAI_API_KEY is required when llm_provider=openai")
        return OpenAIChatProvider(
            api_key=settings.OPENAI_API_KEY, model=settings.AGENT_CHAT_MODEL_OPENAI
        )

    if choice == LLMProviderChoice.GEMINI:
        from app.agents.providers.gemini_provider import GeminiChatProvider

        if not settings.GEMINI_API_KEY:
            raise RuntimeError("GEMINI_API_KEY is required when llm_provider=gemini")
        return GeminiChatProvider(
            api_key=settings.GEMINI_API_KEY, model=settings.AGENT_CHAT_MODEL_GEMINI
        )

    if choice == LLMProviderChoice.CLAUDE:
        from app.agents.providers.claude_provider import ClaudeChatProvider

        if not settings.ANTHROPIC_API_KEY:
            raise RuntimeError("ANTHROPIC_API_KEY is required when llm_provider=claude")
        return ClaudeChatProvider(
            api_key=settings.ANTHROPIC_API_KEY, model=settings.AGENT_CHAT_MODEL_CLAUDE
        )

    raise ValueError(f"Unknown llm_provider {choice!r}")
