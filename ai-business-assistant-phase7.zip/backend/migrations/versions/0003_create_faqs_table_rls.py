"""create faqs table, enable RLS scoped to app.current_business_id

Revision ID: 0003
Revises: 0002
Create Date: 2026-06-30

RLS note: unlike businesses (scoped by owner_id), faqs are scoped by
business_id directly. The app.current_business_id session variable is
only set AFTER api/deps.py:get_owned_business has already verified the
caller owns (or administers) the business in question -- so this RLS
policy is a second, independent enforcement of a check the app layer
already made, not the only check.
"""
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0003"
down_revision: str | None = "0002"
branch_labels: Sequence[str] | None = None
depends_on: Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "faqs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "business_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("question", sa.Text(), nullable=False),
        sa.Column("answer", sa.Text(), nullable=False),
        sa.Column("category", sa.String(length=100), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_faqs_business_id", "faqs", ["business_id"])

    op.execute("ALTER TABLE faqs ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE faqs FORCE ROW LEVEL SECURITY")

    op.execute(
        """
        CREATE POLICY faq_select_policy ON faqs
        FOR SELECT
        USING (business_id = NULLIF(current_setting('app.current_business_id', true), '')::uuid)
        """
    )
    op.execute(
        """
        CREATE POLICY faq_insert_policy ON faqs
        FOR INSERT
        WITH CHECK (business_id = NULLIF(current_setting('app.current_business_id', true), '')::uuid)
        """
    )
    op.execute(
        """
        CREATE POLICY faq_update_policy ON faqs
        FOR UPDATE
        USING (business_id = NULLIF(current_setting('app.current_business_id', true), '')::uuid)
        WITH CHECK (business_id = NULLIF(current_setting('app.current_business_id', true), '')::uuid)
        """
    )
    op.execute(
        """
        CREATE POLICY faq_delete_policy ON faqs
        FOR DELETE
        USING (business_id = NULLIF(current_setting('app.current_business_id', true), '')::uuid)
        """
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS faq_delete_policy ON faqs")
    op.execute("DROP POLICY IF EXISTS faq_update_policy ON faqs")
    op.execute("DROP POLICY IF EXISTS faq_insert_policy ON faqs")
    op.execute("DROP POLICY IF EXISTS faq_select_policy ON faqs")
    op.drop_index("ix_faqs_business_id", table_name="faqs")
    op.drop_table("faqs")
