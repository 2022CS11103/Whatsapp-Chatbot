"""Pydantic v2 schemas for the chat (AI agent) API."""

from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ChatRequest(BaseModel):
    # Identifies the end user across turns (phone number, session id,
    # etc). Together with business_id this resolves to a Conversation
    # -- creating one on first contact, reusing it after.
    external_user_ref: str = Field(min_length=1, max_length=255)
    message: str = Field(min_length=1, max_length=4000)


class CitationResponse(BaseModel):
    document_id: str
    chunk_index: int
    score: float


class ChatResponse(BaseModel):
    conversation_id: UUID
    reply: str
    intent: str
    citations: list[CitationResponse] = Field(default_factory=list)
    needs_handoff: bool = False


class MessageResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    role: str
    content: str
    intent: str | None
    citations: list[dict[str, Any]] | None


class ConversationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    business_id: UUID
    external_user_ref: str
    channel: str
    status: str
