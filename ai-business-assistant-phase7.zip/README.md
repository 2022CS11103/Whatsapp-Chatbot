# AI Business Assistant

A multi-tenant AI automation platform for small businesses (restaurants, clinics,
gyms, salons, travel agencies, real estate, coaching institutes). The backend is
fully generic — only the uploaded knowledge base changes per business.

> **Status: Phase 7 of 11 complete — WhatsApp Integration.**
> See `docs/architecture.md` for the full system design and roadmap.

## Architecture at a glance

- **Backend**: Python 3.12, FastAPI, async SQLAlchemy 2.0, PostgreSQL, Redis
- **AI layer** (Phase 6+): LangGraph orchestration, pluggable LLM providers
  (OpenAI / Gemini / Claude), Qdrant for RAG
- **Pattern**: Layered architecture — Router → Service → Repository, with
  dependency injection wired in `app/api/deps.py`. No layer talks to a layer
  two hops away.
- **Multi-tenancy**: shared tables with `business_id` scoping, hardened with
  Postgres Row-Level Security from Phase 2 onward.

## Phase 1: Authentication

Implements registration, login, JWT access/refresh tokens, and `/auth/me`.

## Phase 7: WhatsApp Integration

Every business's WhatsApp number becomes another front door into the
same AI agent from Phase 6 — no separate logic, no separate memory.

```
Meta Cloud API                FastAPI                    Background
inbound message  ──POST──▶  webhook (verify         ──▶  process_inbound_
                             signature, 200 fast)         whatsapp_message
                                                                │
                                                                ▼
                                                          AgentService
                                                          (same graph as
                                                           the web chat)
                                                                │
                                                                ▼
                                                          Meta Cloud API
                                                          (send reply)
```

- The webhook (`GET/POST /api/v1/webhooks/whatsapp`) has no JWT auth —
  Meta calls it directly. Authenticity is proven a different way: the
  `GET` handshake checks a verify token you configure yourself, and
  every `POST` body is checked against Meta's `X-Hub-Signature-256`
  header (HMAC using your Meta App Secret) before anything in it is
  trusted.
- Meta expects a 200 within a few seconds; an LLM round-trip routinely
  takes longer. The webhook hands off to a `BackgroundTask`
  (`app/jobs/whatsapp_jobs.py`) and returns immediately — same pattern
  Phase 4's document ingestion already uses.
- A business is identified per-message by matching the WhatsApp
  number Meta says received it (`metadata.display_phone_number`)
  against `Business.whatsapp_number` — set that field via
  `PATCH /businesses/{id}` to connect a number.
- One Conversation history per (business, phone number) regardless of
  channel — `Conversation.channel` just records whether a given thread
  started on the web widget or WhatsApp.

### Connect a business's WhatsApp number

1. In the [Meta App Dashboard](https://developers.facebook.com/apps),
   add the WhatsApp product, grab the test number's Access Token and
   your App Secret.
2. Put those in `backend/.env`: `WHATSAPP_ACCESS_TOKEN`,
   `WHATSAPP_APP_SECRET`, and a `WHATSAPP_VERIFY_TOKEN` you make up
   yourself.
3. Set the business's number: `PATCH /businesses/{id}` with
   `{"whatsapp_number": "15551234567"}` (digits only, matching what
   Meta reports as `display_phone_number`).
4. Point the Meta Dashboard's webhook URL at
   `https://<your-public-host>/api/v1/webhooks/whatsapp` with the same
   verify token from step 2 — Meta calls it once to confirm ownership.
   (Meta requires HTTPS and a publicly reachable host; a tool like
   `ngrok` is the usual way to expose `localhost:8000` for testing.)
5. Message the test number on WhatsApp — the reply comes from the same
   agent graph as the web chat.

## Phase 6: AI Agent

A LangGraph state machine turns each chat message into a grounded reply:

```
User Message
     v
[intent_node]   <- classify: faq / rag / booking / lead / handoff / chitchat
     v
[retrieve_node] <- Qdrant semantic search (rag intent only)
     v
[response_node] <- LLM generates a grounded answer with citations
     v
[guardrail_node]<- hallucination check + content filter (code, not LLM)
     v
Final Reply
```

- A direct FAQ match short-circuits straight to the guardrail — no LLM
  call needed, since a curated FAQ answer doesn't need generating.
- `booking` / `lead` / `handoff` intents route straight to a handoff
  message, so no chat request ever silently drops a lead.
- The LLM provider (OpenAI / Gemini / Claude) is a per-business setting
  (`BusinessSettings.llm_provider`), resolved per request in
  `api/deps.py` and swappable via the `LLMProvider` interface.
- Redis (`app/memory/short_term_memory.py`) holds a rolling window of
  the last `MEMORY_MAX_TURNS` turns for fast context; `conversations` /
  `messages` (RLS-protected, same pattern as `faqs`/`documents`) remain
  the durable source of truth the cache falls back to.

Try it:

```bash
./scripts/curl_examples_chat.sh
```

### Run locally

```bash
cd backend
cp .env.example .env
# edit JWT_SECRET_KEY in .env — generate one with:
python -c "import secrets; print(secrets.token_urlsafe(48))"

python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

alembic upgrade head
uvicorn app.main:app --reload
```

Or via Docker Compose (Postgres + Redis + backend):

```bash
docker compose -f docker/docker-compose.yml up --build
```

### Try it

```bash
./scripts/curl_examples_auth.sh
```

Or open `http://localhost:8000/docs` for interactive Swagger UI.

### Run tests

```bash
pytest tests/unit                  # no DB required, runs in ~1s
pytest tests/integration -m integration   # requires Postgres running
```

### Code quality

```bash
ruff check app tests
black --check app tests
mypy app
```

## Project structure

```
backend/app/
├── api/routers/      HTTP endpoints only — no business logic
├── schemas/          Pydantic v2 request/response models
├── models/            SQLAlchemy ORM models
├── repositories/      Persistence queries — no business logic
├── services/           Business logic — no SQL, no HTTP
├── agents/              LangGraph state, nodes, and LLM provider strategies
├── memory/              Redis-backed short-term conversation memory
├── prompts/             System prompt templates
├── rag/                  Embeddings, chunking, Qdrant retrieval
├── integrations/whatsapp/ Meta Cloud API client, webhook schemas, signature verification
├── jobs/                 BackgroundTask workloads (document ingestion, inbound WhatsApp)
├── auth/                JWT + password hashing primitives
├── middleware/        Logging, error handling
├── config/             Settings (env-driven), logging config
├── database/          Async session factory, RLS-ready tenant context
└── utils/exceptions.py Custom exception hierarchy
```

See `docs/architecture.md` for the full architecture, ER diagram, API
design, and the remaining 4-phase roadmap (Dashboard → Analytics →
Deployment → Polish).
