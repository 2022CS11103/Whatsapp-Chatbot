"""Embedding provider interface.

Concrete implementations live alongside this file
(openai_embedding.py, gemini_embedding.py). The ingestion job
and retriever depend only on this interface, never on a concrete
class -- swap providers by changing EMBEDDING_PROVIDER in .env.
"""

from abc import ABC, abstractmethod


class EmbeddingProvider(ABC):
    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Returns a list of float vectors, one per input text.

        Batch size should be managed by the caller -- large document
        ingestions should chunk the texts list into batches of at most
        a few hundred to avoid hitting API rate limits.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Vector dimension produced by this provider/model combo."""
        raise NotImplementedError
