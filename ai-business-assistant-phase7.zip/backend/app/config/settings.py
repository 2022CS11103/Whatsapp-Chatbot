"""Application configuration loaded from environment variables.

All runtime configuration MUST flow through this module. Never read
os.environ directly elsewhere in the codebase — it breaks testability
and makes config drift invisible.
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field, PostgresDsn, RedisDsn
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- App ---
    APP_NAME: str = "AI Business Assistant"
    ENVIRONMENT: Literal["local", "staging", "production"] = "local"
    DEBUG: bool = False
    API_V1_PREFIX: str = "/api/v1"

    # --- Database ---
    DATABASE_URL: PostgresDsn
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20

    # --- Redis ---
    REDIS_URL: RedisDsn

    # --- Auth ---
    JWT_SECRET_KEY: str = Field(min_length=32)
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # --- CORS ---
    CORS_ORIGINS: list[str] = ["http://localhost:5173"]

    # --- AI Providers (used from Phase 6 onward) ---
    OPENAI_API_KEY: str | None = None
    GEMINI_API_KEY: str | None = None
    ANTHROPIC_API_KEY: str | None = None

    # --- AI Agent (Phase 6) ---
    AGENT_CHAT_MODEL_OPENAI: str = "gpt-4o-mini"
    AGENT_CHAT_MODEL_GEMINI: str = "gemini-3.5-flash"
    AGENT_CHAT_MODEL_CLAUDE: str = "claude-sonnet-4-6"
    AGENT_MAX_OUTPUT_TOKENS: int = 1024
    AGENT_RAG_TOP_K: int = 5
    AGENT_RAG_SCORE_THRESHOLD: float = 0.3

    # --- Short-term memory (Redis rolling window) ---
    MEMORY_MAX_TURNS: int = 10
    MEMORY_TTL_SECONDS: int = 60 * 60 * 6  # 6 hours of inactivity expires the window

    # --- WhatsApp (Meta Cloud API, Phase 7) ---
    # A single Meta app + system-user access token serves every
    # business on the platform; businesses are told apart per-webhook
    # by the phone_number_id Meta includes in each payload, matched
    # against Business.whatsapp_number (see app/jobs/whatsapp_jobs.py).
    WHATSAPP_ACCESS_TOKEN: str | None = None
    # Arbitrary string you choose yourself and enter in the Meta App
    # Dashboard's webhook config -- proves the GET verification request
    # actually came from your own dashboard setup, not a random caller.
    WHATSAPP_VERIFY_TOKEN: str | None = None
    # Meta App Secret, used to verify the X-Hub-Signature-256 header on
    # every inbound POST so forged webhook calls are rejected.
    WHATSAPP_APP_SECRET: str | None = None
    WHATSAPP_API_VERSION: str = "v21.0"

    # --- Qdrant ---
    QDRANT_URL: str = "http://localhost:6333"
    QDRANT_COLLECTION_PREFIX: str = "business"

    # --- Embeddings ---
    EMBEDDING_PROVIDER: str = "openai"  # openai | gemini
    EMBEDDING_MODEL_OPENAI: str = "text-embedding-3-small"
    EMBEDDING_MODEL_GEMINI: str = "models/text-embedding-004"
    EMBEDDING_DIMENSION: int = 1536  # text-embedding-3-small default

    # --- File storage (local disk for dev; swap StorageService impl for S3 in prod) ---
    STORAGE_DIR: str = "./storage/uploads"
    MAX_UPLOAD_SIZE_BYTES: int = 20 * 1024 * 1024  # 20 MB

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"


@lru_cache
def get_settings() -> Settings:
    """Cached settings singleton. Use via FastAPI Depends(get_settings)."""
    return Settings()
