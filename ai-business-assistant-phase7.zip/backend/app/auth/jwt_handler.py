"""JWT issuance and verification. Single responsibility: token I/O only.

No DB access here — AuthService is responsible for translating a
decoded token's subject into an actual User.
"""

from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4

import jwt

from app.config.settings import Settings
from app.utils.exceptions import TokenError


class TokenType(StrEnum):
    ACCESS = "access"
    REFRESH = "refresh"


class JWTHandler:
    def __init__(self, settings: Settings) -> None:
        self._secret = settings.JWT_SECRET_KEY
        self._algorithm = settings.JWT_ALGORITHM
        self._access_expire_minutes = settings.ACCESS_TOKEN_EXPIRE_MINUTES
        self._refresh_expire_days = settings.REFRESH_TOKEN_EXPIRE_DAYS

    def create_access_token(self, user_id: UUID) -> str:
        return self._create_token(
            user_id, TokenType.ACCESS, timedelta(minutes=self._access_expire_minutes)
        )

    def create_refresh_token(self, user_id: UUID) -> str:
        return self._create_token(
            user_id, TokenType.REFRESH, timedelta(days=self._refresh_expire_days)
        )

    def _create_token(self, user_id: UUID, token_type: TokenType, expires_in: timedelta) -> str:
        now = datetime.now(UTC)
        payload: dict[str, Any] = {
            "sub": str(user_id),
            "type": token_type.value,
            "jti": str(uuid4()),
            "iat": now,
            "exp": now + expires_in,
        }
        return jwt.encode(payload, self._secret, algorithm=self._algorithm)

    def decode(self, token: str, expected_type: TokenType) -> UUID:
        """Decode a token and return the user id, or raise TokenError."""
        try:
            payload = jwt.decode(token, self._secret, algorithms=[self._algorithm])
        except jwt.ExpiredSignatureError as exc:
            raise TokenError("Token has expired") from exc
        except jwt.InvalidTokenError as exc:
            raise TokenError("Token is invalid") from exc

        if payload.get("type") != expected_type.value:
            raise TokenError(f"Expected a {expected_type.value} token")

        try:
            return UUID(payload["sub"])
        except (KeyError, ValueError) as exc:
            raise TokenError("Token subject is malformed") from exc
