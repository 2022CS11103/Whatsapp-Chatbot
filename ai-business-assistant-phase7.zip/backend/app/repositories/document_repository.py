"""Document and DocumentChunk persistence queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.document import Document, DocumentChunk
from app.repositories.base_repository import BaseRepository


class DocumentRepository(BaseRepository[Document]):
    model = Document

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session)

    async def get_by_id_for_business(self, document_id: UUID, business_id: UUID) -> Document | None:
        result = await self._session.execute(
            select(Document).where(Document.id == document_id, Document.business_id == business_id)
        )
        return result.scalar_one_or_none()

    async def list_for_business(
        self, business_id: UUID, offset: int, limit: int
    ) -> tuple[list[Document], int]:
        items_result = await self._session.execute(
            select(Document)
            .where(Document.business_id == business_id)
            .order_by(Document.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        count_result = await self._session.execute(
            select(func.count()).select_from(Document).where(Document.business_id == business_id)
        )
        return list(items_result.scalars().all()), count_result.scalar_one()

    async def add_chunks(self, chunks: list[DocumentChunk]) -> list[DocumentChunk]:
        self._session.add_all(chunks)
        await self._session.flush()
        return chunks

    async def delete(self, document: Document) -> None:
        await self._session.delete(document)
        await self._session.flush()
