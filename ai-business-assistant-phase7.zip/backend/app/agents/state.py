"""Shared state threaded through every node of the agent graph
(app/agents/graph.py). Kept as a plain TypedDict (not a pydantic
model) because LangGraph nodes each return partial-state dicts that
get shallow-merged into this by the graph runtime -- pydantic
validation on every partial update would fight that.

Every field except user_message/business_id/conversation_id/history
is optional-by-convention: it's filled in as the state flows through
whichever branch of the graph it takes (see app/agents/graph.py for
the routing).
"""

from typing import Any, TypedDict


class CitationDict(TypedDict):
    document_id: str
    chunk_index: int
    score: float


class AgentState(TypedDict, total=False):
    # --- input, set once by AgentService before the graph runs ---
    business_id: str
    conversation_id: str
    user_message: str
    history: list[dict[str, str]]  # prior turns, oldest first, NOT including user_message

    # --- intent_node output ---
    intent: str  # faq | rag | booking | lead | handoff | chitchat
    faq_answer: str | None

    # --- retrieve_node output ---
    retrieved_chunks: list[dict[str, Any]]  # serialized RetrievedChunk

    # --- response_node output ---
    draft_answer: str
    citations: list[CitationDict]

    # --- guardrail_node output ---
    final_answer: str
    needs_handoff: bool
    guardrail_flags: list[str]
