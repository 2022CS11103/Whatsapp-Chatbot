"""Unit tests for the WhatsApp webhook router.

Exercises real HTTP request/response handling (via httpx's ASGI
transport against the actual FastAPI app) including the GET
verification handshake and POST signature verification -- the one
thing genuinely worth testing end-to-end here, since it's security-
critical and easy to get subtly wrong (raw body vs re-serialized JSON,
header casing, timing-safe comparison).

The background job itself (process_inbound_whatsapp_message) is
monkeypatched out: it needs a real Postgres/Redis/Qdrant to do
anything meaningful, which belongs in an integration test, not here.
"""

import hashlib
import hmac
import json

import httpx
import pytest

VERIFY_TOKEN = "my-verify-token"
APP_SECRET = "my-app-secret"


def _sign(body: bytes, secret: str = APP_SECRET) -> str:
    digest = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


def _sample_body() -> bytes:
    return json.dumps(
        {
            "entry": [
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "123",
                                    "display_phone_number": "15551234567",
                                },
                                "messages": [
                                    {
                                        "from": "15559876543",
                                        "id": "wamid.1",
                                        "type": "text",
                                        "text": {"body": "hours?"},
                                    }
                                ],
                            }
                        }
                    ]
                }
            ]
        }
    ).encode()


@pytest.fixture
def app_and_scheduled_calls(monkeypatch):
    monkeypatch.setenv("WHATSAPP_VERIFY_TOKEN", VERIFY_TOKEN)
    monkeypatch.setenv("WHATSAPP_APP_SECRET", APP_SECRET)

    from app.config.settings import get_settings

    get_settings.cache_clear()

    import app.api.routers.whatsapp_router as whatsapp_router_module

    scheduled_calls: list[dict] = []

    async def fake_job(**kwargs):
        scheduled_calls.append(kwargs)

    monkeypatch.setattr(whatsapp_router_module, "process_inbound_whatsapp_message", fake_job)

    from app.main import app

    yield app, scheduled_calls
    get_settings.cache_clear()


@pytest.mark.asyncio
async def test_verification_handshake_succeeds_with_correct_token(app_and_scheduled_calls) -> None:
    app, _ = app_and_scheduled_calls
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get(
            "/api/v1/webhooks/whatsapp",
            params={
                "hub.mode": "subscribe",
                "hub.verify_token": VERIFY_TOKEN,
                "hub.challenge": "CHALLENGE123",
            },
        )

    assert response.status_code == 200
    assert response.text == "CHALLENGE123"


@pytest.mark.asyncio
async def test_verification_handshake_rejects_wrong_token(app_and_scheduled_calls) -> None:
    app, _ = app_and_scheduled_calls
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get(
            "/api/v1/webhooks/whatsapp",
            params={
                "hub.mode": "subscribe",
                "hub.verify_token": "WRONG",
                "hub.challenge": "CHALLENGE123",
            },
        )

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_post_with_valid_signature_schedules_background_job(
    app_and_scheduled_calls,
) -> None:
    app, scheduled_calls = app_and_scheduled_calls
    body = _sample_body()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/webhooks/whatsapp",
            content=body,
            headers={"Content-Type": "application/json", "X-Hub-Signature-256": _sign(body)},
        )

    assert response.status_code == 200
    assert response.json() == {"status": "received"}
    assert len(scheduled_calls) == 1
    assert scheduled_calls[0]["from_number"] == "15559876543"
    assert scheduled_calls[0]["message_text"] == "hours?"
    assert scheduled_calls[0]["phone_number_id"] == "123"
    assert scheduled_calls[0]["display_phone_number"] == "15551234567"


@pytest.mark.asyncio
async def test_post_with_invalid_signature_is_rejected(app_and_scheduled_calls) -> None:
    app, scheduled_calls = app_and_scheduled_calls
    body = _sample_body()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/webhooks/whatsapp",
            content=body,
            headers={
                "Content-Type": "application/json",
                "X-Hub-Signature-256": "sha256=" + "0" * 64,
            },
        )

    assert response.status_code == 403
    assert scheduled_calls == []


@pytest.mark.asyncio
async def test_post_with_no_signature_header_is_rejected(app_and_scheduled_calls) -> None:
    app, scheduled_calls = app_and_scheduled_calls
    body = _sample_body()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/webhooks/whatsapp", content=body, headers={"Content-Type": "application/json"}
        )

    assert response.status_code == 403
    assert scheduled_calls == []


@pytest.mark.asyncio
async def test_non_text_message_is_skipped_without_scheduling_job(
    app_and_scheduled_calls,
) -> None:
    app, scheduled_calls = app_and_scheduled_calls
    body = json.dumps(
        {
            "entry": [
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "123",
                                    "display_phone_number": "15551234567",
                                },
                                "messages": [
                                    {"from": "15559876543", "id": "wamid.img", "type": "image"}
                                ],
                            }
                        }
                    ]
                }
            ]
        }
    ).encode()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/webhooks/whatsapp",
            content=body,
            headers={"Content-Type": "application/json", "X-Hub-Signature-256": _sign(body)},
        )

    assert response.status_code == 200
    assert scheduled_calls == []


@pytest.mark.asyncio
async def test_status_update_payload_returns_200_without_scheduling_job(
    app_and_scheduled_calls,
) -> None:
    app, scheduled_calls = app_and_scheduled_calls
    body = json.dumps(
        {
            "entry": [
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "123",
                                    "display_phone_number": "15551234567",
                                }
                            }
                        }
                    ]
                }
            ]
        }
    ).encode()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/webhooks/whatsapp",
            content=body,
            headers={"Content-Type": "application/json", "X-Hub-Signature-256": _sign(body)},
        )

    assert response.status_code == 200
    assert scheduled_calls == []
