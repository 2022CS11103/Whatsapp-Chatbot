"""Processes one inbound WhatsApp message through the same AgentService
used by the web chat endpoint, then sends the reply back via the Meta
Cloud API.

Run as a FastAPI BackgroundTask scheduled by
app/api/routers/whatsapp_router.py, for the same reason
app/jobs/ingestion_jobs.py runs as one: Meta expects the webhook to
return 200 within a few seconds, and an LLM round-trip routinely takes
longer than that. The webhook handler acknowledges immediately; this
function does the actual work afterward, on its own fresh DB session
(request-scoped dependencies are already closed by the time a
BackgroundTask runs).

Business resolution is the one thing this job does differently from
every other background job in the codebase: ingestion_jobs.py is
handed an already-known, already-authorized business_id by the request
that scheduled it. This job is *given* nothing but a WhatsApp phone
number by an unauthenticated webhook -- resolving that to a business
is the first thing it has to do, before there's any business_id to set
RLS context with. See BusinessRepository.get_by_whatsapp_number for
how that lookup is authorized.
"""

import logging

from redis.asyncio import Redis
from sqlalchemy import text

from app.agents.providers.provider_factory import get_llm_provider
from app.config.settings import get_settings
from app.database.session import AsyncSessionFactory
from app.integrations.whatsapp.client import WhatsAppClient
from app.memory.short_term_memory import ShortTermMemory
from app.models.business_settings import LLMProviderChoice
from app.models.conversation import ConversationChannel
from app.rag.embedding_factory import get_embedding_provider
from app.rag.qdrant_store import QdrantVectorStore
from app.rag.retriever import Retriever
from app.repositories.business_repository import BusinessRepository
from app.repositories.business_settings_repository import BusinessSettingsRepository
from app.repositories.conversation_repository import ConversationRepository
from app.repositories.faq_repository import FAQRepository
from app.services.agent_service import AgentService

logger = logging.getLogger(__name__)

_SEND_FAILURE_MESSAGE = (
    "Sorry, I'm having trouble responding right now. Please try again in a moment."
)


async def process_inbound_whatsapp_message(
    phone_number_id: str, display_phone_number: str, from_number: str, message_text: str
) -> None:
    settings = get_settings()
    whatsapp_client = WhatsAppClient(
        access_token=settings.WHATSAPP_ACCESS_TOKEN or "", api_version=settings.WHATSAPP_API_VERSION
    )

    async with AsyncSessionFactory() as session:
        # No authenticated user on a webhook request -- this session's
        # only path through businesses' RLS SELECT policy is the
        # admin-role bypass, same as BusinessRepository.list_all() uses.
        await session.execute(text("SELECT set_config('app.current_user_role', 'admin', true)"))
        business_repository = BusinessRepository(session)
        business = await business_repository.get_by_whatsapp_number(display_phone_number)

        if business is None:
            logger.warning(
                "process_inbound_whatsapp_message: no business registered for "
                "WhatsApp number %s (phone_number_id=%s) -- message from %s dropped",
                display_phone_number,
                phone_number_id,
                from_number,
            )
            return

        await session.execute(
            text("SELECT set_config('app.current_business_id', :bid, true)"),
            {"bid": str(business.id)},
        )

        try:
            settings_repository = BusinessSettingsRepository(session)
            business_settings = await settings_repository.get_by_business_id(business.id)
            llm_choice = (
                business_settings.llm_provider if business_settings else LLMProviderChoice.OPENAI
            )
            llm_provider = get_llm_provider(settings, llm_choice)

            embedder = get_embedding_provider(settings)
            qdrant_store = QdrantVectorStore(settings)
            retriever = Retriever(embedder, qdrant_store)

            faq_repository = FAQRepository(session)
            conversation_repository = ConversationRepository(session)

            redis_client: Redis = Redis.from_url(str(settings.REDIS_URL), decode_responses=True)
            try:
                memory = ShortTermMemory(
                    redis_client,
                    max_turns=settings.MEMORY_MAX_TURNS,
                    ttl_seconds=settings.MEMORY_TTL_SECONDS,
                )
                agent_service = AgentService(
                    llm_provider=llm_provider,
                    retriever=retriever,
                    faq_repository=faq_repository,
                    conversation_repository=conversation_repository,
                    memory=memory,
                    agent_max_output_tokens=settings.AGENT_MAX_OUTPUT_TOKENS,
                    agent_rag_top_k=settings.AGENT_RAG_TOP_K,
                    agent_rag_score_threshold=settings.AGENT_RAG_SCORE_THRESHOLD,
                )
                response = await agent_service.handle_message(
                    business=business,
                    external_user_ref=from_number,
                    user_message=message_text,
                    channel=ConversationChannel.WHATSAPP,
                )
            finally:
                await redis_client.aclose()

            await whatsapp_client.send_text_message(
                phone_number_id=phone_number_id, to=from_number, body=response.reply
            )

        except Exception:  # noqa: BLE001 -- a failure here must not crash the worker
            logger.exception(
                "process_inbound_whatsapp_message failed for business %s, from %s",
                business.id,
                from_number,
            )
            await whatsapp_client.send_text_message(
                phone_number_id=phone_number_id, to=from_number, body=_SEND_FAILURE_MESSAGE
            )
