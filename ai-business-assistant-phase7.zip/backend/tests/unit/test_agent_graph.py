"""Unit tests for the agent graph -- fakes only, no DB/Redis/LLM API."""

import uuid

import pytest

from app.agents.graph import build_agent_graph
from app.agents.nodes.guardrail_node import GuardrailNode
from app.agents.nodes.intent_node import IntentNode
from app.agents.nodes.response_node import ResponseNode
from app.agents.nodes.retrieve_node import RetrieveNode
from app.rag.retriever import RetrievedChunk


class FakeLLMProvider:
    def __init__(self, reply: str) -> None:
        self.reply = reply
        self.calls: list[tuple[str, list[dict]]] = []

    async def complete(self, system_prompt, history, max_tokens=1024):
        self.calls.append((system_prompt, history))
        return self.reply


class FakeFAQ:
    def __init__(self, answer: str) -> None:
        self.answer = answer


class FakeFAQRepository:
    def __init__(self, matches: list[FakeFAQ]) -> None:
        self.matches = matches

    async def search_for_business(self, business_id, query, limit=3):
        return self.matches


class FakeRetriever:
    def __init__(self, chunks: list[RetrievedChunk]) -> None:
        self.chunks = chunks

    async def retrieve(self, query, business_id, top_k=5, score_threshold=0.3):
        return self.chunks


def _build_graph(
    intent_reply: str,
    faq_matches: list[FakeFAQ],
    chunks: list[RetrievedChunk],
    response_reply: str,
):
    business_id = uuid.uuid4()
    intent_llm = FakeLLMProvider(intent_reply)
    faq_repo = FakeFAQRepository(faq_matches)
    intent_node = IntentNode(intent_llm, faq_repo, business_id)

    retriever = FakeRetriever(chunks)
    retrieve_node = RetrieveNode(retriever, business_id, top_k=5, score_threshold=0.3)

    response_llm = FakeLLMProvider(response_reply)
    response_node = ResponseNode(
        response_llm, business_name="Test Cafe", industry_type="restaurant", max_output_tokens=200
    )

    guardrail_node = GuardrailNode()
    graph = build_agent_graph(intent_node, retrieve_node, response_node, guardrail_node)
    return graph, response_llm


def _base_state(message: str = "What are your hours?") -> dict:
    return {
        "business_id": str(uuid.uuid4()),
        "conversation_id": str(uuid.uuid4()),
        "user_message": message,
        "history": [],
    }


@pytest.mark.asyncio
async def test_faq_direct_match_skips_llm_response_node() -> None:
    graph, response_llm = _build_graph(
        intent_reply="faq",
        faq_matches=[FakeFAQ("We are open 9-6 daily.")],
        chunks=[],
        response_reply="SHOULD NOT BE USED",
    )

    result = await graph.ainvoke(_base_state())

    assert result["intent"] == "faq"
    assert result["final_answer"] == "We are open 9-6 daily."
    assert result["needs_handoff"] is False
    assert response_llm.calls == []


@pytest.mark.asyncio
async def test_faq_intent_without_match_falls_through_to_rag() -> None:
    chunk = RetrievedChunk(
        chunk_id="c1", document_id="doc1", chunk_index=0, content="Menu details", score=0.8
    )
    graph, response_llm = _build_graph(
        intent_reply="faq", faq_matches=[], chunks=[chunk], response_reply="We serve pasta."
    )

    result = await graph.ainvoke(_base_state())

    assert result["intent"] == "rag"
    assert result["final_answer"] == "We serve pasta."
    assert result["citations"] == [{"document_id": "doc1", "chunk_index": 0, "score": 0.8}]
    assert len(response_llm.calls) == 1


@pytest.mark.asyncio
async def test_rag_with_no_retrieved_chunks_triggers_guardrail_fallback() -> None:
    graph, response_llm = _build_graph(
        intent_reply="rag", faq_matches=[], chunks=[], response_reply="a hallucinated answer"
    )

    result = await graph.ainvoke(_base_state())

    assert result["intent"] == "rag"
    assert "no_context_for_rag" in result["guardrail_flags"]
    assert result["needs_handoff"] is True
    # The LLM's hallucinated draft must never reach the user.
    assert result["final_answer"] != "a hallucinated answer"


@pytest.mark.asyncio
async def test_chitchat_intent_calls_response_node_without_retrieval() -> None:
    graph, response_llm = _build_graph(
        intent_reply="chitchat", faq_matches=[], chunks=[], response_reply="Hi! How can I help?"
    )

    result = await graph.ainvoke(_base_state("hello there"))

    assert result["intent"] == "chitchat"
    assert result["final_answer"] == "Hi! How can I help?"
    assert result["citations"] == []
    assert len(response_llm.calls) == 1


@pytest.mark.asyncio
async def test_booking_intent_short_circuits_to_handoff_without_llm_call() -> None:
    graph, response_llm = _build_graph(
        intent_reply="booking", faq_matches=[], chunks=[], response_reply="SHOULD NOT BE USED"
    )

    result = await graph.ainvoke(_base_state("I want to book a table for 4"))

    assert result["intent"] == "booking"
    assert result["needs_handoff"] is True
    assert response_llm.calls == []


@pytest.mark.asyncio
async def test_guardrail_content_filter_overrides_denylisted_reply() -> None:
    graph, _ = _build_graph(
        intent_reply="chitchat",
        faq_matches=[],
        chunks=[],
        response_reply="I guarantee this is the best deal in town!",
    )

    result = await graph.ainvoke(_base_state("tell me about your deals"))

    assert "content_filter" in result["guardrail_flags"]
    assert result["needs_handoff"] is True
    assert "guarantee" not in result["final_answer"].lower()


def test_intent_node_heuristic_fallback_classifies_booking_keywords() -> None:
    assert IntentNode._heuristic_classify("I'd like to book a table") == "booking"
    assert IntentNode._heuristic_classify("Can I speak to a human please") == "handoff"
    assert IntentNode._heuristic_classify("hi") == "chitchat"
    assert IntentNode._heuristic_classify("what's on the menu") == "faq"
