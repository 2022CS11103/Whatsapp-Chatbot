"""LangGraph state machine definition -- the heart of the agent.

    User Message
         v
   [intent_node]  <- classify: faq / rag / booking / lead / handoff / chitchat
         v
    route_after_intent
    /      |        \\
[retrieve_node] [respond_node] [ ]   (faq-with-match and booking/lead/handoff
    v              |            |     skip straight to guardrail_node -- see
[respond_node]     |            |     route_after_intent below)
    \\              |           /
     [guardrail_node]  <- hallucination check, content filter (code, not LLM)
         v
    Final Reply

Built fresh per request (see app/services/agent_service.py) rather
than once at import time: node instances close over request-scoped
dependencies (the business's chosen LLMProvider, its business_id, its
tenant-scoped repositories) that don't exist until a request arrives.
The graph *topology* is fixed; only the nodes' bound dependencies
change per call.

Node ids intentionally don't match AgentState field names (e.g. the
node is "intent_node", not "intent") -- LangGraph rejects add_node
calls whose name collides with a state key.
"""

from langgraph.graph import END, START, StateGraph
from langgraph.graph.state import CompiledStateGraph

from app.agents.nodes.guardrail_node import GuardrailNode
from app.agents.nodes.intent_node import IntentNode
from app.agents.nodes.response_node import ResponseNode
from app.agents.nodes.retrieve_node import RetrieveNode
from app.agents.state import AgentState


def route_after_intent(state: AgentState) -> str:
    intent = state.get("intent", "chitchat")
    if intent in ("booking", "lead", "handoff"):
        return "guardrail"
    if intent == "faq" and state.get("faq_answer"):
        return "guardrail"
    if intent == "rag":
        return "retrieve"
    return "respond"


def build_agent_graph(
    intent_node: IntentNode,
    retrieve_node: RetrieveNode,
    response_node: ResponseNode,
    guardrail_node: GuardrailNode,
) -> CompiledStateGraph:
    graph = StateGraph(AgentState)

    # Node ids are suffixed with "_node" so they never collide with an
    # AgentState field name (e.g. a node called "intent" would clash
    # with the state's "intent" key) -- LangGraph rejects that at
    # add_node time.
    graph.add_node("intent_node", intent_node)
    graph.add_node("retrieve_node", retrieve_node)
    graph.add_node("respond_node", response_node)
    graph.add_node("guardrail_node", guardrail_node)

    graph.add_edge(START, "intent_node")
    graph.add_conditional_edges(
        "intent_node",
        route_after_intent,
        {
            "retrieve": "retrieve_node",
            "respond": "respond_node",
            "guardrail": "guardrail_node",
        },
    )
    graph.add_edge("retrieve_node", "respond_node")
    graph.add_edge("respond_node", "guardrail_node")
    graph.add_edge("guardrail_node", END)

    return graph.compile()
