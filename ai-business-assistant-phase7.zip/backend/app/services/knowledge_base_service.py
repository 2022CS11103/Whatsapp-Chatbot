"""Knowledge base document business logic.

Upload only creates the Document row (status=pending) and saves the
raw file -- it does not parse or chunk synchronously, so the upload
request returns fast. Parsing happens in
app/jobs/ingestion_jobs.py:process_document, scheduled as a
FastAPI BackgroundTask by the router right after this service returns.
"""

from uuid import UUID

from app.models.document import Document, DocumentStatus
from app.repositories.document_repository import DocumentRepository
from app.services.storage_service import StorageService
from app.utils.exceptions import NotFoundError


class KnowledgeBaseService:
    def __init__(
        self, document_repository: DocumentRepository, storage_service: StorageService
    ) -> None:
        self._documents = document_repository
        self._storage = storage_service

    async def upload(
        self, business_id: UUID, filename: str, content_type: str, content: bytes
    ) -> Document:
        storage_path = await self._storage.save(business_id, filename, content)

        document = Document(
            business_id=business_id,
            filename=filename,
            content_type=content_type,
            storage_path=storage_path,
            status=DocumentStatus.PENDING,
        )
        await self._documents.add(document)
        await self._documents.commit()
        return document

    async def list_for_business(
        self, business_id: UUID, offset: int, limit: int
    ) -> tuple[list[Document], int]:
        return await self._documents.list_for_business(business_id, offset, limit)

    async def get(self, business_id: UUID, document_id: UUID) -> Document:
        document = await self._documents.get_by_id_for_business(document_id, business_id)
        if document is None:
            raise NotFoundError("Document not found")
        return document

    async def delete(self, business_id: UUID, document_id: UUID) -> None:
        document = await self.get(business_id, document_id)
        await self._storage.delete(document.storage_path)
        await self._documents.delete(document)
        await self._documents.commit()
