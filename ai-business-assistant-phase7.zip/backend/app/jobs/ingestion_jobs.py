"""Document ingestion: parse + chunk + embed + upsert to Qdrant.

Run as a FastAPI BackgroundTask after upload returns its response.

This function deliberately does NOT reuse the request's DB session or
dependency-injected repositories. FastAPI closes request-scoped
dependencies (like the DB session from get_db) once the response has
been sent, and a BackgroundTask runs after that point -- so it must
open its own fresh session.

Because that fresh session has no RLS context set yet, this function
sets app.current_business_id itself, using the business_id it was
explicitly handed by the (already-authorized) upload request. It does
not re-derive or re-check authorization -- the caller already proved
the uploading user owns this business before scheduling this task.

Embedding batching: chunks are embedded in batches of EMBED_BATCH_SIZE
to avoid hitting provider rate limits on large documents.
"""

import logging
import uuid
from uuid import UUID

from qdrant_client.models import PointStruct
from sqlalchemy import text

from app.config.settings import get_settings
from app.database.session import AsyncSessionFactory
from app.models.document import DocumentChunk, DocumentStatus
from app.rag.chunking import chunk_text
from app.rag.document_parsers.parser_factory import get_parser_for_content_type
from app.rag.embedding_factory import get_embedding_provider
from app.rag.qdrant_store import QdrantVectorStore
from app.repositories.document_repository import DocumentRepository
from app.services.storage_service import LocalStorageService

logger = logging.getLogger(__name__)

EMBED_BATCH_SIZE = 64  # chunks per embedding API call


async def process_document(document_id: UUID, business_id: UUID) -> None:
    settings = get_settings()
    storage = LocalStorageService(settings.STORAGE_DIR)

    async with AsyncSessionFactory() as session:
        await session.execute(
            text("SELECT set_config('app.current_business_id', :bid, true)"),
            {"bid": str(business_id)},
        )
        repo = DocumentRepository(session)

        document = await repo.get_by_id_for_business(document_id, business_id)
        if document is None:
            logger.error(
                "process_document: document %s not found for business %s",
                document_id,
                business_id,
            )
            return

        document.status = DocumentStatus.PROCESSING
        await repo.commit()

        try:
            # --- Step 1: Parse ---
            file_bytes = await storage.read(document.storage_path)
            parser = get_parser_for_content_type(document.content_type)
            text_content = parser.extract_text(file_bytes)
            chunks = chunk_text(text_content)

            if not chunks:
                raise ValueError("Document produced no text chunks after parsing")

            # --- Step 2: Persist chunks (qdrant_point_id = None for now) ---
            chunk_rows = [
                DocumentChunk(document_id=document.id, chunk_index=i, content=chunk)
                for i, chunk in enumerate(chunks)
            ]
            await repo.add_chunks(chunk_rows)
            await repo.commit()

            # --- Step 3: Embed + upsert to Qdrant ---
            # Skip if no API key configured (allows running without AI keys in dev)
            if not settings.OPENAI_API_KEY and not settings.GEMINI_API_KEY:
                logger.warning(
                    "No embedding API key set -- skipping vector embedding for document %s. "
                    "Set OPENAI_API_KEY or GEMINI_API_KEY to enable semantic search.",
                    document_id,
                )
                document.status = DocumentStatus.COMPLETED
                document.error_message = None
                await repo.commit()
                return

            embedder = get_embedding_provider(settings)
            vector_store = QdrantVectorStore(settings)
            await vector_store.create_collection_if_not_exists(business_id)

            qdrant_points: list[PointStruct] = []
            for batch_start in range(0, len(chunks), EMBED_BATCH_SIZE):
                batch_chunks = chunks[batch_start : batch_start + EMBED_BATCH_SIZE]
                batch_rows = chunk_rows[batch_start : batch_start + EMBED_BATCH_SIZE]

                vectors = await embedder.embed(batch_chunks)

                for chunk_row, vector in zip(batch_rows, vectors, strict=True):
                    point_id = str(uuid.uuid4())
                    chunk_row.qdrant_point_id = point_id
                    qdrant_points.append(
                        PointStruct(
                            id=point_id,
                            vector=vector,
                            payload={
                                "document_id": str(document.id),
                                "business_id": str(business_id),
                                "chunk_index": chunk_row.chunk_index,
                                "content": chunk_row.content,
                            },
                        )
                    )

            await vector_store.upsert(business_id, qdrant_points)
            await repo.commit()  # persist qdrant_point_ids on chunk rows

            document.status = DocumentStatus.COMPLETED
            document.error_message = None
            await repo.commit()

        except Exception as exc:  # noqa: BLE001 -- any failure must not crash the worker
            logger.exception("process_document failed for document %s", document_id)
            document.status = DocumentStatus.FAILED
            document.error_message = str(exc)[:2000]
            await repo.commit()
