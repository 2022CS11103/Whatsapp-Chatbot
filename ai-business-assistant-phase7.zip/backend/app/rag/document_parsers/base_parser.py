"""Document parser interface. Each supported file type implements this
so KnowledgeBaseService/ingestion job stay generic across formats."""

from abc import ABC, abstractmethod


class DocumentParser(ABC):
    @abstractmethod
    def extract_text(self, file_bytes: bytes) -> str:
        """Returns plain text extracted from the file's raw bytes.

        Raises ValueError if the file cannot be parsed (corrupt,
        unsupported internal structure, etc).
        """
        raise NotImplementedError
