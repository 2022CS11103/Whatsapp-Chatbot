"""Unit tests for KnowledgeBaseService -- fakes only, no DB, no disk."""

import uuid

import pytest

from app.models.document import Document, DocumentStatus
from app.services.knowledge_base_service import KnowledgeBaseService
from app.utils.exceptions import NotFoundError


class FakeDocumentRepository:
    def __init__(self) -> None:
        self._items: dict[uuid.UUID, Document] = {}

    async def add(self, entity: Document) -> Document:
        entity.id = uuid.uuid4()
        self._items[entity.id] = entity
        return entity

    async def get_by_id_for_business(self, document_id: uuid.UUID, business_id: uuid.UUID):
        doc = self._items.get(document_id)
        if doc is not None and doc.business_id == business_id:
            return doc
        return None

    async def list_for_business(self, business_id: uuid.UUID, offset: int, limit: int):
        matching = [d for d in self._items.values() if d.business_id == business_id]
        return matching[offset : offset + limit], len(matching)

    async def delete(self, document: Document) -> None:
        self._items.pop(document.id, None)

    async def commit(self) -> None:
        pass


class FakeStorageService:
    def __init__(self) -> None:
        self.saved: dict[str, bytes] = {}
        self.deleted: list[str] = []

    async def save(self, business_id: uuid.UUID, filename: str, content: bytes) -> str:
        path = f"/fake/{business_id}/{filename}"
        self.saved[path] = content
        return path

    async def read(self, storage_path: str) -> bytes:
        return self.saved[storage_path]

    async def delete(self, storage_path: str) -> None:
        self.deleted.append(storage_path)
        self.saved.pop(storage_path, None)


@pytest.fixture
def storage() -> FakeStorageService:
    return FakeStorageService()


@pytest.fixture
def service(storage: FakeStorageService) -> KnowledgeBaseService:
    return KnowledgeBaseService(FakeDocumentRepository(), storage)


@pytest.mark.asyncio
async def test_upload_creates_pending_document(service: KnowledgeBaseService) -> None:
    business_id = uuid.uuid4()
    document = await service.upload(business_id, "menu.pdf", "application/pdf", b"%PDF-fake")

    assert document.business_id == business_id
    assert document.status == DocumentStatus.PENDING
    assert document.filename == "menu.pdf"


@pytest.mark.asyncio
async def test_upload_saves_to_storage(
    service: KnowledgeBaseService, storage: FakeStorageService
) -> None:
    business_id = uuid.uuid4()
    document = await service.upload(business_id, "notes.txt", "text/plain", b"hello world")

    assert storage.saved[document.storage_path] == b"hello world"


@pytest.mark.asyncio
async def test_list_for_business_excludes_other_businesses(
    service: KnowledgeBaseService,
) -> None:
    business_a = uuid.uuid4()
    business_b = uuid.uuid4()
    await service.upload(business_a, "a.txt", "text/plain", b"a")
    await service.upload(business_b, "b.txt", "text/plain", b"b")

    items, total = await service.list_for_business(business_a, offset=0, limit=20)

    assert total == 1
    assert items[0].filename == "a.txt"


@pytest.mark.asyncio
async def test_get_document_from_wrong_business_raises_not_found(
    service: KnowledgeBaseService,
) -> None:
    business_a = uuid.uuid4()
    business_b = uuid.uuid4()
    document = await service.upload(business_a, "a.txt", "text/plain", b"a")

    with pytest.raises(NotFoundError):
        await service.get(business_b, document.id)


@pytest.mark.asyncio
async def test_delete_removes_document_and_storage_file(
    service: KnowledgeBaseService, storage: FakeStorageService
) -> None:
    business_id = uuid.uuid4()
    document = await service.upload(business_id, "a.txt", "text/plain", b"a")

    await service.delete(business_id, document.id)

    assert document.storage_path in storage.deleted
    with pytest.raises(NotFoundError):
        await service.get(business_id, document.id)
