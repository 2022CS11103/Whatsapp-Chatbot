"""Authentication business logic.

This service is the single place register/login/refresh decisions are
made. It depends only on abstractions (repository + auth primitives),
which makes it fully testable with in-memory fakes — see
tests/unit/test_auth_service.py.
"""

from uuid import UUID

from app.auth.jwt_handler import JWTHandler, TokenType
from app.auth.password_hasher import PasswordHasher
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.schemas.auth_schema import RegisterRequest, TokenResponse
from app.utils.exceptions import (
    DuplicateResourceError,
    InactiveUserError,
    InvalidCredentialsError,
    NotFoundError,
)


class AuthService:
    def __init__(
        self,
        user_repository: UserRepository,
        password_hasher: PasswordHasher,
        jwt_handler: JWTHandler,
    ) -> None:
        self._users = user_repository
        self._hasher = password_hasher
        self._jwt = jwt_handler

    async def register(self, payload: RegisterRequest) -> User:
        existing = await self._users.get_by_email(payload.email)
        if existing is not None:
            raise DuplicateResourceError("An account with this email already exists")

        user = User(
            email=payload.email,
            hashed_password=self._hasher.hash(payload.password),
            full_name=payload.full_name,
        )
        await self._users.add(user)
        await self._users.commit()
        return user

    async def authenticate(self, email: str, password: str) -> TokenResponse:
        user = await self._users.get_by_email(email)
        if user is None or not self._hasher.verify(password, user.hashed_password):
            raise InvalidCredentialsError("Incorrect email or password")
        if not user.is_active:
            raise InactiveUserError("This account has been deactivated")

        return self._issue_tokens(user.id)

    async def refresh(self, refresh_token: str) -> TokenResponse:
        user_id = self._jwt.decode(refresh_token, expected_type=TokenType.REFRESH)
        user = await self._users.get_by_id(user_id)
        if user is None or not user.is_active:
            raise InvalidCredentialsError("Account no longer available")

        return self._issue_tokens(user.id)

    async def get_current_user(self, access_token: str) -> User:
        user_id = self._jwt.decode(access_token, expected_type=TokenType.ACCESS)
        user = await self._users.get_by_id(user_id)
        if user is None:
            raise NotFoundError("User not found")
        if not user.is_active:
            raise InactiveUserError("This account has been deactivated")
        return user

    def _issue_tokens(self, user_id: UUID) -> TokenResponse:
        return TokenResponse(
            access_token=self._jwt.create_access_token(user_id),
            refresh_token=self._jwt.create_refresh_token(user_id),
        )
