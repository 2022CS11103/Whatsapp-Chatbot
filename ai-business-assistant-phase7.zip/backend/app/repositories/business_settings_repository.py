"""BusinessSettings-specific persistence queries."""

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.business_settings import BusinessSettings
from app.repositories.base_repository import BaseRepository


class BusinessSettingsRepository(BaseRepository[BusinessSettings]):
    model = BusinessSettings

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session)

    async def get_by_business_id(self, business_id: UUID) -> BusinessSettings | None:
        result = await self._session.execute(
            select(BusinessSettings).where(BusinessSettings.business_id == business_id)
        )
        return result.scalar_one_or_none()
