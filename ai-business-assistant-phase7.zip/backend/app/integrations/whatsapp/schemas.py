"""Pydantic models for the Meta WhatsApp Cloud API webhook payload.

Only the fields this app actually reads are modeled -- Meta's payload
carries a lot more (contact profile names, message context/replies,
media, reactions, delivery-status updates interleaved with messages)
that we deliberately ignore for Phase 7's text-only MVP. Everything
unmodeled is silently dropped by Pydantic rather than raising, which
is what we want: a webhook parser should never 500 on a shape it
doesn't handle yet, since Meta interprets sustained failures as "this
endpoint is broken" and disables the subscription.

Reference shape (trimmed to what we model):

{
  "entry": [{
    "changes": [{
      "value": {
        "metadata": {
          "phone_number_id": "1234567890",
          "display_phone_number": "15551234567"
        },
        "messages": [{
          "from": "15559876543",
          "id": "wamid.abc123",
          "type": "text",
          "text": {"body": "What are your hours?"}
        }]
      }
    }]
  }]
}
"""

from pydantic import BaseModel, Field


class WhatsAppTextBody(BaseModel):
    body: str


class WhatsAppInboundMessage(BaseModel):
    id: str
    from_: str = Field(alias="from")
    type: str
    text: WhatsAppTextBody | None = None

    model_config = {"populate_by_name": True}


class WhatsAppMetadata(BaseModel):
    phone_number_id: str
    display_phone_number: str


class WhatsAppChangeValue(BaseModel):
    metadata: WhatsAppMetadata
    messages: list[WhatsAppInboundMessage] = Field(default_factory=list)


class WhatsAppChange(BaseModel):
    value: WhatsAppChangeValue


class WhatsAppEntry(BaseModel):
    changes: list[WhatsAppChange] = Field(default_factory=list)


class WhatsAppWebhookPayload(BaseModel):
    entry: list[WhatsAppEntry] = Field(default_factory=list)

    def iter_text_messages(self) -> list[tuple[WhatsAppMetadata, WhatsAppInboundMessage]]:
        """Flattens the nested entry/changes/messages structure into
        (metadata, message) pairs for text messages only -- status
        updates (delivery/read receipts) and non-text message types
        have no `.text`, and callers should decide separately whether
        to acknowledge or reply to those.
        """
        pairs: list[tuple[WhatsAppMetadata, WhatsAppInboundMessage]] = []
        for entry in self.entry:
            for change in entry.changes:
                for message in change.value.messages:
                    pairs.append((change.value.metadata, message))
        return pairs
