"""Unit tests for BusinessService — fakes only, no DB."""

import uuid

import pytest

from app.models.business import Business, BusinessStatus, IndustryType
from app.models.business_settings import DEFAULT_BUSINESS_HOURS, BusinessSettings
from app.models.user import User, UserRole
from app.schemas.business_schema import (
    BusinessCreateRequest,
    BusinessSettingsUpdateRequest,
    BusinessUpdateRequest,
)
from app.services.business_service import BusinessService
from app.utils.exceptions import NotFoundError, PermissionDeniedError


class FakeBusinessRepository:
    def __init__(self) -> None:
        self._items: dict[uuid.UUID, Business] = {}

    async def add(self, entity: Business) -> Business:
        entity.id = uuid.uuid4()
        self._items[entity.id] = entity
        return entity

    async def get_by_id(self, entity_id: uuid.UUID) -> Business | None:
        return self._items.get(entity_id)

    async def list_for_owner(self, owner_id, offset, limit):
        owned = [b for b in self._items.values() if b.owner_id == owner_id]
        return owned[offset : offset + limit], len(owned)

    async def list_all(self, offset, limit):
        all_items = list(self._items.values())
        return all_items[offset : offset + limit], len(all_items)

    async def delete(self, business: Business) -> None:
        self._items.pop(business.id, None)

    async def commit(self) -> None:
        pass


class FakeBusinessSettingsRepository:
    def __init__(self) -> None:
        self._items: dict[uuid.UUID, BusinessSettings] = {}

    async def add(self, entity: BusinessSettings) -> BusinessSettings:
        entity.id = uuid.uuid4()
        self._items[entity.business_id] = entity
        return entity

    async def get_by_business_id(self, business_id: uuid.UUID) -> BusinessSettings | None:
        return self._items.get(business_id)

    async def commit(self) -> None:
        pass


@pytest.fixture
def service() -> BusinessService:
    return BusinessService(FakeBusinessRepository(), FakeBusinessSettingsRepository())


def make_user(role: UserRole = UserRole.OWNER) -> User:
    return User(
        id=uuid.uuid4(),
        email="owner@example.com",
        hashed_password="x",
        role=role,
        is_active=True,
    )


@pytest.mark.asyncio
async def test_create_business_also_creates_default_settings(service: BusinessService) -> None:
    owner = make_user()
    business = await service.create(
        owner, BusinessCreateRequest(name="Tasty Bites", industry_type=IndustryType.RESTAURANT)
    )

    assert business.owner_id == owner.id
    assert business.status == BusinessStatus.TRIAL

    settings = await service.get_settings(owner, business.id)
    assert settings.default_language == "en"
    assert settings.business_hours == DEFAULT_BUSINESS_HOURS


@pytest.mark.asyncio
async def test_owner_cannot_access_other_owners_business(service: BusinessService) -> None:
    owner_a = make_user()
    owner_b = make_user()
    business = await service.create(
        owner_a, BusinessCreateRequest(name="A's Gym", industry_type=IndustryType.GYM)
    )

    with pytest.raises(PermissionDeniedError):
        await service.get(owner_b, business.id)


@pytest.mark.asyncio
async def test_admin_can_access_any_business(service: BusinessService) -> None:
    owner = make_user()
    admin = make_user(role=UserRole.ADMIN)
    business = await service.create(
        owner, BusinessCreateRequest(name="Zen Salon", industry_type=IndustryType.SALON)
    )

    fetched = await service.get(admin, business.id)
    assert fetched.id == business.id


@pytest.mark.asyncio
async def test_get_nonexistent_business_raises_not_found(service: BusinessService) -> None:
    owner = make_user()
    with pytest.raises(NotFoundError):
        await service.get(owner, uuid.uuid4())


@pytest.mark.asyncio
async def test_update_business_applies_only_provided_fields(service: BusinessService) -> None:
    owner = make_user()
    business = await service.create(
        owner, BusinessCreateRequest(name="Old Name", industry_type=IndustryType.CLINIC)
    )

    updated = await service.update(owner, business.id, BusinessUpdateRequest(name="New Name"))

    assert updated.name == "New Name"
    assert updated.industry_type == IndustryType.CLINIC  # untouched


@pytest.mark.asyncio
async def test_update_business_by_non_owner_raises_permission_denied(
    service: BusinessService,
) -> None:
    owner = make_user()
    intruder = make_user()
    business = await service.create(
        owner, BusinessCreateRequest(name="Mine", industry_type=IndustryType.GYM)
    )

    with pytest.raises(PermissionDeniedError):
        await service.update(intruder, business.id, BusinessUpdateRequest(name="Hijacked"))


@pytest.mark.asyncio
async def test_delete_business_removes_it(service: BusinessService) -> None:
    owner = make_user()
    business = await service.create(
        owner, BusinessCreateRequest(name="Temp", industry_type=IndustryType.OTHER)
    )

    await service.delete(owner, business.id)

    with pytest.raises(NotFoundError):
        await service.get(owner, business.id)


@pytest.mark.asyncio
async def test_update_settings_applies_only_provided_fields(service: BusinessService) -> None:
    owner = make_user()
    business = await service.create(
        owner, BusinessCreateRequest(name="Coach Co", industry_type=IndustryType.COACHING_INSTITUTE)
    )

    updated = await service.update_settings(
        owner, business.id, BusinessSettingsUpdateRequest(handoff_enabled=False)
    )

    assert updated.handoff_enabled is False
    assert updated.default_language == "en"  # untouched


@pytest.mark.asyncio
async def test_list_for_user_only_returns_owned_businesses(service: BusinessService) -> None:
    owner_a = make_user()
    owner_b = make_user()
    await service.create(owner_a, BusinessCreateRequest(name="A1", industry_type=IndustryType.GYM))
    await service.create(owner_a, BusinessCreateRequest(name="A2", industry_type=IndustryType.GYM))
    await service.create(owner_b, BusinessCreateRequest(name="B1", industry_type=IndustryType.GYM))

    items, total = await service.list_for_user(owner_a, offset=0, limit=20)

    assert total == 2
    assert {b.name for b in items} == {"A1", "A2"}


@pytest.mark.asyncio
async def test_list_for_user_admin_sees_all(service: BusinessService) -> None:
    owner_a = make_user()
    owner_b = make_user()
    admin = make_user(role=UserRole.ADMIN)
    await service.create(owner_a, BusinessCreateRequest(name="A1", industry_type=IndustryType.GYM))
    await service.create(owner_b, BusinessCreateRequest(name="B1", industry_type=IndustryType.GYM))

    items, total = await service.list_for_user(admin, offset=0, limit=20)

    assert total == 2
