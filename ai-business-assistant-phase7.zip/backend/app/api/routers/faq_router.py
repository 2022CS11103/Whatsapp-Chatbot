"""FAQ endpoints, nested under a specific business."""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, status

from app.api.deps import OwnedBusinessDep, get_faq_service
from app.models.faq import FAQ
from app.schemas.common_schema import PaginatedResponse
from app.schemas.faq_schema import (
    FAQBulkCreateRequest,
    FAQCreateRequest,
    FAQResponse,
    FAQUpdateRequest,
)
from app.services.faq_service import FAQService
from app.utils.pagination import PaginationParams, pagination_params

router = APIRouter(prefix="/businesses/{business_id}/faqs", tags=["faqs"])

FAQServiceDep = Annotated[FAQService, Depends(get_faq_service)]
PaginationDep = Annotated[PaginationParams, Depends(pagination_params)]


@router.post("", response_model=FAQResponse, status_code=status.HTTP_201_CREATED)
async def create_faq(
    business_id: UUID,
    payload: FAQCreateRequest,
    owned_business: OwnedBusinessDep,
    faq_service: FAQServiceDep,
) -> FAQ:
    return await faq_service.create(owned_business.id, payload)


@router.post("/bulk", response_model=list[FAQResponse], status_code=status.HTTP_201_CREATED)
async def bulk_create_faqs(
    business_id: UUID,
    payload: FAQBulkCreateRequest,
    owned_business: OwnedBusinessDep,
    faq_service: FAQServiceDep,
) -> list[FAQ]:
    return await faq_service.bulk_create(owned_business.id, payload.faqs)


@router.get("", response_model=PaginatedResponse[FAQResponse])
async def list_faqs(
    business_id: UUID,
    owned_business: OwnedBusinessDep,
    faq_service: FAQServiceDep,
    pagination: PaginationDep,
) -> PaginatedResponse[FAQResponse]:
    items, total = await faq_service.list_for_business(
        owned_business.id, pagination.offset, pagination.page_size
    )
    return PaginatedResponse(
        items=[FAQResponse.model_validate(item) for item in items],
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
    )


@router.get("/{faq_id}", response_model=FAQResponse)
async def get_faq(
    business_id: UUID,
    faq_id: UUID,
    owned_business: OwnedBusinessDep,
    faq_service: FAQServiceDep,
) -> FAQ:
    return await faq_service.get(owned_business.id, faq_id)


@router.patch("/{faq_id}", response_model=FAQResponse)
async def update_faq(
    business_id: UUID,
    faq_id: UUID,
    payload: FAQUpdateRequest,
    owned_business: OwnedBusinessDep,
    faq_service: FAQServiceDep,
) -> FAQ:
    return await faq_service.update(owned_business.id, faq_id, payload)


@router.delete("/{faq_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_faq(
    business_id: UUID,
    faq_id: UUID,
    owned_business: OwnedBusinessDep,
    faq_service: FAQServiceDep,
) -> None:
    await faq_service.delete(owned_business.id, faq_id)
