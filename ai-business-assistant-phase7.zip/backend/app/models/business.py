"""Business model — the tenant root. Every business-scoped table in
later phases (FAQ, documents, conversations, leads) carries a
business_id pointing here, and is protected by an RLS policy that
checks app.current_business_id.

This table itself is scoped differently: by owner_id, since a
business has no parent tenant above it. See migrations/versions for
the corresponding RLS policy.
"""

import enum
import uuid
from typing import TYPE_CHECKING

from sqlalchemy import Enum, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base_class import Base
from app.models.mixins import TimestampMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.models.business_settings import BusinessSettings


class IndustryType(str, enum.Enum):
    RESTAURANT = "restaurant"
    CLINIC = "clinic"
    GYM = "gym"
    SALON = "salon"
    TRAVEL_AGENCY = "travel_agency"
    REAL_ESTATE = "real_estate"
    COACHING_INSTITUTE = "coaching_institute"
    OTHER = "other"


class BusinessStatus(str, enum.Enum):
    TRIAL = "trial"
    ACTIVE = "active"
    INACTIVE = "inactive"


class Business(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "businesses"

    owner_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    industry_type: Mapped[IndustryType] = mapped_column(
        Enum(IndustryType, name="industry_type", native_enum=False, length=32), nullable=False
    )
    whatsapp_number: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[BusinessStatus] = mapped_column(
        Enum(BusinessStatus, name="business_status", native_enum=False, length=16),
        default=BusinessStatus.TRIAL,
        nullable=False,
    )

    settings: Mapped["BusinessSettings"] = relationship(
        back_populates="business", uselist=False, cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Business id={self.id} name={self.name!r}>"
