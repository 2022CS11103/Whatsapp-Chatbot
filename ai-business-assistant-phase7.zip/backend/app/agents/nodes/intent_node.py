"""intent_node: classifies the user's message into one of the agent's
supported intents, and -- since FAQ is checked before RAG (a direct DB
match is cheaper and more precise than a vector search) -- also does
the FAQ lookup itself when the intent looks like "faq".

Classification is LLM-first with a keyword-heuristic fallback: if the
LLM call fails (provider outage, rate limit) or returns something
outside the known intent set, we fall back rather than let the whole
turn fail.
"""

import uuid
from typing import Any

from app.agents.providers.base_provider import LLMProvider
from app.agents.state import AgentState
from app.prompts.system_prompts import INTENT_CLASSIFICATION_PROMPT
from app.repositories.faq_repository import FAQRepository

VALID_INTENTS = frozenset({"faq", "rag", "booking", "lead", "handoff", "chitchat"})

_BOOKING_KEYWORDS = ("book", "reserve", "reservation", "schedule", "appointment", "slot")
_LEAD_KEYWORDS = ("call me", "contact me", "my number is", "interested in", "sign me up")
_HANDOFF_KEYWORDS = ("human", "agent", "representative", "speak to someone", "not helpful")
_GREETING_KEYWORDS = ("hi", "hello", "hey", "thanks", "thank you", "good morning", "good evening")


class IntentNode:
    def __init__(
        self,
        llm_provider: LLMProvider,
        faq_repository: FAQRepository,
        business_id: uuid.UUID,
    ) -> None:
        self._llm = llm_provider
        self._faqs = faq_repository
        self._business_id = business_id

    async def __call__(self, state: AgentState) -> dict[str, Any]:
        message = state["user_message"]
        intent = await self._classify(message)

        faq_answer: str | None = None
        if intent == "faq":
            matches = await self._faqs.search_for_business(self._business_id, message)
            faq_answer = matches[0].answer if matches else None
            if faq_answer is None:
                # No direct match after all -- fall through to a
                # normal knowledge-base lookup instead of dead-ending.
                intent = "rag"

        return {"intent": intent, "faq_answer": faq_answer}

    async def _classify(self, message: str) -> str:
        try:
            raw = await self._llm.complete(
                system_prompt=INTENT_CLASSIFICATION_PROMPT,
                history=[{"role": "user", "content": message}],
                max_tokens=10,
            )
        except Exception:
            return self._heuristic_classify(message)

        intent = raw.strip().lower().strip(".")
        return intent if intent in VALID_INTENTS else self._heuristic_classify(message)

    @staticmethod
    def _heuristic_classify(message: str) -> str:
        lowered = message.lower()
        if any(keyword in lowered for keyword in _HANDOFF_KEYWORDS):
            return "handoff"
        if any(keyword in lowered for keyword in _BOOKING_KEYWORDS):
            return "booking"
        if any(keyword in lowered for keyword in _LEAD_KEYWORDS):
            return "lead"
        if any(keyword in lowered for keyword in _GREETING_KEYWORDS) and len(lowered.split()) <= 4:
            return "chitchat"
        return "faq"
