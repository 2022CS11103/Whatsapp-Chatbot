#!/usr/bin/env bash
# Smoke-test / documentation script for the Business CRUD API (Phase 2).
# Demonstrates tenant isolation: Owner B cannot see or access Owner A's business.
# Usage: ./scripts/curl_examples_business.sh [base_url]
set -euo pipefail

BASE_URL="${1:-http://localhost:8000}/api/v1"
STAMP=$(date +%s)
EMAIL_A="ownerA-$STAMP@example.com"
EMAIL_B="ownerB-$STAMP@example.com"
PASSWORD="securepass123"

register_and_login() {
  local email="$1"
  curl -s -X POST "$BASE_URL/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"$email\",\"password\":\"$PASSWORD\"}" > /dev/null
  curl -s -X POST "$BASE_URL/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"$email\",\"password\":\"$PASSWORD\"}"
}

echo "==> Registering two separate owners"
register_and_login "$EMAIL_A" > /tmp/login_a.json
register_and_login "$EMAIL_B" > /tmp/login_b.json
TOKEN_A=$(python3 -c "import json; print(json.load(open('/tmp/login_a.json'))['access_token'])")
TOKEN_B=$(python3 -c "import json; print(json.load(open('/tmp/login_b.json'))['access_token'])")

echo "==> Owner A creates a business"
curl -s -X POST "$BASE_URL/businesses" \
  -H "Authorization: Bearer $TOKEN_A" -H "Content-Type: application/json" \
  -d '{"name":"Tasty Bites","industry_type":"restaurant","whatsapp_number":"+919999999999"}' | tee /tmp/business.json
echo -e "\n"
BUSINESS_ID=$(python3 -c "import json; print(json.load(open('/tmp/business.json'))['id'])")

echo "==> Owner A lists their businesses (expect 1)"
curl -s "$BASE_URL/businesses" -H "Authorization: Bearer $TOKEN_A"
echo -e "\n"

echo "==> Owner B lists their businesses (expect 0 -- tenant isolation)"
curl -s "$BASE_URL/businesses" -H "Authorization: Bearer $TOKEN_B"
echo -e "\n"

echo "==> Owner B tries to fetch Owner A's business directly by ID (expect 403)"
curl -s -w "\nHTTP %{http_code}\n" "$BASE_URL/businesses/$BUSINESS_ID" -H "Authorization: Bearer $TOKEN_B"

echo "==> Owner A fetches their own business settings (auto-created defaults)"
curl -s "$BASE_URL/businesses/$BUSINESS_ID/settings" -H "Authorization: Bearer $TOKEN_A"
echo -e "\n"

echo "==> Owner A updates settings (disable handoff)"
curl -s -X PATCH "$BASE_URL/businesses/$BUSINESS_ID/settings" \
  -H "Authorization: Bearer $TOKEN_A" -H "Content-Type: application/json" \
  -d '{"handoff_enabled": false}'
echo -e "\n"

echo "==> Owner A deletes the business"
curl -s -o /dev/null -w "HTTP %{http_code}\n" -X DELETE "$BASE_URL/businesses/$BUSINESS_ID" \
  -H "Authorization: Bearer $TOKEN_A"
