"""FAQ business logic.

Unlike BusinessService, this service does NOT re-check ownership --
that already happened in api/deps.py:get_owned_business before this
service is even constructed for the request. This service trusts the
business_id it's given is one the caller is authorized for, and relies
on the FAQ table's RLS policy as the independent enforcement layer.
"""

from uuid import UUID

from app.models.faq import FAQ
from app.repositories.faq_repository import FAQRepository
from app.schemas.faq_schema import FAQCreateRequest, FAQUpdateRequest
from app.utils.exceptions import NotFoundError


class FAQService:
    def __init__(self, faq_repository: FAQRepository) -> None:
        self._faqs = faq_repository

    async def create(self, business_id: UUID, payload: FAQCreateRequest) -> FAQ:
        faq = FAQ(
            business_id=business_id,
            question=payload.question,
            answer=payload.answer,
            category=payload.category,
        )
        await self._faqs.add(faq)
        await self._faqs.commit()
        return faq

    async def bulk_create(self, business_id: UUID, payloads: list[FAQCreateRequest]) -> list[FAQ]:
        faqs = [
            FAQ(
                business_id=business_id,
                question=p.question,
                answer=p.answer,
                category=p.category,
            )
            for p in payloads
        ]
        await self._faqs.add_many(faqs)
        await self._faqs.commit()
        return faqs

    async def list_for_business(
        self, business_id: UUID, offset: int, limit: int
    ) -> tuple[list[FAQ], int]:
        return await self._faqs.list_for_business(business_id, offset, limit)

    async def get(self, business_id: UUID, faq_id: UUID) -> FAQ:
        faq = await self._faqs.get_by_id_for_business(faq_id, business_id)
        if faq is None:
            raise NotFoundError("FAQ not found")
        return faq

    async def update(self, business_id: UUID, faq_id: UUID, payload: FAQUpdateRequest) -> FAQ:
        faq = await self.get(business_id, faq_id)

        update_data = payload.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(faq, field, value)

        await self._faqs.commit()
        return faq

    async def delete(self, business_id: UUID, faq_id: UUID) -> None:
        faq = await self.get(business_id, faq_id)
        await self._faqs.delete(faq)
        await self._faqs.commit()
