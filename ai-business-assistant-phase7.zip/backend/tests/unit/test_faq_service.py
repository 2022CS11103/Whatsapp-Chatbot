"""Unit tests for FAQService -- fakes only, no DB."""

import uuid

import pytest

from app.models.faq import FAQ
from app.schemas.faq_schema import FAQCreateRequest, FAQUpdateRequest
from app.services.faq_service import FAQService
from app.utils.exceptions import NotFoundError


class FakeFAQRepository:
    def __init__(self) -> None:
        self._items: dict[uuid.UUID, FAQ] = {}

    async def add(self, entity: FAQ) -> FAQ:
        entity.id = uuid.uuid4()
        self._items[entity.id] = entity
        return entity

    async def add_many(self, entities: list[FAQ]) -> list[FAQ]:
        for entity in entities:
            entity.id = uuid.uuid4()
            self._items[entity.id] = entity
        return entities

    async def get_by_id_for_business(self, faq_id: uuid.UUID, business_id: uuid.UUID):
        faq = self._items.get(faq_id)
        if faq is not None and faq.business_id == business_id:
            return faq
        return None

    async def list_for_business(self, business_id: uuid.UUID, offset: int, limit: int):
        matching = [f for f in self._items.values() if f.business_id == business_id]
        return matching[offset : offset + limit], len(matching)

    async def delete(self, faq: FAQ) -> None:
        self._items.pop(faq.id, None)

    async def commit(self) -> None:
        pass


@pytest.fixture
def service() -> FAQService:
    return FAQService(FakeFAQRepository())


@pytest.mark.asyncio
async def test_create_faq(service: FAQService) -> None:
    business_id = uuid.uuid4()
    faq = await service.create(
        business_id, FAQCreateRequest(question="What are your hours?", answer="9-6 daily")
    )

    assert faq.business_id == business_id
    assert faq.question == "What are your hours?"


@pytest.mark.asyncio
async def test_bulk_create_faqs(service: FAQService) -> None:
    business_id = uuid.uuid4()
    payloads = [
        FAQCreateRequest(question="Q1", answer="A1"),
        FAQCreateRequest(question="Q2", answer="A2"),
    ]

    created = await service.bulk_create(business_id, payloads)

    assert len(created) == 2
    assert all(f.business_id == business_id for f in created)


@pytest.mark.asyncio
async def test_list_for_business_excludes_other_businesses(service: FAQService) -> None:
    business_a = uuid.uuid4()
    business_b = uuid.uuid4()
    await service.create(business_a, FAQCreateRequest(question="A-Q", answer="A-A"))
    await service.create(business_b, FAQCreateRequest(question="B-Q", answer="B-A"))

    items, total = await service.list_for_business(business_a, offset=0, limit=20)

    assert total == 1
    assert items[0].question == "A-Q"


@pytest.mark.asyncio
async def test_get_faq_from_wrong_business_raises_not_found(service: FAQService) -> None:
    business_a = uuid.uuid4()
    business_b = uuid.uuid4()
    faq = await service.create(business_a, FAQCreateRequest(question="Q", answer="A"))

    with pytest.raises(NotFoundError):
        await service.get(business_b, faq.id)


@pytest.mark.asyncio
async def test_update_faq_applies_only_provided_fields(service: FAQService) -> None:
    business_id = uuid.uuid4()
    faq = await service.create(business_id, FAQCreateRequest(question="Old Q", answer="Old A"))

    updated = await service.update(business_id, faq.id, FAQUpdateRequest(answer="New A"))

    assert updated.answer == "New A"
    assert updated.question == "Old Q"


@pytest.mark.asyncio
async def test_delete_faq_removes_it(service: FAQService) -> None:
    business_id = uuid.uuid4()
    faq = await service.create(business_id, FAQCreateRequest(question="Q", answer="A"))

    await service.delete(business_id, faq.id)

    with pytest.raises(NotFoundError):
        await service.get(business_id, faq.id)
