"""Async database session management.

Exposes:
- get_db: plain session dependency, used by non-tenant-scoped routes
  (e.g. auth, admin).
- get_tenant_db: session dependency that additionally sets the
  Postgres session variable `app.current_business_id`, which RLS
  policies (added from Phase 2 onward) check via
  `current_setting('app.current_business_id')::uuid`. This is the
  defense-in-depth layer beneath the application-level tenant scoping
  middleware — even a bug in a repository's WHERE clause cannot leak
  cross-tenant rows once RLS is enabled on a table.
"""

from collections.abc import AsyncGenerator
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config.settings import get_settings

settings = get_settings()

engine = create_async_engine(
    str(settings.DATABASE_URL),
    pool_size=settings.DATABASE_POOL_SIZE,
    max_overflow=settings.DATABASE_MAX_OVERFLOW,
    echo=settings.DEBUG,
    pool_pre_ping=True,
)

AsyncSessionFactory = async_sessionmaker(
    bind=engine,
    autoflush=False,
    expire_on_commit=False,
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Plain session, no tenant context. Used for auth/admin routes."""
    async with AsyncSessionFactory() as session:
        yield session


async def get_tenant_db_factory(
    business_id: UUID,
) -> AsyncGenerator[AsyncSession, None]:
    """Session with `app.current_business_id` set for the transaction.

    Intended to be wrapped by a FastAPI dependency (see api/deps.py,
    introduced in Phase 2) that resolves `business_id` from the
    authenticated user's claims before yielding the session.
    """
    async with AsyncSessionFactory() as session:
        await session.execute(
            text("SELECT set_config('app.current_business_id', :business_id, true)"),
            {"business_id": str(business_id)},
        )
        yield session
