"""Integration tests for /api/v1/businesses/{id}/documents/* against
real Postgres, exercising the actual background ingestion pipeline."""

import asyncio

import pytest
from httpx import ASGITransport, AsyncClient

from app.database.base_class import Base
from app.database.session import engine
from app.main import app

pytestmark = pytest.mark.integration


@pytest.fixture(autouse=True)
async def _setup_database(tmp_path, monkeypatch):
    from app.config import settings as settings_module

    settings_module.get_settings.cache_clear()
    monkeypatch.setenv("STORAGE_DIR", str(tmp_path))
    settings_module.get_settings.cache_clear()

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()
    settings_module.get_settings.cache_clear()


@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


async def _register_login_and_create_business(
    client: AsyncClient, email: str, business_name: str
) -> tuple[str, str]:
    await client.post("/api/v1/auth/register", json={"email": email, "password": "supersecure123"})
    login_resp = await client.post(
        "/api/v1/auth/login", json={"email": email, "password": "supersecure123"}
    )
    token: str = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    biz_resp = await client.post(
        "/api/v1/businesses",
        json={"name": business_name, "industry_type": "restaurant"},
        headers=headers,
    )
    business_id: str = biz_resp.json()["id"]
    return token, business_id


async def _poll_until_terminal(
    client: AsyncClient, url: str, headers: dict, deadline_seconds: float = 5.0
):
    elapsed = 0.0
    while elapsed < deadline_seconds:
        resp = await client.get(url, headers=headers)
        status = resp.json()["status"]
        if status in ("completed", "failed"):
            return resp
        await asyncio.sleep(0.1)
        elapsed += 0.1
    raise TimeoutError(f"Document did not reach a terminal status within {deadline_seconds}s")


@pytest.mark.asyncio
async def test_upload_text_file_is_parsed_and_chunked(client: AsyncClient) -> None:
    token, business_id = await _register_login_and_create_business(
        client, "kb-owner@example.com", "KB Restaurant"
    )
    headers = {"Authorization": f"Bearer {token}"}

    content = ("Our restaurant serves Italian food. " * 100).encode("utf-8")
    upload_resp = await client.post(
        f"/api/v1/businesses/{business_id}/documents",
        headers=headers,
        files={"file": ("menu.txt", content, "text/plain")},
    )
    assert upload_resp.status_code == 202
    document_id = upload_resp.json()["id"]
    assert upload_resp.json()["status"] == "pending"

    final_resp = await _poll_until_terminal(
        client, f"/api/v1/businesses/{business_id}/documents/{document_id}/status", headers
    )
    assert final_resp.json()["status"] == "completed"
    assert final_resp.json()["error_message"] is None


@pytest.mark.asyncio
async def test_upload_unsupported_content_type_rejected(client: AsyncClient) -> None:
    token, business_id = await _register_login_and_create_business(
        client, "kb-reject@example.com", "Reject Test"
    )
    headers = {"Authorization": f"Bearer {token}"}

    resp = await client.post(
        f"/api/v1/businesses/{business_id}/documents",
        headers=headers,
        files={"file": ("image.jpg", b"fake image bytes", "image/jpeg")},
    )
    assert resp.status_code == 422
    assert resp.json()["error_code"] == "validation_failed"


@pytest.mark.asyncio
async def test_corrupt_pdf_marks_document_failed(client: AsyncClient) -> None:
    token, business_id = await _register_login_and_create_business(
        client, "kb-corrupt@example.com", "Corrupt Test"
    )
    headers = {"Authorization": f"Bearer {token}"}

    upload_resp = await client.post(
        f"/api/v1/businesses/{business_id}/documents",
        headers=headers,
        files={"file": ("fake.pdf", b"not a real pdf", "application/pdf")},
    )
    document_id = upload_resp.json()["id"]

    final_resp = await _poll_until_terminal(
        client, f"/api/v1/businesses/{business_id}/documents/{document_id}/status", headers
    )
    assert final_resp.json()["status"] == "failed"
    assert final_resp.json()["error_message"] is not None


@pytest.mark.asyncio
async def test_owner_cannot_access_another_owners_documents(client: AsyncClient) -> None:
    token_a, business_a = await _register_login_and_create_business(
        client, "kb-victim@example.com", "Victim Biz"
    )
    token_b, _ = await _register_login_and_create_business(
        client, "kb-intruder@example.com", "Intruder Biz"
    )

    await client.post(
        f"/api/v1/businesses/{business_a}/documents",
        headers={"Authorization": f"Bearer {token_a}"},
        files={"file": ("secret.txt", b"private content", "text/plain")},
    )

    list_resp = await client.get(
        f"/api/v1/businesses/{business_a}/documents",
        headers={"Authorization": f"Bearer {token_b}"},
    )
    assert list_resp.status_code == 403


@pytest.mark.asyncio
async def test_delete_document(client: AsyncClient) -> None:
    token, business_id = await _register_login_and_create_business(
        client, "kb-delete@example.com", "Delete Test"
    )
    headers = {"Authorization": f"Bearer {token}"}

    upload_resp = await client.post(
        f"/api/v1/businesses/{business_id}/documents",
        headers=headers,
        files={"file": ("temp.txt", b"temporary content", "text/plain")},
    )
    document_id = upload_resp.json()["id"]

    delete_resp = await client.delete(
        f"/api/v1/businesses/{business_id}/documents/{document_id}", headers=headers
    )
    assert delete_resp.status_code == 204

    get_resp = await client.get(
        f"/api/v1/businesses/{business_id}/documents/{document_id}", headers=headers
    )
    assert get_resp.status_code == 404
