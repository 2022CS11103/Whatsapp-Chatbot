"""response_node: generates the LLM-grounded reply.

Reached for two branches only: "rag" (after retrieve_node has filled
retrieved_chunks) and "chitchat"/anything else that isn't a direct FAQ
hit or a handoff. FAQ answers with a direct match skip this node
entirely -- see app/agents/graph.py -- since re-running them through
an LLM would add cost and hallucination risk for zero benefit.
"""

from typing import Any

from app.agents.providers.base_provider import LLMProvider
from app.agents.state import AgentState, CitationDict
from app.prompts.system_prompts import CHITCHAT_SYSTEM_PROMPT, RAG_ANSWER_SYSTEM_PROMPT


class ResponseNode:
    def __init__(
        self,
        llm_provider: LLMProvider,
        business_name: str,
        industry_type: str,
        max_output_tokens: int,
    ) -> None:
        self._llm = llm_provider
        self._business_name = business_name
        self._industry_type = industry_type
        self._max_output_tokens = max_output_tokens

    async def __call__(self, state: AgentState) -> dict[str, Any]:
        intent = state.get("intent", "chitchat")

        if intent == "rag":
            chunks = state.get("retrieved_chunks", [])
            context = "\n\n".join(f"[{i + 1}] {chunk['content']}" for i, chunk in enumerate(chunks))
            system_prompt = RAG_ANSWER_SYSTEM_PROMPT.format(
                business_name=self._business_name,
                industry_type=self._industry_type,
                context=context or "(no relevant context was found)",
            )
            citations: list[CitationDict] = [
                {
                    "document_id": chunk["document_id"],
                    "chunk_index": chunk["chunk_index"],
                    "score": chunk["score"],
                }
                for chunk in chunks
            ]
        else:
            system_prompt = CHITCHAT_SYSTEM_PROMPT.format(
                business_name=self._business_name,
                industry_type=self._industry_type,
            )
            citations = []

        history = [*state.get("history", []), {"role": "user", "content": state["user_message"]}]
        answer = await self._llm.complete(
            system_prompt=system_prompt,
            history=history,  # type: ignore[arg-type]
            max_tokens=self._max_output_tokens,
        )

        return {"draft_answer": answer, "citations": citations}
