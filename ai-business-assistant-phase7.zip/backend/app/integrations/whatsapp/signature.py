"""Verifies the X-Hub-Signature-256 header Meta attaches to every
webhook POST, proving the request actually came from Meta (using the
app secret both sides know) and wasn't forged by an attacker who
discovered the webhook URL.

Meta's format: header value is "sha256=<hex digest>", where the digest
is HMAC-SHA256(app_secret, raw_request_body). Verification MUST run
against the raw bytes as received -- re-serializing a parsed JSON body
can reorder keys or change whitespace and silently break the check.
"""

import hashlib
import hmac

_SIGNATURE_PREFIX = "sha256="


def verify_signature(payload: bytes, signature_header: str | None, app_secret: str) -> bool:
    if not signature_header or not signature_header.startswith(_SIGNATURE_PREFIX):
        return False

    provided_digest = signature_header[len(_SIGNATURE_PREFIX) :]
    expected_digest = hmac.new(app_secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()

    # constant-time comparison -- a naive `==` leaks timing info that
    # can be used to guess the correct digest one byte at a time.
    return hmac.compare_digest(provided_digest, expected_digest)
