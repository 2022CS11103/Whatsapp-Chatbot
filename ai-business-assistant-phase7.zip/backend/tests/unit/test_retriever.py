"""Unit tests for Retriever -- no Qdrant, no embedding API needed."""

import uuid

import pytest

from app.rag.retriever import RetrievedChunk, Retriever


class FakeEmbeddingProvider:
    """Always returns a fixed vector regardless of input."""

    def __init__(self, dimension: int = 4) -> None:
        self._dimension = dimension

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[1.0] * self._dimension for _ in texts]

    @property
    def dimension(self) -> int:
        return self._dimension


class FakeScoredPoint:
    def __init__(self, point_id: str, score: float, payload: dict) -> None:
        self.id = point_id
        self.score = score
        self.payload = payload


class FakeQdrantStore:
    def __init__(self, results: list[FakeScoredPoint]) -> None:
        self._results = results

    async def search(self, business_id, query_vector, top_k):
        return self._results[:top_k]


@pytest.fixture
def business_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.mark.asyncio
async def test_retriever_returns_chunks_above_threshold(business_id: uuid.UUID) -> None:
    fake_results = [
        FakeScoredPoint(
            "pt-1", 0.9, {"document_id": "doc-1", "chunk_index": 0, "content": "Great food"}
        ),
        FakeScoredPoint(
            "pt-2", 0.5, {"document_id": "doc-1", "chunk_index": 1, "content": "Open 9-6"}
        ),
        FakeScoredPoint(
            "pt-3", 0.1, {"document_id": "doc-1", "chunk_index": 2, "content": "Low relevance"}
        ),
    ]
    retriever = Retriever(FakeEmbeddingProvider(), FakeQdrantStore(fake_results))

    results = await retriever.retrieve("food hours", business_id, top_k=5, score_threshold=0.3)

    assert len(results) == 2
    assert results[0].score == 0.9
    assert results[1].score == 0.5


@pytest.mark.asyncio
async def test_retriever_filters_below_threshold(business_id: uuid.UUID) -> None:
    fake_results = [
        FakeScoredPoint(
            "pt-1", 0.2, {"document_id": "doc-1", "chunk_index": 0, "content": "irrelevant"}
        ),
    ]
    retriever = Retriever(FakeEmbeddingProvider(), FakeQdrantStore(fake_results))

    results = await retriever.retrieve("some query", business_id, score_threshold=0.3)

    assert results == []


@pytest.mark.asyncio
async def test_retriever_empty_results(business_id: uuid.UUID) -> None:
    retriever = Retriever(FakeEmbeddingProvider(), FakeQdrantStore([]))

    results = await retriever.retrieve("anything", business_id)

    assert results == []


@pytest.mark.asyncio
async def test_retrieved_chunk_has_correct_fields(business_id: uuid.UUID) -> None:
    fake_results = [
        FakeScoredPoint(
            "pt-abc",
            0.85,
            {"document_id": "doc-xyz", "chunk_index": 3, "content": "Specific info"},
        )
    ]
    retriever = Retriever(FakeEmbeddingProvider(), FakeQdrantStore(fake_results))

    results = await retriever.retrieve("query", business_id, score_threshold=0.0)

    assert len(results) == 1
    chunk = results[0]
    assert isinstance(chunk, RetrievedChunk)
    assert chunk.chunk_id == "pt-abc"
    assert chunk.document_id == "doc-xyz"
    assert chunk.chunk_index == 3
    assert chunk.content == "Specific info"
    assert chunk.score == 0.85
