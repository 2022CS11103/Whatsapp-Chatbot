"""Application exception hierarchy.

Services raise these; middleware/error_handler_middleware.py translates
them into HTTP responses. Services and repositories must never raise
raw HTTPException — that couples business logic to the web layer.
"""


class AppException(Exception):
    """Base class for all application-raised exceptions."""

    status_code: int = 500
    error_code: str = "internal_error"

    def __init__(self, message: str | None = None) -> None:
        self.message = message or self.__class__.__name__
        super().__init__(self.message)


class NotFoundError(AppException):
    status_code = 404
    error_code = "not_found"


class DuplicateResourceError(AppException):
    status_code = 409
    error_code = "duplicate_resource"


class InvalidCredentialsError(AppException):
    status_code = 401
    error_code = "invalid_credentials"


class TokenError(AppException):
    status_code = 401
    error_code = "invalid_token"


class InactiveUserError(AppException):
    status_code = 403
    error_code = "inactive_user"


class PermissionDeniedError(AppException):
    status_code = 403
    error_code = "permission_denied"


class ValidationFailedError(AppException):
    status_code = 422
    error_code = "validation_failed"
