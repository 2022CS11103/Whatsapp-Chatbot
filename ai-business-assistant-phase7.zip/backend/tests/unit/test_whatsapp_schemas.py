"""Unit tests for parsing the Meta WhatsApp Cloud API webhook payload
shape into (metadata, message) pairs.
"""

from app.integrations.whatsapp.schemas import WhatsAppWebhookPayload


def test_single_text_message_is_extracted() -> None:
    payload = WhatsAppWebhookPayload.model_validate(
        {
            "entry": [
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "123",
                                    "display_phone_number": "15551234567",
                                },
                                "messages": [
                                    {
                                        "from": "15559876543",
                                        "id": "wamid.abc",
                                        "type": "text",
                                        "text": {"body": "What are your hours?"},
                                    }
                                ],
                            }
                        }
                    ]
                }
            ]
        }
    )

    pairs = payload.iter_text_messages()

    assert len(pairs) == 1
    metadata, message = pairs[0]
    assert metadata.phone_number_id == "123"
    assert metadata.display_phone_number == "15551234567"
    assert message.from_ == "15559876543"
    assert message.type == "text"
    assert message.text is not None
    assert message.text.body == "What are your hours?"


def test_status_only_payload_yields_no_messages() -> None:
    """Delivery/read receipts carry metadata but no `messages` key at
    all -- this must not raise, just produce nothing to process."""
    payload = WhatsAppWebhookPayload.model_validate(
        {
            "entry": [
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "123",
                                    "display_phone_number": "15551234567",
                                }
                            }
                        }
                    ]
                }
            ]
        }
    )

    assert payload.iter_text_messages() == []


def test_empty_payload_yields_no_messages() -> None:
    assert WhatsAppWebhookPayload.model_validate({}).iter_text_messages() == []


def test_non_text_message_type_is_still_extracted_with_null_text() -> None:
    """Non-text types (image, audio, ...) still show up in the pairs --
    it's the caller's job (whatsapp_router) to check `.type` / `.text`
    and skip what it can't handle, not this parser's."""
    payload = WhatsAppWebhookPayload.model_validate(
        {
            "entry": [
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "123",
                                    "display_phone_number": "15551234567",
                                },
                                "messages": [
                                    {"from": "15559876543", "id": "wamid.img", "type": "image"}
                                ],
                            }
                        }
                    ]
                }
            ]
        }
    )

    pairs = payload.iter_text_messages()
    assert len(pairs) == 1
    _, message = pairs[0]
    assert message.type == "image"
    assert message.text is None


def test_multiple_entries_and_changes_are_all_flattened() -> None:
    payload = WhatsAppWebhookPayload.model_validate(
        {
            "entry": [
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "1",
                                    "display_phone_number": "111",
                                },
                                "messages": [
                                    {
                                        "from": "aaa",
                                        "id": "m1",
                                        "type": "text",
                                        "text": {"body": "hi"},
                                    }
                                ],
                            }
                        }
                    ]
                },
                {
                    "changes": [
                        {
                            "value": {
                                "metadata": {
                                    "phone_number_id": "2",
                                    "display_phone_number": "222",
                                },
                                "messages": [
                                    {
                                        "from": "bbb",
                                        "id": "m2",
                                        "type": "text",
                                        "text": {"body": "yo"},
                                    }
                                ],
                            }
                        }
                    ]
                },
            ]
        }
    )

    pairs = payload.iter_text_messages()
    assert len(pairs) == 2
    assert {p[1].from_ for p in pairs} == {"aaa", "bbb"}
