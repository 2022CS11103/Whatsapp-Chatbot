"""File handling helpers -- path safety, filename sanitization."""

import re
import uuid
from pathlib import Path


def sanitize_filename(filename: str) -> str:
    """Strips directory components and unsafe characters, so a
    user-supplied filename can never be used to write outside the
    intended storage directory (path traversal) or collide with
    reserved characters across platforms.
    """
    name = Path(filename).name  # strips any directory components
    name = re.sub(r"[^A-Za-z0-9._-]", "_", name)
    return name or "unnamed_file"


def build_storage_path(storage_dir: str, business_id: uuid.UUID, filename: str) -> Path:
    safe_name = sanitize_filename(filename)
    unique_prefix = uuid.uuid4().hex[:8]
    return Path(storage_dir) / str(business_id) / f"{unique_prefix}_{safe_name}"
