"""create businesses and business_settings tables, enable RLS on businesses

Revision ID: 0002
Revises: 0001
Create Date: 2026-06-30

RLS note: the policies below check `app.current_user_id` /
`app.current_user_role`, session variables set per-request by
app/api/deps.py:apply_tenant_context. `current_setting(..., true)`
returns NULL when unset rather than raising, so any request that
forgets to set tenant context sees zero rows -- a secure default,
not an error.

IMPORTANT: RLS is bypassed by the table owner / superuser role by
default. `FORCE ROW LEVEL SECURITY` makes policies apply even to the
table owner. In production, the application's DB role should NOT be
a superuser, and should not be the table owner either -- this is the
real guarantee; FORCE is a safety net during development against the
common case of running as postgres/superuser locally.
"""
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0002"
down_revision: str | None = "0001"
branch_labels: Sequence[str] | None = None
depends_on: Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "businesses",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "owner_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column(
            "industry_type",
            sa.Enum(
                "restaurant",
                "clinic",
                "gym",
                "salon",
                "travel_agency",
                "real_estate",
                "coaching_institute",
                "other",
                name="industry_type",
                native_enum=False,
                length=32,
            ),
            nullable=False,
        ),
        sa.Column("whatsapp_number", sa.String(length=32), nullable=True),
        sa.Column(
            "status",
            sa.Enum(
                "trial", "active", "inactive", name="business_status", native_enum=False, length=16
            ),
            nullable=False,
            server_default="trial",
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_businesses_owner_id", "businesses", ["owner_id"])

    op.create_table(
        "business_settings",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "business_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            unique=True,
            nullable=False,
        ),
        sa.Column("default_language", sa.String(length=10), nullable=False, server_default="en"),
        sa.Column(
            "llm_provider",
            sa.Enum(
                "openai", "gemini", "claude", name="llm_provider_choice", native_enum=False, length=16
            ),
            nullable=False,
            server_default="openai",
        ),
        sa.Column("business_hours", sa.JSON(), nullable=False),
        sa.Column("handoff_enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )

    # --- Row-Level Security on businesses ---
    op.execute("ALTER TABLE businesses ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE businesses FORCE ROW LEVEL SECURITY")

    op.execute(
        """
        CREATE POLICY business_select_policy ON businesses
        FOR SELECT
        USING (
            owner_id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR current_setting('app.current_user_role', true) = 'admin'
        )
        """
    )
    op.execute(
        """
        CREATE POLICY business_insert_policy ON businesses
        FOR INSERT
        WITH CHECK (
            owner_id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR current_setting('app.current_user_role', true) = 'admin'
        )
        """
    )
    op.execute(
        """
        CREATE POLICY business_update_policy ON businesses
        FOR UPDATE
        USING (
            owner_id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR current_setting('app.current_user_role', true) = 'admin'
        )
        WITH CHECK (
            owner_id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR current_setting('app.current_user_role', true) = 'admin'
        )
        """
    )
    op.execute(
        """
        CREATE POLICY business_delete_policy ON businesses
        FOR DELETE
        USING (
            owner_id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR current_setting('app.current_user_role', true) = 'admin'
        )
        """
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS business_delete_policy ON businesses")
    op.execute("DROP POLICY IF EXISTS business_update_policy ON businesses")
    op.execute("DROP POLICY IF EXISTS business_insert_policy ON businesses")
    op.execute("DROP POLICY IF EXISTS business_select_policy ON businesses")
    op.drop_table("business_settings")
    op.drop_index("ix_businesses_owner_id", table_name="businesses")
    op.drop_table("businesses")
