"""LLM chat provider interface.

Concrete implementations live alongside this file (openai_provider.py,
gemini_provider.py, claude_provider.py). Agent nodes (response_node,
intent_node) depend only on this interface, never on a concrete
class -- which provider is used is a per-business setting
(BusinessSettings.llm_provider), resolved once per request by
provider_factory.get_llm_provider.

This is deliberately a much narrower interface than each SDK's native
client: a single-turn "system prompt + message history in, text out"
call. Streaming, tool-calling, etc. are out of scope for Phase 6 --
add them here (not in the node code) if a later phase needs them, so
every provider implementation grows the same capability together.
"""

from abc import ABC, abstractmethod
from typing import TypedDict


class ChatTurn(TypedDict):
    role: str  # "user" | "assistant"
    content: str


class LLMProvider(ABC):
    @abstractmethod
    async def complete(
        self,
        system_prompt: str,
        history: list[ChatTurn],
        max_tokens: int = 1024,
    ) -> str:
        """Returns the model's text reply given a system prompt and
        prior turns (oldest first, ending with the latest user turn).
        """
        raise NotImplementedError
