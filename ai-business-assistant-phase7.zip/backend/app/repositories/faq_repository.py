"""FAQ-specific persistence queries."""

from uuid import UUID

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.faq import FAQ
from app.repositories.base_repository import BaseRepository


class FAQRepository(BaseRepository[FAQ]):
    model = FAQ

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session)

    async def search_for_business(self, business_id: UUID, query: str, limit: int = 3) -> list[FAQ]:
        """Cheap lexical match against FAQ questions, used by the AI
        agent's intent node before falling back to RAG (a direct FAQ
        hit is cheaper and more precise than a vector search).

        This is intentionally simple (ILIKE over individual words, not
        a ranked full-text or embedding search) -- FAQs are meant to
        be short, curated entries, so exact-ish phrase overlap is
        enough. Revisit with Postgres full-text search (tsvector) if
        businesses start reporting misses.
        """
        words = [w for w in query.split() if len(w) > 2][:8]
        if not words:
            return []

        conditions = [FAQ.question.ilike(f"%{word}%") for word in words]
        result = await self._session.execute(
            select(FAQ).where(FAQ.business_id == business_id, or_(*conditions)).limit(limit)
        )
        return list(result.scalars().all())

    async def list_for_business(
        self, business_id: UUID, offset: int, limit: int
    ) -> tuple[list[FAQ], int]:
        items_result = await self._session.execute(
            select(FAQ)
            .where(FAQ.business_id == business_id)
            .order_by(FAQ.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        count_result = await self._session.execute(
            select(func.count()).select_from(FAQ).where(FAQ.business_id == business_id)
        )
        return list(items_result.scalars().all()), count_result.scalar_one()

    async def get_by_id_for_business(self, faq_id: UUID, business_id: UUID) -> FAQ | None:
        result = await self._session.execute(
            select(FAQ).where(FAQ.id == faq_id, FAQ.business_id == business_id)
        )
        return result.scalar_one_or_none()

    async def add_many(self, entities: list[FAQ]) -> list[FAQ]:
        self._session.add_all(entities)
        await self._session.flush()
        return entities

    async def delete(self, faq: FAQ) -> None:
        await self._session.delete(faq)
        await self._session.flush()
