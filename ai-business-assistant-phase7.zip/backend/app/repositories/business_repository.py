"""Business-specific persistence queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.business import Business
from app.repositories.base_repository import BaseRepository


class BusinessRepository(BaseRepository[Business]):
    model = Business

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session)

    async def list_for_owner(
        self, owner_id: UUID, offset: int, limit: int
    ) -> tuple[list[Business], int]:
        items_result = await self._session.execute(
            select(Business)
            .where(Business.owner_id == owner_id)
            .order_by(Business.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        count_result = await self._session.execute(
            select(func.count()).select_from(Business).where(Business.owner_id == owner_id)
        )
        return list(items_result.scalars().all()), count_result.scalar_one()

    async def list_all(self, offset: int, limit: int) -> tuple[list[Business], int]:
        """Admin-only: list every business on the platform."""
        items_result = await self._session.execute(
            select(Business).order_by(Business.created_at.desc()).offset(offset).limit(limit)
        )
        count_result = await self._session.execute(select(func.count()).select_from(Business))
        return list(items_result.scalars().all()), count_result.scalar_one()

    async def get_by_whatsapp_number(self, whatsapp_number: str) -> Business | None:
        """Resolves the business that owns a given WhatsApp number, for
        routing inbound webhook messages (see app/jobs/whatsapp_jobs.py).

        Callers must set app.current_user_role='admin' on the session
        before calling this -- there is no authenticated user_id in a
        webhook request for the normal owner_id RLS check to match
        against, so this deliberately goes through businesses' RLS
        admin-bypass policy instead, the same mechanism list_all()
        above already relies on.
        """
        result = await self._session.execute(
            select(Business).where(Business.whatsapp_number == whatsapp_number)
        )
        return result.scalar_one_or_none()

    async def delete(self, business: Business) -> None:
        await self._session.delete(business)
        await self._session.flush()
