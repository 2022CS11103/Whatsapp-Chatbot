"""Unit tests for app.rag.chunking.chunk_text."""

import pytest

from app.rag.chunking import chunk_text


def test_empty_text_returns_no_chunks() -> None:
    assert chunk_text("   ") == []
    assert chunk_text("") == []


def test_short_text_returns_single_chunk() -> None:
    chunks = chunk_text("Hello world", chunk_size=1000, overlap=150)
    assert chunks == ["Hello world"]


def test_long_text_splits_into_multiple_overlapping_chunks() -> None:
    text = "A" * 2500
    chunks = chunk_text(text, chunk_size=1000, overlap=150)

    assert len(chunks) > 1
    # consecutive chunks should share overlapping content
    for chunk in chunks:
        assert len(chunk) <= 1000


def test_chunk_size_must_exceed_overlap() -> None:
    with pytest.raises(ValueError):
        chunk_text("some text", chunk_size=100, overlap=100)


def test_all_text_is_covered_no_gaps() -> None:
    text = "0123456789" * 50  # 500 chars, deterministic content
    chunks = chunk_text(text, chunk_size=100, overlap=20)

    # reconstruct coverage by checking the chunk size doesn't exceed
    # the requested size and that we get a sane number of chunks for
    # the input length / step size
    step = 100 - 20
    expected_min_chunks = (len(text) // step) - 1
    assert len(chunks) >= expected_min_chunks
