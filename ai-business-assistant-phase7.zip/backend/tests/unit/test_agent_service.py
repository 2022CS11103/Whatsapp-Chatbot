"""Unit tests for AgentService -- fakes only, no DB/Redis/LLM API.

These exercise the orchestration (conversation resolution, history
loading, persistence, memory updates) with a fully faked graph run,
not the graph's internal routing -- that's covered by
tests/unit/test_agent_graph.py.
"""

import uuid

import pytest

from app.models.business import Business, IndustryType
from app.models.conversation import Conversation, ConversationChannel, Message, MessageRole
from app.services.agent_service import AgentService


class FakeLLMProvider:
    async def complete(self, system_prompt, history, max_tokens=1024):
        return "irrelevant -- graph is not exercised via the real LLM in this test"


class FakeRetriever:
    async def retrieve(self, query, business_id, top_k=5, score_threshold=0.3):
        return []


class FakeFAQRepository:
    async def search_for_business(self, business_id, query, limit=3):
        return []


class FakeMemory:
    def __init__(self) -> None:
        self.history_by_conv: dict[str, list[dict]] = {}
        self.seeded: dict[str, list[dict]] = {}
        self.appended: list[tuple[str, str, str]] = []

    async def get_history(self, conversation_id: str):
        return self.history_by_conv.get(conversation_id, [])

    async def seed(self, conversation_id: str, turns):
        self.seeded[conversation_id] = turns

    async def append_turn(self, conversation_id: str, role: str, content: str) -> None:
        self.appended.append((conversation_id, role, content))


class FakeConversationRepository:
    def __init__(self) -> None:
        self.conversations: dict[uuid.UUID, Conversation] = {}
        self.messages: list[Message] = []
        self.committed = False

    async def get_or_create(
        self, business_id, external_user_ref, channel=ConversationChannel.WEB
    ) -> Conversation:
        for conv in self.conversations.values():
            if conv.business_id == business_id and conv.external_user_ref == external_user_ref:
                return conv
        conv = Conversation(
            id=uuid.uuid4(),
            business_id=business_id,
            external_user_ref=external_user_ref,
            channel=channel,
        )
        self.conversations[conv.id] = conv
        return conv

    async def get_recent_messages(self, conversation_id, limit: int):
        return [m for m in self.messages if m.conversation_id == conversation_id][-limit:]

    async def add_message(self, message: Message) -> Message:
        message.id = message.id or uuid.uuid4()
        self.messages.append(message)
        return message

    async def commit(self) -> None:
        self.committed = True


def _business() -> Business:
    return Business(
        id=uuid.uuid4(),
        owner_id=uuid.uuid4(),
        name="Test Cafe",
        industry_type=IndustryType.RESTAURANT,
    )


@pytest.fixture
def agent_service_parts():
    conversations = FakeConversationRepository()
    memory = FakeMemory()
    service = AgentService(
        llm_provider=FakeLLMProvider(),
        retriever=FakeRetriever(),
        faq_repository=FakeFAQRepository(),
        conversation_repository=conversations,
        memory=memory,
        agent_max_output_tokens=200,
        agent_rag_top_k=5,
        agent_rag_score_threshold=0.3,
    )
    return service, conversations, memory


@pytest.mark.asyncio
async def test_handle_message_creates_conversation_and_persists_messages(
    agent_service_parts,
) -> None:
    service, conversations, memory = agent_service_parts
    business = _business()

    response = await service.handle_message(business, "whatsapp:+15551234567", "hi there")

    assert response.conversation_id in conversations.conversations
    assert conversations.committed is True
    # user + assistant messages both persisted
    assert len(conversations.messages) == 2
    assert conversations.messages[0].role == MessageRole.USER
    assert conversations.messages[0].content == "hi there"
    assert conversations.messages[1].role == MessageRole.ASSISTANT
    assert conversations.messages[1].content == response.reply


@pytest.mark.asyncio
async def test_handle_message_reuses_existing_conversation_for_same_user(
    agent_service_parts,
) -> None:
    service, conversations, memory = agent_service_parts
    business = _business()

    first = await service.handle_message(business, "user-42", "first message")
    second = await service.handle_message(business, "user-42", "second message")

    assert first.conversation_id == second.conversation_id
    assert len(conversations.messages) == 4


@pytest.mark.asyncio
async def test_handle_message_updates_short_term_memory(agent_service_parts) -> None:
    service, conversations, memory = agent_service_parts
    business = _business()

    response = await service.handle_message(business, "user-1", "hello")

    roles_appended = [entry[1] for entry in memory.appended]
    assert roles_appended == ["user", "assistant"]
    assert memory.appended[0][2] == "hello"
    assert memory.appended[1][2] == response.reply


@pytest.mark.asyncio
async def test_handle_message_creates_whatsapp_conversation_with_correct_channel(
    agent_service_parts,
) -> None:
    service, conversations, memory = agent_service_parts
    business = _business()

    response = await service.handle_message(
        business,
        "15559876543",
        "hours?",
        channel=ConversationChannel.WHATSAPP,
    )

    created_conversation = conversations.conversations[response.conversation_id]
    assert created_conversation.channel == ConversationChannel.WHATSAPP
    assert created_conversation.external_user_ref == "15559876543"


@pytest.mark.asyncio
async def test_handle_message_defaults_to_web_channel_when_unspecified(
    agent_service_parts,
) -> None:
    service, conversations, memory = agent_service_parts
    business = _business()

    response = await service.handle_message(business, "web-session-1", "hi")

    created_conversation = conversations.conversations[response.conversation_id]
    assert created_conversation.channel == ConversationChannel.WEB
    service, conversations, memory = agent_service_parts
    business = _business()

    # Pre-seed durable storage with an existing conversation + messages,
    # simulating a resumed conversation whose Redis window expired.
    existing = Conversation(
        id=uuid.uuid4(), business_id=business.id, external_user_ref="returning-user"
    )
    conversations.conversations[existing.id] = existing
    conversations.messages.append(
        Message(
            id=uuid.uuid4(),
            conversation_id=existing.id,
            role=MessageRole.USER,
            content="earlier question",
        )
    )
    conversations.messages.append(
        Message(
            id=uuid.uuid4(),
            conversation_id=existing.id,
            role=MessageRole.ASSISTANT,
            content="earlier answer",
        )
    )

    await service.handle_message(business, "returning-user", "follow up question")

    # get_history returned nothing (empty FakeMemory), so the service
    # should have fallen back to DB history and reseeded the cache.
    assert str(existing.id) in memory.seeded
    assert memory.seeded[str(existing.id)] == [
        {"role": "user", "content": "earlier question"},
        {"role": "assistant", "content": "earlier answer"},
    ]
