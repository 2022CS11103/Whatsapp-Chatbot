"""Business CRUD business logic.

Ownership enforcement happens at two layers, deliberately redundant:
1. Here in the service — every read/update/delete checks the caller
   either owns the business or is an admin, before touching it.
2. Postgres RLS (migration 0002) — even if a bug let a query through
   this service without an ownership check, RLS blocks the row at the
   database level, scoped by app.current_business_id /
   app.current_user_id session variables set per-request.
"""

from uuid import UUID

from app.models.business import Business, BusinessStatus
from app.models.business_settings import DEFAULT_BUSINESS_HOURS, BusinessSettings, LLMProviderChoice
from app.models.user import User, UserRole
from app.repositories.business_repository import BusinessRepository
from app.repositories.business_settings_repository import BusinessSettingsRepository
from app.schemas.business_schema import (
    BusinessCreateRequest,
    BusinessSettingsUpdateRequest,
    BusinessUpdateRequest,
)
from app.utils.exceptions import NotFoundError, PermissionDeniedError


class BusinessService:
    def __init__(
        self,
        business_repository: BusinessRepository,
        settings_repository: BusinessSettingsRepository,
    ) -> None:
        self._businesses = business_repository
        self._settings = settings_repository

    async def create(self, owner: User, payload: BusinessCreateRequest) -> Business:
        business = Business(
            owner_id=owner.id,
            name=payload.name,
            industry_type=payload.industry_type,
            whatsapp_number=payload.whatsapp_number,
            status=BusinessStatus.TRIAL,
        )
        await self._businesses.add(business)
        await self._businesses.commit()

        # Every business gets a settings row with sane defaults at creation
        # time, so /businesses/{id}/settings never 404s for a valid business.
        # Defaults are set explicitly here rather than relied on as
        # column-level ORM defaults, which only populate after a flush
        # round-trip -- explicit construction keeps the object correct
        # immediately, regardless of flush timing.
        settings = BusinessSettings(
            business_id=business.id,
            default_language="en",
            llm_provider=LLMProviderChoice.OPENAI,
            business_hours=dict(DEFAULT_BUSINESS_HOURS),
            handoff_enabled=True,
        )
        await self._settings.add(settings)
        await self._settings.commit()

        return business

    async def list_for_user(
        self, user: User, offset: int, limit: int
    ) -> tuple[list[Business], int]:
        if user.role == UserRole.ADMIN:
            return await self._businesses.list_all(offset, limit)
        return await self._businesses.list_for_owner(user.id, offset, limit)

    async def get(self, user: User, business_id: UUID) -> Business:
        business = await self._businesses.get_by_id(business_id)
        if business is None:
            raise NotFoundError("Business not found")
        self._assert_can_access(user, business)
        return business

    async def update(
        self, user: User, business_id: UUID, payload: BusinessUpdateRequest
    ) -> Business:
        business = await self.get(user, business_id)

        update_data = payload.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(business, field, value)

        await self._businesses.commit()
        return business

    async def delete(self, user: User, business_id: UUID) -> None:
        business = await self.get(user, business_id)
        await self._businesses.delete(business)
        await self._businesses.commit()

    async def get_settings(self, user: User, business_id: UUID) -> BusinessSettings:
        await self.get(user, business_id)  # ownership check
        settings = await self._settings.get_by_business_id(business_id)
        if settings is None:
            raise NotFoundError("Business settings not found")
        return settings

    async def update_settings(
        self, user: User, business_id: UUID, payload: BusinessSettingsUpdateRequest
    ) -> BusinessSettings:
        settings = await self.get_settings(user, business_id)

        update_data = payload.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(settings, field, value)

        await self._settings.commit()
        return settings

    @staticmethod
    def _assert_can_access(user: User, business: Business) -> None:
        if user.role != UserRole.ADMIN and business.owner_id != user.id:
            raise PermissionDeniedError("You do not have access to this business")
