"""Schemas shared across multiple domains."""

from typing import Generic, TypeVar

from pydantic import BaseModel

ItemT = TypeVar("ItemT")


class ErrorResponse(BaseModel):
    error_code: str
    message: str


class MessageResponse(BaseModel):
    message: str


class PaginatedResponse(BaseModel, Generic[ItemT]):
    items: list[ItemT]
    total: int
    page: int
    page_size: int
