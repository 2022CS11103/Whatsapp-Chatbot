"""Conversation/Message persistence queries.

Two models, one repository: a conversation is never read or written
without its messages being relevant to the same request, so splitting
this into ConversationRepository + MessageRepository would just mean
every caller injects both. See app/repositories/base_repository.py
for the generic CRUD this builds on.
"""

import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.conversation import Conversation, ConversationChannel, Message
from app.repositories.base_repository import BaseRepository


class ConversationRepository(BaseRepository[Conversation]):
    model = Conversation

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session)

    async def get_open_for_user(
        self, business_id: uuid.UUID, external_user_ref: str
    ) -> Conversation | None:
        result = await self._session.execute(
            select(Conversation).where(
                Conversation.business_id == business_id,
                Conversation.external_user_ref == external_user_ref,
                Conversation.status != "closed",
            )
        )
        return result.scalars().first()

    async def create(
        self,
        business_id: uuid.UUID,
        external_user_ref: str,
        channel: ConversationChannel = ConversationChannel.WEB,
    ) -> Conversation:
        conversation = Conversation(
            business_id=business_id,
            external_user_ref=external_user_ref,
            channel=channel,
        )
        return await self.add(conversation)

    async def get_or_create(
        self,
        business_id: uuid.UUID,
        external_user_ref: str,
        channel: ConversationChannel = ConversationChannel.WEB,
    ) -> Conversation:
        existing = await self.get_open_for_user(business_id, external_user_ref)
        if existing is not None:
            return existing
        conversation = await self.create(business_id, external_user_ref, channel)
        await self.commit()
        return conversation

    async def get_recent_messages(self, conversation_id: uuid.UUID, limit: int) -> list[Message]:
        """Most recent `limit` messages, oldest-first (ready to hand
        straight to an LLM as conversation history)."""
        result = await self._session.execute(
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(Message.created_at.desc())
            .limit(limit)
        )
        messages = list(result.scalars().all())
        messages.reverse()
        return messages

    async def add_message(self, message: Message) -> Message:
        self._session.add(message)
        await self._session.flush()
        return message

    async def get_with_messages(self, conversation_id: uuid.UUID) -> Conversation | None:
        result = await self._session.execute(
            select(Conversation)
            .where(Conversation.id == conversation_id)
            .options(selectinload(Conversation.messages))
        )
        return result.scalar_one_or_none()
