"""Unit tests for ShortTermMemory -- uses fakeredis, no real Redis server."""

import pytest
from fakeredis import aioredis as fake_aioredis

from app.memory.short_term_memory import ShortTermMemory


@pytest.fixture
def redis_client():
    return fake_aioredis.FakeRedis(decode_responses=True)


@pytest.fixture
def memory(redis_client) -> ShortTermMemory:
    return ShortTermMemory(redis_client, max_turns=4, ttl_seconds=3600)


@pytest.mark.asyncio
async def test_append_and_get_history_round_trips(memory: ShortTermMemory) -> None:
    conversation_id = "conv-1"
    await memory.append_turn(conversation_id, "user", "Hi there")
    await memory.append_turn(conversation_id, "assistant", "Hello! How can I help?")

    history = await memory.get_history(conversation_id)

    assert history == [
        {"role": "user", "content": "Hi there"},
        {"role": "assistant", "content": "Hello! How can I help?"},
    ]


@pytest.mark.asyncio
async def test_window_is_capped_at_max_turns(memory: ShortTermMemory) -> None:
    conversation_id = "conv-2"
    for i in range(6):
        await memory.append_turn(conversation_id, "user", f"message {i}")

    history = await memory.get_history(conversation_id)

    assert len(history) == 4
    assert [turn["content"] for turn in history] == [
        "message 2",
        "message 3",
        "message 4",
        "message 5",
    ]


@pytest.mark.asyncio
async def test_get_history_for_unknown_conversation_is_empty(memory: ShortTermMemory) -> None:
    assert await memory.get_history("does-not-exist") == []


@pytest.mark.asyncio
async def test_seed_populates_window_from_durable_storage(memory: ShortTermMemory) -> None:
    conversation_id = "conv-3"
    await memory.seed(
        conversation_id,
        [
            {"role": "user", "content": "old message 1"},
            {"role": "assistant", "content": "old reply 1"},
        ],
    )

    history = await memory.get_history(conversation_id)

    assert history == [
        {"role": "user", "content": "old message 1"},
        {"role": "assistant", "content": "old reply 1"},
    ]


@pytest.mark.asyncio
async def test_seed_trims_to_max_turns(memory: ShortTermMemory) -> None:
    conversation_id = "conv-4"
    turns = [{"role": "user", "content": f"msg {i}"} for i in range(10)]

    await memory.seed(conversation_id, turns)

    history = await memory.get_history(conversation_id)
    assert len(history) == 4
    assert history[0]["content"] == "msg 6"


@pytest.mark.asyncio
async def test_clear_removes_the_window(memory: ShortTermMemory) -> None:
    conversation_id = "conv-5"
    await memory.append_turn(conversation_id, "user", "hi")

    await memory.clear(conversation_id)

    assert await memory.get_history(conversation_id) == []
