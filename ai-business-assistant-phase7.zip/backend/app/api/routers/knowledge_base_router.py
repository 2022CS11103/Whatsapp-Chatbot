"""Document upload endpoints, nested under a specific business.

Upload accepts multipart/form-data, saves the file, and schedules
parsing as a background task -- the response returns immediately with
status=pending. Poll GET /{document_id} (or /status) to see it
transition to processing -> completed/failed.
"""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, File, UploadFile, status

from app.api.deps import OwnedBusinessDep, get_knowledge_base_service
from app.config.settings import get_settings
from app.jobs.ingestion_jobs import process_document
from app.models.document import Document
from app.rag.document_parsers.parser_factory import SUPPORTED_CONTENT_TYPES
from app.schemas.common_schema import PaginatedResponse
from app.schemas.knowledge_base_schema import DocumentResponse
from app.services.knowledge_base_service import KnowledgeBaseService
from app.utils.exceptions import ValidationFailedError
from app.utils.pagination import PaginationParams, pagination_params

router = APIRouter(prefix="/businesses/{business_id}/documents", tags=["knowledge-base"])

KnowledgeBaseServiceDep = Annotated[KnowledgeBaseService, Depends(get_knowledge_base_service)]
PaginationDep = Annotated[PaginationParams, Depends(pagination_params)]


@router.post("", response_model=DocumentResponse, status_code=status.HTTP_202_ACCEPTED)
async def upload_document(
    business_id: UUID,
    owned_business: OwnedBusinessDep,
    kb_service: KnowledgeBaseServiceDep,
    background_tasks: BackgroundTasks,
    file: Annotated[UploadFile, File()],
) -> Document:
    if file.content_type not in SUPPORTED_CONTENT_TYPES:
        raise ValidationFailedError(
            f"Unsupported file type {file.content_type!r}. "
            f"Supported types: {sorted(SUPPORTED_CONTENT_TYPES)}"
        )

    settings = get_settings()
    content = await file.read()
    if len(content) > settings.MAX_UPLOAD_SIZE_BYTES:
        raise ValidationFailedError(
            f"File exceeds maximum upload size of {settings.MAX_UPLOAD_SIZE_BYTES} bytes"
        )

    document = await kb_service.upload(
        owned_business.id, file.filename or "unnamed_file", file.content_type, content
    )

    background_tasks.add_task(process_document, document.id, owned_business.id)

    return document


@router.get("", response_model=PaginatedResponse[DocumentResponse])
async def list_documents(
    business_id: UUID,
    owned_business: OwnedBusinessDep,
    kb_service: KnowledgeBaseServiceDep,
    pagination: PaginationDep,
) -> PaginatedResponse[DocumentResponse]:
    items, total = await kb_service.list_for_business(
        owned_business.id, pagination.offset, pagination.page_size
    )
    return PaginatedResponse(
        items=[DocumentResponse.model_validate(item) for item in items],
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
    )


@router.get("/{document_id}", response_model=DocumentResponse)
async def get_document(
    business_id: UUID,
    document_id: UUID,
    owned_business: OwnedBusinessDep,
    kb_service: KnowledgeBaseServiceDep,
) -> Document:
    return await kb_service.get(owned_business.id, document_id)


@router.get("/{document_id}/status", response_model=DocumentResponse)
async def get_document_status(
    business_id: UUID,
    document_id: UUID,
    owned_business: OwnedBusinessDep,
    kb_service: KnowledgeBaseServiceDep,
) -> Document:
    """Lightweight alias for polling ingestion progress."""
    return await kb_service.get(owned_business.id, document_id)


@router.delete("/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_document(
    business_id: UUID,
    document_id: UUID,
    owned_business: OwnedBusinessDep,
    kb_service: KnowledgeBaseServiceDep,
) -> None:
    await kb_service.delete(owned_business.id, document_id)
