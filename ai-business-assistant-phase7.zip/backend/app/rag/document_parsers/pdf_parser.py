"""Parser for .pdf files, using pypdf (pure-Python, no system deps)."""

import io

from pypdf import PdfReader
from pypdf.errors import PdfReadError

from app.rag.document_parsers.base_parser import DocumentParser


class PDFParser(DocumentParser):
    def extract_text(self, file_bytes: bytes) -> str:
        try:
            reader = PdfReader(io.BytesIO(file_bytes))
        except PdfReadError as exc:
            raise ValueError("File is not a valid PDF") from exc

        pages_text = [page.extract_text() or "" for page in reader.pages]
        text = "\n\n".join(pages_text).strip()
        if not text:
            raise ValueError(
                "No extractable text found in PDF (it may be a scanned image without OCR)"
            )
        return text
