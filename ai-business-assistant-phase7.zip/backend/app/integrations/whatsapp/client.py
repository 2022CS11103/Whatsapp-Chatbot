"""Thin client over the Meta WhatsApp Cloud API's send-message
endpoint. Deliberately minimal (text messages only, one method) to
match Phase 7's scope -- template messages, media, interactive
buttons, etc. are all real Cloud API features but out of scope until a
later phase actually needs them.
"""

import logging

import httpx

logger = logging.getLogger(__name__)


class WhatsAppClient:
    def __init__(self, access_token: str, api_version: str) -> None:
        self._access_token = access_token
        self._api_version = api_version

    async def send_text_message(self, phone_number_id: str, to: str, body: str) -> None:
        """Sends a plain-text WhatsApp message. `phone_number_id` is
        Meta's internal ID for the business's WhatsApp number (from
        the inbound webhook's metadata, not the human-readable phone
        number) and `to` is the recipient's number in international
        format without a leading '+', exactly as Meta sends it back to
        us in the inbound message's `from` field.

        Errors are logged and swallowed rather than raised: this is
        called from a background task after the webhook has already
        returned 200 to Meta, so there's no request left to fail --
        the best we can do on a send failure is log it for debugging.
        """
        url = f"https://graph.facebook.com/{self._api_version}/{phone_number_id}/messages"
        headers = {"Authorization": f"Bearer {self._access_token}"}
        payload = {
            "messaging_product": "whatsapp",
            "to": to,
            "type": "text",
            "text": {"body": body},
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(url, json=payload, headers=headers)
                response.raise_for_status()
        except httpx.HTTPError:
            logger.exception(
                "WhatsAppClient: failed to send message via phone_number_id=%s to=%s",
                phone_number_id,
                to,
            )
