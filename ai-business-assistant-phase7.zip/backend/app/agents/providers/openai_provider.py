"""OpenAI chat provider (gpt-4o-mini by default)."""

import openai

from app.agents.providers.base_provider import ChatTurn, LLMProvider


class OpenAIChatProvider(LLMProvider):
    def __init__(self, api_key: str, model: str) -> None:
        self._client = openai.AsyncOpenAI(api_key=api_key)
        self._model = model

    async def complete(
        self, system_prompt: str, history: list[ChatTurn], max_tokens: int = 1024
    ) -> str:
        messages = [{"role": "system", "content": system_prompt}] + [
            {"role": turn["role"], "content": turn["content"]} for turn in history
        ]
        response = await self._client.chat.completions.create(
            model=self._model,
            messages=messages,  # type: ignore[arg-type]
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content or ""
