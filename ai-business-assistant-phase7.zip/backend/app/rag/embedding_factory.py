"""Factory that returns the configured EmbeddingProvider implementation."""

from app.config.settings import Settings
from app.rag.embedding_provider import EmbeddingProvider


def get_embedding_provider(settings: Settings) -> EmbeddingProvider:
    provider = settings.EMBEDDING_PROVIDER.lower()

    if provider == "openai":
        from app.rag.openai_embedding import OpenAIEmbeddingProvider

        if not settings.OPENAI_API_KEY:
            raise RuntimeError("OPENAI_API_KEY is required when EMBEDDING_PROVIDER=openai")
        return OpenAIEmbeddingProvider(
            api_key=settings.OPENAI_API_KEY,
            model=settings.EMBEDDING_MODEL_OPENAI,
            dimension=settings.EMBEDDING_DIMENSION,
        )

    if provider == "gemini":
        from app.rag.gemini_embedding import GeminiEmbeddingProvider

        if not settings.GEMINI_API_KEY:
            raise RuntimeError("GEMINI_API_KEY is required when EMBEDDING_PROVIDER=gemini")
        return GeminiEmbeddingProvider(
            api_key=settings.GEMINI_API_KEY,
            model=settings.EMBEDDING_MODEL_GEMINI,
        )

    raise ValueError(f"Unknown EMBEDDING_PROVIDER {provider!r}. Supported: openai, gemini")
