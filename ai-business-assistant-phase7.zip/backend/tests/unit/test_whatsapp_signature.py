"""Unit tests for X-Hub-Signature-256 verification."""

import hashlib
import hmac

from app.integrations.whatsapp.signature import verify_signature

SECRET = "my-app-secret"
BODY = b'{"entry": []}'


def _signature_for(body: bytes, secret: str) -> str:
    digest = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


def test_valid_signature_passes() -> None:
    header = _signature_for(BODY, SECRET)
    assert verify_signature(BODY, header, SECRET) is True


def test_wrong_digest_fails() -> None:
    assert verify_signature(BODY, "sha256=" + "0" * 64, SECRET) is False


def test_missing_header_fails() -> None:
    assert verify_signature(BODY, None, SECRET) is False


def test_malformed_header_without_prefix_fails() -> None:
    assert verify_signature(BODY, "not-a-valid-header", SECRET) is False


def test_tampered_body_fails() -> None:
    header = _signature_for(BODY, SECRET)
    assert verify_signature(b"a different body entirely", header, SECRET) is False


def test_wrong_secret_fails() -> None:
    header = _signature_for(BODY, SECRET)
    assert verify_signature(BODY, header, "a-different-secret") is False
