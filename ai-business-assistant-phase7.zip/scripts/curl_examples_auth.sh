#!/usr/bin/env bash
# Smoke-test / documentation script for the Authentication API (Phase 1).
# Usage: ./scripts/curl_examples_auth.sh [base_url]
set -euo pipefail

BASE_URL="${1:-http://localhost:8000}/api/v1"
EMAIL="demo-$(date +%s)@example.com"
PASSWORD="securepass123"

echo "==> Register"
curl -s -X POST "$BASE_URL/auth/register" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\",\"full_name\":\"Demo User\"}" | tee /tmp/register.json
echo -e "\n"

echo "==> Login"
curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}" | tee /tmp/login.json
echo -e "\n"

ACCESS_TOKEN=$(python3 -c "import json; print(json.load(open('/tmp/login.json'))['access_token'])")
REFRESH_TOKEN=$(python3 -c "import json; print(json.load(open('/tmp/login.json'))['refresh_token'])")

echo "==> Get current user (/auth/me)"
curl -s "$BASE_URL/auth/me" -H "Authorization: Bearer $ACCESS_TOKEN"
echo -e "\n"

echo "==> Refresh token"
curl -s -X POST "$BASE_URL/auth/refresh" \
  -H "Content-Type: application/json" \
  -d "{\"refresh_token\":\"$REFRESH_TOKEN\"}"
echo -e "\n"

echo "==> Expect 401 without a token"
curl -s -o /dev/null -w "HTTP %{http_code}\n" "$BASE_URL/auth/me"

echo "==> Expect 409 on duplicate registration"
curl -s -X POST "$BASE_URL/auth/register" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"anything12\"}"
echo ""
