"""Per-business configuration: language, AI provider choice, hours."""

import enum
import uuid
from typing import TYPE_CHECKING, Any

from sqlalchemy import JSON, Boolean, Enum, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base_class import Base
from app.models.mixins import TimestampMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.models.business import Business


class LLMProviderChoice(str, enum.Enum):
    OPENAI = "openai"
    GEMINI = "gemini"
    CLAUDE = "claude"


DEFAULT_BUSINESS_HOURS = {
    "monday": {"open": "09:00", "close": "18:00"},
    "tuesday": {"open": "09:00", "close": "18:00"},
    "wednesday": {"open": "09:00", "close": "18:00"},
    "thursday": {"open": "09:00", "close": "18:00"},
    "friday": {"open": "09:00", "close": "18:00"},
    "saturday": {"open": "09:00", "close": "14:00"},
    "sunday": {"closed": True},
}


class BusinessSettings(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "business_settings"

    business_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("businesses.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    default_language: Mapped[str] = mapped_column(String(10), default="en", nullable=False)
    llm_provider: Mapped[LLMProviderChoice] = mapped_column(
        Enum(LLMProviderChoice, name="llm_provider_choice", native_enum=False, length=16),
        default=LLMProviderChoice.OPENAI,
        nullable=False,
    )
    business_hours: Mapped[dict[str, Any]] = mapped_column(
        JSON, default=lambda: DEFAULT_BUSINESS_HOURS, nullable=False
    )
    handoff_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    business: Mapped["Business"] = relationship(back_populates="settings")

    def __repr__(self) -> str:
        return f"<BusinessSettings business_id={self.business_id}>"
