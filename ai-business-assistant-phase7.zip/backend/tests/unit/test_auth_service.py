"""Unit tests for AuthService.

Uses a fake UserRepository (in-memory) so these tests run with no
database, no network, no fixtures beyond what conftest provides. This
is what lets the service layer be tested in milliseconds.
"""

import pytest

from app.auth.jwt_handler import JWTHandler, TokenType
from app.auth.password_hasher import PasswordHasher
from app.models.user import User
from app.schemas.auth_schema import RegisterRequest
from app.services.auth_service import AuthService
from app.utils.exceptions import (
    DuplicateResourceError,
    InactiveUserError,
    InvalidCredentialsError,
)


class FakeUserRepository:
    """In-memory stand-in for UserRepository, satisfying the same interface."""

    def __init__(self) -> None:
        self._users: dict[str, User] = {}
        self._by_id: dict = {}

    async def get_by_email(self, email: str) -> User | None:
        return self._users.get(email)

    async def get_by_id(self, entity_id):
        return self._by_id.get(entity_id)

    async def add(self, entity: User) -> User:
        import uuid

        entity.id = uuid.uuid4()
        entity.is_active = True
        self._users[entity.email] = entity
        self._by_id[entity.id] = entity
        return entity

    async def commit(self) -> None:
        pass


@pytest.fixture
def auth_service(jwt_handler: JWTHandler, password_hasher: PasswordHasher) -> AuthService:
    return AuthService(FakeUserRepository(), password_hasher, jwt_handler)


@pytest.mark.asyncio
async def test_register_creates_user(auth_service: AuthService) -> None:
    user = await auth_service.register(
        RegisterRequest(email="ananya@example.com", password="securepass123")
    )
    assert user.email == "ananya@example.com"
    assert user.hashed_password != "securepass123"


@pytest.mark.asyncio
async def test_register_duplicate_email_raises(auth_service: AuthService) -> None:
    payload = RegisterRequest(email="dup@example.com", password="securepass123")
    await auth_service.register(payload)

    with pytest.raises(DuplicateResourceError):
        await auth_service.register(payload)


@pytest.mark.asyncio
async def test_authenticate_with_correct_password_returns_tokens(
    auth_service: AuthService, jwt_handler: JWTHandler
) -> None:
    await auth_service.register(RegisterRequest(email="login@example.com", password="correctpass1"))

    tokens = await auth_service.authenticate("login@example.com", "correctpass1")

    assert tokens.access_token
    assert tokens.refresh_token
    # Decoding should not raise -- proves the token is well-formed
    jwt_handler.decode(tokens.access_token, expected_type=TokenType.ACCESS)


@pytest.mark.asyncio
async def test_authenticate_with_wrong_password_raises(auth_service: AuthService) -> None:
    await auth_service.register(
        RegisterRequest(email="wrongpass@example.com", password="correctpass1")
    )

    with pytest.raises(InvalidCredentialsError):
        await auth_service.authenticate("wrongpass@example.com", "wrongpassword")


@pytest.mark.asyncio
async def test_authenticate_inactive_user_raises(auth_service: AuthService) -> None:
    user = await auth_service.register(
        RegisterRequest(email="inactive@example.com", password="correctpass1")
    )
    user.is_active = False

    with pytest.raises(InactiveUserError):
        await auth_service.authenticate("inactive@example.com", "correctpass1")


@pytest.mark.asyncio
async def test_refresh_issues_new_token_pair(auth_service: AuthService) -> None:
    await auth_service.register(
        RegisterRequest(email="refresh@example.com", password="correctpass1")
    )
    tokens = await auth_service.authenticate("refresh@example.com", "correctpass1")

    new_tokens = await auth_service.refresh(tokens.refresh_token)

    assert new_tokens.access_token != tokens.access_token


@pytest.mark.asyncio
async def test_refresh_with_access_token_raises(auth_service: AuthService) -> None:
    await auth_service.register(
        RegisterRequest(email="badrefresh@example.com", password="correctpass1")
    )
    tokens = await auth_service.authenticate("badrefresh@example.com", "correctpass1")

    from app.utils.exceptions import TokenError

    with pytest.raises(TokenError):
        await auth_service.refresh(tokens.access_token)
