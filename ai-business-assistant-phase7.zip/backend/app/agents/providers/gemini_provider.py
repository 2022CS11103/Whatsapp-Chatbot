"""Gemini chat provider (gemini-1.5-flash by default)."""

import google.generativeai as genai

from app.agents.providers.base_provider import ChatTurn, LLMProvider

_ROLE_MAP = {"user": "user", "assistant": "model"}


class GeminiChatProvider(LLMProvider):
    def __init__(self, api_key: str, model: str) -> None:
        genai.configure(api_key=api_key)
        self._model_name = model

    async def complete(
        self, system_prompt: str, history: list[ChatTurn], max_tokens: int = 1024
    ) -> str:
        model = genai.GenerativeModel(
            model_name=self._model_name,
            system_instruction=system_prompt,
        )
        # Gemini's turn-taking requires history to end on a "user"
        # turn (the current message) with no trailing "model" turn --
        # true by construction since graph nodes always call this with
        # history ending in the latest user message.
        contents = [
            {"role": _ROLE_MAP[turn["role"]], "parts": [turn["content"]]} for turn in history
        ]
        response = await model.generate_content_async(
            contents,
            generation_config=genai.GenerationConfig(max_output_tokens=max_tokens),
        )
        return response.text or ""
