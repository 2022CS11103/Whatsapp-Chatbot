"""Pydantic v2 schemas for the Business and BusinessSettings APIs."""

from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from app.models.business import BusinessStatus, IndustryType
from app.models.business_settings import LLMProviderChoice


class BusinessCreateRequest(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    industry_type: IndustryType
    whatsapp_number: str | None = Field(default=None, max_length=32)


class BusinessUpdateRequest(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    industry_type: IndustryType | None = None
    whatsapp_number: str | None = Field(default=None, max_length=32)
    status: BusinessStatus | None = None


class BusinessResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    owner_id: UUID
    name: str
    industry_type: IndustryType
    whatsapp_number: str | None
    status: BusinessStatus


class BusinessSettingsUpdateRequest(BaseModel):
    default_language: str | None = Field(default=None, max_length=10)
    llm_provider: LLMProviderChoice | None = None
    business_hours: dict[str, Any] | None = None
    handoff_enabled: bool | None = None


class BusinessSettingsResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    business_id: UUID
    default_language: str
    llm_provider: LLMProviderChoice
    business_hours: dict[str, Any]
    handoff_enabled: bool
