"""Shared dependency providers.

This is the only place concrete implementations are wired together.
Routers depend on these functions, never on concrete classes directly
— swapping an implementation (e.g. a different JWT library) touches
only this file.
"""

from collections.abc import Callable
from typing import Annotated
from uuid import UUID

from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer
from redis.asyncio import Redis
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.providers.base_provider import LLMProvider
from app.agents.providers.provider_factory import get_llm_provider
from app.auth.jwt_handler import JWTHandler
from app.auth.password_hasher import PasswordHasher
from app.config.settings import Settings, get_settings
from app.database.session import get_db
from app.memory.short_term_memory import ShortTermMemory
from app.models.business import Business
from app.models.business_settings import LLMProviderChoice
from app.models.user import User, UserRole
from app.rag.qdrant_store import QdrantVectorStore
from app.rag.retriever import Retriever
from app.repositories.business_repository import BusinessRepository
from app.repositories.business_settings_repository import BusinessSettingsRepository
from app.repositories.conversation_repository import ConversationRepository
from app.repositories.document_repository import DocumentRepository
from app.repositories.faq_repository import FAQRepository
from app.repositories.user_repository import UserRepository
from app.services.agent_service import AgentService
from app.services.auth_service import AuthService
from app.services.business_service import BusinessService
from app.services.faq_service import FAQService
from app.services.knowledge_base_service import KnowledgeBaseService
from app.services.storage_service import LocalStorageService, StorageService
from app.utils.exceptions import PermissionDeniedError

_oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=True)

SettingsDep = Annotated[Settings, Depends(get_settings)]
DbSessionDep = Annotated[AsyncSession, Depends(get_db)]


def get_jwt_handler(settings: SettingsDep) -> JWTHandler:
    return JWTHandler(settings)


def get_password_hasher() -> PasswordHasher:
    return PasswordHasher()


def get_user_repository(session: DbSessionDep) -> UserRepository:
    return UserRepository(session)


def get_auth_service(
    user_repository: Annotated[UserRepository, Depends(get_user_repository)],
    password_hasher: Annotated[PasswordHasher, Depends(get_password_hasher)],
    jwt_handler: Annotated[JWTHandler, Depends(get_jwt_handler)],
) -> AuthService:
    return AuthService(user_repository, password_hasher, jwt_handler)


async def get_current_user(
    token: Annotated[str, Depends(_oauth2_scheme)],
    auth_service: Annotated[AuthService, Depends(get_auth_service)],
) -> User:
    return await auth_service.get_current_user(token)


CurrentUserDep = Annotated[User, Depends(get_current_user)]


def require_role(*allowed_roles: UserRole) -> Callable[[User], User]:
    """Factory for a dependency that restricts a route to given roles."""

    def _check(user: CurrentUserDep) -> User:
        if user.role not in allowed_roles:
            raise PermissionDeniedError(
                f"Requires one of roles: {[r.value for r in allowed_roles]}"
            )
        return user

    return _check


async def apply_tenant_context(
    session: DbSessionDep,
    current_user: CurrentUserDep,
) -> None:
    """Sets Postgres session variables that RLS policies check.

    Uses set_config(), not `SET LOCAL ... = :param`. Postgres's SET
    command is parsed as DDL-like syntax that does not accept bind
    parameters ($1) -- only set_config(), a regular function call,
    supports parameterized values safely. The third argument `true`
    makes it transaction-local, equivalent to SET LOCAL.

    Must run on the SAME session instance the route's repositories use.
    FastAPI caches Depends(get_db) results per-request, so as long as
    this dependency and the repositories below both resolve through
    DbSessionDep, they share one session/connection and the config set
    here is visible to their queries within the same transaction.
    """
    await session.execute(
        text("SELECT set_config('app.current_user_id', :uid, true)"),
        {"uid": str(current_user.id)},
    )
    await session.execute(
        text("SELECT set_config('app.current_user_role', :role, true)"),
        {"role": current_user.role.value},
    )


TenantContextDep = Annotated[None, Depends(apply_tenant_context)]


def get_business_repository(session: DbSessionDep) -> BusinessRepository:
    return BusinessRepository(session)


def get_business_settings_repository(session: DbSessionDep) -> BusinessSettingsRepository:
    return BusinessSettingsRepository(session)


def get_business_service(
    _tenant_context: TenantContextDep,
    business_repository: Annotated[BusinessRepository, Depends(get_business_repository)],
    settings_repository: Annotated[
        BusinessSettingsRepository, Depends(get_business_settings_repository)
    ],
) -> BusinessService:
    return BusinessService(business_repository, settings_repository)


async def get_owned_business(
    business_id: UUID,
    current_user: CurrentUserDep,
    business_service: Annotated[BusinessService, Depends(get_business_service)],
) -> Business:
    """Resolves business_id from the path and verifies the caller owns
    it (or is an admin), raising NotFoundError/PermissionDeniedError
    otherwise. Use as a dependency on any route nested under
    /businesses/{business_id}/... before further tenant-scoped work.
    """
    return await business_service.get(current_user, business_id)


OwnedBusinessDep = Annotated[Business, Depends(get_owned_business)]


async def apply_faq_tenant_context(
    session: DbSessionDep,
    owned_business: OwnedBusinessDep,
) -> None:
    """Sets app.current_business_id for RLS on business-scoped child
    tables (faqs, and later documents/conversations/leads). Only runs
    after get_owned_business has already verified ownership -- this is
    the independent enforcement layer underneath that check, not a
    substitute for it.
    """
    await session.execute(
        text("SELECT set_config('app.current_business_id', :bid, true)"),
        {"bid": str(owned_business.id)},
    )


FAQTenantContextDep = Annotated[None, Depends(apply_faq_tenant_context)]


def get_faq_repository(session: DbSessionDep) -> FAQRepository:
    return FAQRepository(session)


def get_faq_service(
    _faq_tenant_context: FAQTenantContextDep,
    faq_repository: Annotated[FAQRepository, Depends(get_faq_repository)],
) -> FAQService:
    return FAQService(faq_repository)


def get_storage_service(settings: SettingsDep) -> StorageService:
    return LocalStorageService(settings.STORAGE_DIR)


def get_document_repository(session: DbSessionDep) -> DocumentRepository:
    return DocumentRepository(session)


def get_knowledge_base_service(
    # Reuses apply_faq_tenant_context: despite the name, it generically
    # sets app.current_business_id after verifying business ownership,
    # which is exactly what documents (and any future business-scoped
    # child resource) need too.
    _tenant_context: FAQTenantContextDep,
    document_repository: Annotated[DocumentRepository, Depends(get_document_repository)],
    storage_service: Annotated[StorageService, Depends(get_storage_service)],
) -> KnowledgeBaseService:
    return KnowledgeBaseService(document_repository, storage_service)


def get_qdrant_store(settings: SettingsDep) -> QdrantVectorStore:
    return QdrantVectorStore(settings)


def get_retriever(
    settings: SettingsDep,
    qdrant_store: Annotated[QdrantVectorStore, Depends(get_qdrant_store)],
) -> Retriever:
    from app.rag.embedding_factory import get_embedding_provider

    embedder = get_embedding_provider(settings)
    return Retriever(embedder, qdrant_store)


# --- AI Agent (Phase 6) ---


def get_redis_client(settings: SettingsDep) -> Redis:
    return Redis.from_url(str(settings.REDIS_URL), decode_responses=True)  # type: ignore[no-any-return]


def get_short_term_memory(
    settings: SettingsDep,
    redis_client: Annotated[Redis, Depends(get_redis_client)],
) -> ShortTermMemory:
    return ShortTermMemory(
        redis_client, max_turns=settings.MEMORY_MAX_TURNS, ttl_seconds=settings.MEMORY_TTL_SECONDS
    )


def get_conversation_repository(session: DbSessionDep) -> ConversationRepository:
    return ConversationRepository(session)


async def get_llm_provider_for_business(
    settings: SettingsDep,
    owned_business: OwnedBusinessDep,
    settings_repository: Annotated[
        BusinessSettingsRepository, Depends(get_business_settings_repository)
    ],
) -> LLMProvider:
    """Resolves the LLMProvider for the business's configured choice
    (BusinessSettings.llm_provider) rather than lazily loading
    `Business.settings` -- the async ORM relationship isn't safe to
    lazy-load outside the session's original await context, so this
    goes back through the repository explicitly instead.
    """
    business_settings = await settings_repository.get_by_business_id(owned_business.id)
    choice = business_settings.llm_provider if business_settings else LLMProviderChoice.OPENAI
    return get_llm_provider(settings, choice)


def get_agent_service(
    settings: SettingsDep,
    _tenant_context: FAQTenantContextDep,
    llm_provider: Annotated[LLMProvider, Depends(get_llm_provider_for_business)],
    retriever: Annotated[Retriever, Depends(get_retriever)],
    faq_repository: Annotated[FAQRepository, Depends(get_faq_repository)],
    conversation_repository: Annotated[
        ConversationRepository, Depends(get_conversation_repository)
    ],
    memory: Annotated[ShortTermMemory, Depends(get_short_term_memory)],
) -> AgentService:
    return AgentService(
        llm_provider=llm_provider,
        retriever=retriever,
        faq_repository=faq_repository,
        conversation_repository=conversation_repository,
        memory=memory,
        agent_max_output_tokens=settings.AGENT_MAX_OUTPUT_TOKENS,
        agent_rag_top_k=settings.AGENT_RAG_TOP_K,
        agent_rag_score_threshold=settings.AGENT_RAG_SCORE_THRESHOLD,
    )
