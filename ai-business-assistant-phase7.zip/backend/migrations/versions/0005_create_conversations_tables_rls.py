"""create conversations and messages tables, enable RLS

Revision ID: 0005
Revises: 0004
Create Date: 2026-07-02

RLS note: conversations is scoped the same way faqs/documents are --
business_id = app.current_business_id. messages has no business_id
column of its own (only conversation_id), so its policy uses an
EXISTS subquery against conversations, exactly like document_chunks
does against documents in 0004.

app.current_business_id is set by AgentService's caller (the chat
router, via api/deps.py:get_owned_business + apply_faq_tenant_context
for the web widget; the WhatsApp webhook in Phase 8 will resolve and
set it from the inbound number instead) -- this migration only adds
the independent DB-level enforcement layer underneath that check.
"""
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0005"
down_revision: str | None = "0004"
branch_labels: Sequence[str] | None = None
depends_on: Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "conversations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "business_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("external_user_ref", sa.Text(), nullable=False),
        sa.Column(
            "channel",
            sa.Enum("web", "whatsapp", name="conversation_channel", native_enum=False, length=16),
            nullable=False,
            server_default="web",
        ),
        sa.Column(
            "status",
            sa.Enum(
                "open",
                "handed_off",
                "closed",
                name="conversation_status",
                native_enum=False,
                length=16,
            ),
            nullable=False,
            server_default="open",
        ),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
    )
    op.create_index("ix_conversations_business_id", "conversations", ["business_id"])
    op.create_index(
        "ix_conversations_business_id_external_user_ref",
        "conversations",
        ["business_id", "external_user_ref"],
    )

    op.create_table(
        "messages",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "conversation_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("conversations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "role",
            sa.Enum("user", "assistant", "system", name="message_role", native_enum=False, length=16),
            nullable=False,
        ),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("intent", sa.Text(), nullable=True),
        sa.Column("citations", sa.JSON(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
    )
    op.create_index("ix_messages_conversation_id", "messages", ["conversation_id"])

    # --- RLS: conversations ---
    op.execute("ALTER TABLE conversations ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE conversations FORCE ROW LEVEL SECURITY")

    business_check = (
        "business_id = NULLIF(current_setting('app.current_business_id', true), '')::uuid"
    )
    op.execute(
        f"CREATE POLICY conversation_select_policy ON conversations FOR SELECT USING ({business_check})"
    )
    op.execute(
        f"CREATE POLICY conversation_insert_policy ON conversations FOR INSERT WITH CHECK ({business_check})"
    )
    op.execute(
        f"CREATE POLICY conversation_update_policy ON conversations FOR UPDATE "
        f"USING ({business_check}) WITH CHECK ({business_check})"
    )
    op.execute(
        f"CREATE POLICY conversation_delete_policy ON conversations FOR DELETE USING ({business_check})"
    )

    # --- RLS: messages (via EXISTS against conversations) ---
    op.execute("ALTER TABLE messages ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE messages FORCE ROW LEVEL SECURITY")
    exists_clause = (
        "EXISTS (SELECT 1 FROM conversations WHERE conversations.id = messages.conversation_id "
        "AND conversations.business_id = "
        "NULLIF(current_setting('app.current_business_id', true), '')::uuid)"
    )
    op.execute(
        f"CREATE POLICY message_select_policy ON messages FOR SELECT USING ({exists_clause})"
    )
    op.execute(
        f"CREATE POLICY message_insert_policy ON messages FOR INSERT WITH CHECK ({exists_clause})"
    )
    op.execute(
        f"CREATE POLICY message_update_policy ON messages "
        f"FOR UPDATE USING ({exists_clause}) WITH CHECK ({exists_clause})"
    )
    op.execute(
        f"CREATE POLICY message_delete_policy ON messages FOR DELETE USING ({exists_clause})"
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS message_delete_policy ON messages")
    op.execute("DROP POLICY IF EXISTS message_update_policy ON messages")
    op.execute("DROP POLICY IF EXISTS message_insert_policy ON messages")
    op.execute("DROP POLICY IF EXISTS message_select_policy ON messages")
    op.execute("DROP POLICY IF EXISTS conversation_delete_policy ON conversations")
    op.execute("DROP POLICY IF EXISTS conversation_update_policy ON conversations")
    op.execute("DROP POLICY IF EXISTS conversation_insert_policy ON conversations")
    op.execute("DROP POLICY IF EXISTS conversation_select_policy ON conversations")
    op.drop_index("ix_messages_conversation_id", table_name="messages")
    op.drop_table("messages")
    op.drop_index("ix_conversations_business_id_external_user_ref", table_name="conversations")
    op.drop_index("ix_conversations_business_id", table_name="conversations")
    op.drop_table("conversations")
