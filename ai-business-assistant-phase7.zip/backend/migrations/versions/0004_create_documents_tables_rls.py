"""create documents and document_chunks tables, enable RLS

Revision ID: 0004
Revises: 0003
Create Date: 2026-06-30

RLS note: documents is scoped the same way faqs is -- business_id =
app.current_business_id. document_chunks has no business_id column of
its own (it only knows its document_id), so its policy uses an EXISTS
subquery against documents. Both tables FORCE RLS, so this subquery
itself is correctly scoped: it can only ever see documents rows that
already pass the documents policy, no double-checking needed.

The background ingestion job (app/jobs/ingestion_jobs.py) sets
app.current_business_id on its own freshly-created session before
touching either table, using the business_id it was handed by the
already-authorized upload request -- it never re-derives authorization
itself.
"""
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0004"
down_revision: str | None = "0003"
branch_labels: Sequence[str] | None = None
depends_on: Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "documents",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "business_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("businesses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("filename", sa.String(length=255), nullable=False),
        sa.Column("content_type", sa.String(length=100), nullable=False),
        sa.Column("storage_path", sa.String(length=512), nullable=False),
        sa.Column(
            "status",
            sa.Enum(
                "pending",
                "processing",
                "completed",
                "failed",
                name="document_status",
                native_enum=False,
                length=16,
            ),
            nullable=False,
            server_default="pending",
        ),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
    )
    op.create_index("ix_documents_business_id", "documents", ["business_id"])

    op.create_table(
        "document_chunks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "document_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("documents.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("chunk_index", sa.Integer(), nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("qdrant_point_id", sa.String(length=64), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
    )
    op.create_index("ix_document_chunks_document_id", "document_chunks", ["document_id"])

    # --- RLS: documents ---
    op.execute("ALTER TABLE documents ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE documents FORCE ROW LEVEL SECURITY")

    business_check = (
        "business_id = NULLIF(current_setting('app.current_business_id', true), '')::uuid"
    )
    op.execute(
        f"CREATE POLICY document_select_policy ON documents FOR SELECT USING ({business_check})"
    )
    op.execute(
        f"CREATE POLICY document_insert_policy ON documents FOR INSERT WITH CHECK ({business_check})"
    )
    op.execute(
        f"CREATE POLICY document_update_policy ON documents FOR UPDATE "
        f"USING ({business_check}) WITH CHECK ({business_check})"
    )
    op.execute(
        f"CREATE POLICY document_delete_policy ON documents FOR DELETE USING ({business_check})"
    )

    # --- RLS: document_chunks (via EXISTS against documents) ---
    op.execute("ALTER TABLE document_chunks ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE document_chunks FORCE ROW LEVEL SECURITY")
    exists_clause = (
        "EXISTS (SELECT 1 FROM documents WHERE documents.id = document_chunks.document_id "
        "AND documents.business_id = "
        "NULLIF(current_setting('app.current_business_id', true), '')::uuid)"
    )
    op.execute(
        f"CREATE POLICY document_chunk_select_policy ON document_chunks "
        f"FOR SELECT USING ({exists_clause})"
    )
    op.execute(
        f"CREATE POLICY document_chunk_insert_policy ON document_chunks "
        f"FOR INSERT WITH CHECK ({exists_clause})"
    )
    op.execute(
        f"CREATE POLICY document_chunk_update_policy ON document_chunks "
        f"FOR UPDATE USING ({exists_clause}) WITH CHECK ({exists_clause})"
    )
    op.execute(
        f"CREATE POLICY document_chunk_delete_policy ON document_chunks "
        f"FOR DELETE USING ({exists_clause})"
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS document_chunk_delete_policy ON document_chunks")
    op.execute("DROP POLICY IF EXISTS document_chunk_update_policy ON document_chunks")
    op.execute("DROP POLICY IF EXISTS document_chunk_insert_policy ON document_chunks")
    op.execute("DROP POLICY IF EXISTS document_chunk_select_policy ON document_chunks")
    op.execute("DROP POLICY IF EXISTS document_delete_policy ON documents")
    op.execute("DROP POLICY IF EXISTS document_update_policy ON documents")
    op.execute("DROP POLICY IF EXISTS document_insert_policy ON documents")
    op.execute("DROP POLICY IF EXISTS document_select_policy ON documents")
    op.drop_index("ix_document_chunks_document_id", table_name="document_chunks")
    op.drop_table("document_chunks")
    op.drop_index("ix_documents_business_id", table_name="documents")
    op.drop_table("documents")
