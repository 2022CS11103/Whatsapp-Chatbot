#!/usr/bin/env bash
# Smoke-test / documentation script for the FAQ CRUD API (Phase 3).
# Usage: ./scripts/curl_examples_faq.sh [base_url]
set -euo pipefail

BASE_URL="${1:-http://localhost:8000}/api/v1"
STAMP=$(date +%s)
EMAIL_A="faqowner-$STAMP@example.com"
EMAIL_B="faqintruder-$STAMP@example.com"
PASSWORD="securepass123"

register_login_and_create_business() {
  local email="$1" name="$2"
  curl -s -X POST "$BASE_URL/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"$email\",\"password\":\"$PASSWORD\"}" > /dev/null
  local token
  token=$(curl -s -X POST "$BASE_URL/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"$email\",\"password\":\"$PASSWORD\"}" | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
  local biz_id
  biz_id=$(curl -s -X POST "$BASE_URL/businesses" \
    -H "Authorization: Bearer $token" -H "Content-Type: application/json" \
    -d "{\"name\":\"$name\",\"industry_type\":\"clinic\"}" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
  echo "$token $biz_id"
}

echo "==> Owner A: register, login, create business"
read -r TOKEN_A BIZ_A <<< "$(register_login_and_create_business "$EMAIL_A" "FAQ Test Clinic")"

echo "==> Owner B: register, login, create their own business"
read -r TOKEN_B BIZ_B <<< "$(register_login_and_create_business "$EMAIL_B" "Intruder Gym")"

echo "==> Owner A creates a single FAQ"
curl -s -X POST "$BASE_URL/businesses/$BIZ_A/faqs" \
  -H "Authorization: Bearer $TOKEN_A" -H "Content-Type: application/json" \
  -d '{"question":"What are your hours?","answer":"9am to 6pm, Mon-Sat","category":"hours"}'
echo -e "\n"

echo "==> Owner A bulk-creates FAQs"
curl -s -X POST "$BASE_URL/businesses/$BIZ_A/faqs/bulk" \
  -H "Authorization: Bearer $TOKEN_A" -H "Content-Type: application/json" \
  -d '{"faqs":[{"question":"Do you accept insurance?","answer":"Yes, most major providers"},{"question":"Is parking available?","answer":"Yes, free on-site"}]}'
echo -e "\n"

echo "==> Owner A lists all FAQs (expect 3)"
curl -s "$BASE_URL/businesses/$BIZ_A/faqs" -H "Authorization: Bearer $TOKEN_A"
echo -e "\n"

echo "==> Owner B tries to list Owner A's FAQs (expect 403)"
curl -s -w "\nHTTP %{http_code}\n" "$BASE_URL/businesses/$BIZ_A/faqs" -H "Authorization: Bearer $TOKEN_B"

echo "==> Owner B tries to create an FAQ in Owner A's business (expect 403)"
curl -s -w "\nHTTP %{http_code}\n" -X POST "$BASE_URL/businesses/$BIZ_A/faqs" \
  -H "Authorization: Bearer $TOKEN_B" -H "Content-Type: application/json" \
  -d '{"question":"Hijack attempt","answer":"should fail"}'
