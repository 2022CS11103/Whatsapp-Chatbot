"""Short-term conversation memory: a Redis-backed rolling window of
the last N turns for a conversation.

Why Redis and not the database: the agent needs conversation history
on every single turn, and hitting Postgres for it would mean an extra
round trip (plus a query) on the hot path of every chat message. The
database (Conversation/Message) remains the durable source of truth;
this is a fast, expiring cache in front of it. If a key is missing or
expired, AgentService falls back to ConversationRepository.get_recent_messages
and repopulates this window -- see app/services/agent_service.py.

Stored as a Redis list of JSON-encoded {"role": ..., "content": ...}
dicts, capped at settings.MEMORY_MAX_TURNS entries (a "turn" here is
one message, not one user+assistant pair, matching how history is fed
to the LLM). TTL refreshes on every write so an active conversation
never expires mid-session, but an abandoned one cleans itself up.
"""

import json
from typing import TypedDict

from redis.asyncio import Redis


class TurnDict(TypedDict):
    role: str
    content: str


class ShortTermMemory:
    def __init__(self, redis_client: Redis, max_turns: int, ttl_seconds: int) -> None:
        self._redis = redis_client
        self._max_turns = max_turns
        self._ttl_seconds = ttl_seconds

    def _key(self, conversation_id: str) -> str:
        return f"agent:memory:{conversation_id}"

    async def get_history(self, conversation_id: str) -> list[TurnDict]:
        raw_items = await self._redis.lrange(self._key(conversation_id), 0, -1)  # type: ignore[misc]
        return [json.loads(item) for item in raw_items]

    async def append_turn(self, conversation_id: str, role: str, content: str) -> None:
        key = self._key(conversation_id)
        turn: TurnDict = {"role": role, "content": content}
        async with self._redis.pipeline(transaction=True) as pipe:
            pipe.rpush(key, json.dumps(turn))
            pipe.ltrim(key, -self._max_turns, -1)
            pipe.expire(key, self._ttl_seconds)
            await pipe.execute()

    async def seed(self, conversation_id: str, turns: list[TurnDict]) -> None:
        """Repopulate the window from durable storage (used when a
        conversation resumes and Redis has no entry for it yet)."""
        key = self._key(conversation_id)
        trimmed = turns[-self._max_turns :]
        if not trimmed:
            return
        async with self._redis.pipeline(transaction=True) as pipe:
            pipe.delete(key)
            for turn in trimmed:
                pipe.rpush(key, json.dumps(turn))
            pipe.expire(key, self._ttl_seconds)
            await pipe.execute()

    async def clear(self, conversation_id: str) -> None:
        await self._redis.delete(self._key(conversation_id))
