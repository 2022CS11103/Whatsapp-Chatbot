"""WhatsApp webhook -- the entry point for Meta Cloud API messages.

Unlike every other router in this codebase, these two endpoints are
NOT behind JWT auth (CurrentUserDep) and do NOT go through
apply_tenant_context. Meta calls this endpoint directly, unauthenticated
by our normal user model -- it proves its identity a different way:

- GET:  a one-time handshake when you configure the webhook URL in the
        Meta App Dashboard. Meta sends a verify token we chose
        ourselves; matching it back proves we own this endpoint.
- POST: every actual message/status event. Signed with
        X-Hub-Signature-256 (HMAC using the Meta App Secret), verified
        in app/integrations/whatsapp/signature.py before we trust the
        body at all.

Business resolution and the actual agent call happen in
app/jobs/whatsapp_jobs.py, scheduled as a BackgroundTask so this
handler can return 200 to Meta immediately -- see that module's
docstring for why.
"""

import logging

from fastapi import APIRouter, BackgroundTasks, Header, HTTPException, Query, Request, status
from fastapi.responses import PlainTextResponse

from app.config.settings import Settings, get_settings
from app.integrations.whatsapp.schemas import WhatsAppWebhookPayload
from app.integrations.whatsapp.signature import verify_signature
from app.jobs.whatsapp_jobs import process_inbound_whatsapp_message

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhooks/whatsapp", tags=["whatsapp"])


@router.get("", response_class=PlainTextResponse)
async def verify_webhook(
    hub_mode: str = Query(alias="hub.mode"),
    hub_verify_token: str = Query(alias="hub.verify_token"),
    hub_challenge: str = Query(alias="hub.challenge"),
) -> str:
    settings = get_settings()

    if hub_mode != "subscribe" or hub_verify_token != (settings.WHATSAPP_VERIFY_TOKEN or ""):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Verification failed")

    # Meta requires the raw challenge string back, NOT JSON -- hence
    # PlainTextResponse on this route instead of the usual response_model.
    return hub_challenge


@router.post("", status_code=status.HTTP_200_OK)
async def receive_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_hub_signature_256: str | None = Header(default=None),
) -> dict[str, str]:
    settings: Settings = get_settings()
    raw_body = await request.body()

    if settings.WHATSAPP_APP_SECRET and not verify_signature(
        raw_body, x_hub_signature_256, settings.WHATSAPP_APP_SECRET
    ):
        logger.warning("receive_webhook: signature verification failed, rejecting payload")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid signature")

    payload = WhatsAppWebhookPayload.model_validate_json(raw_body)

    for metadata, message in payload.iter_text_messages():
        if message.type != "text" or message.text is None:
            logger.info(
                "receive_webhook: skipping unsupported message type=%s from=%s",
                message.type,
                message.from_,
            )
            continue

        background_tasks.add_task(
            process_inbound_whatsapp_message,
            phone_number_id=metadata.phone_number_id,
            display_phone_number=metadata.display_phone_number,
            from_number=message.from_,
            message_text=message.text.body,
        )

    # Always 200, even for payloads with nothing to process (status
    # updates, unsupported types) -- Meta retries and eventually
    # disables the webhook subscription if it sees repeated non-200s,
    # so "nothing to do" must look the same as "handled successfully".
    return {"status": "received"}
