"""Claude chat provider (claude-sonnet-4-6 by default)."""

import anthropic

from app.agents.providers.base_provider import ChatTurn, LLMProvider


class ClaudeChatProvider(LLMProvider):
    def __init__(self, api_key: str, model: str) -> None:
        self._client = anthropic.AsyncAnthropic(api_key=api_key)
        self._model = model

    async def complete(
        self, system_prompt: str, history: list[ChatTurn], max_tokens: int = 1024
    ) -> str:
        messages = [{"role": turn["role"], "content": turn["content"]} for turn in history]
        response = await self._client.messages.create(
            model=self._model,
            system=system_prompt,
            messages=messages,  # type: ignore[arg-type]
            max_tokens=max_tokens,
        )
        text_blocks = [block.text for block in response.content if block.type == "text"]
        return "".join(text_blocks)
