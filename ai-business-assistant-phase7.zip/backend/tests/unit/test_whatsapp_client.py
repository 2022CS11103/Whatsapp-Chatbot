"""Unit tests for WhatsAppClient -- no real network calls, httpx's
MockTransport intercepts the request.
"""

import json

import httpx
import pytest

from app.integrations.whatsapp.client import WhatsAppClient


@pytest.mark.asyncio
async def test_send_text_message_posts_expected_payload(monkeypatch) -> None:
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["headers"] = dict(request.headers)
        captured["body"] = request.content
        return httpx.Response(200, json={"messaging_product": "whatsapp"})

    real_async_client = httpx.AsyncClient

    def fake_async_client(*args, **kwargs):
        kwargs["transport"] = httpx.MockTransport(handler)
        return real_async_client(*args, **kwargs)

    monkeypatch.setattr("app.integrations.whatsapp.client.httpx.AsyncClient", fake_async_client)

    client = WhatsAppClient(access_token="test-token", api_version="v21.0")
    await client.send_text_message(phone_number_id="123456", to="15559876543", body="Hello!")

    assert captured["url"] == "https://graph.facebook.com/v21.0/123456/messages"
    assert captured["headers"]["authorization"] == "Bearer test-token"

    body = json.loads(captured["body"])
    assert body == {
        "messaging_product": "whatsapp",
        "to": "15559876543",
        "type": "text",
        "text": {"body": "Hello!"},
    }


@pytest.mark.asyncio
async def test_send_text_message_swallows_http_errors(monkeypatch, caplog) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": "invalid token"})

    real_async_client = httpx.AsyncClient

    def fake_async_client(*args, **kwargs):
        kwargs["transport"] = httpx.MockTransport(handler)
        return real_async_client(*args, **kwargs)

    monkeypatch.setattr("app.integrations.whatsapp.client.httpx.AsyncClient", fake_async_client)

    client = WhatsAppClient(access_token="bad-token", api_version="v21.0")

    # Must not raise -- see WhatsAppClient.send_text_message's docstring
    # on why send failures are logged, not propagated.
    await client.send_text_message(phone_number_id="123456", to="15559876543", body="Hello!")
