#!/usr/bin/env bash
# Smoke-test / documentation script for the Knowledge Base Upload API (Phase 4).
# Usage: ./scripts/curl_examples_knowledge_base.sh [base_url]
set -euo pipefail

BASE_URL="${1:-http://localhost:8000}/api/v1"
STAMP=$(date +%s)
EMAIL="kbowner-$STAMP@example.com"
PASSWORD="securepass123"

curl -s -X POST "$BASE_URL/auth/register" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}" > /dev/null
TOKEN=$(curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}" | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
BIZ_ID=$(curl -s -X POST "$BASE_URL/businesses" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"KB Demo Restaurant","industry_type":"restaurant"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

echo "==> Creating a sample text file"
printf 'Our restaurant serves authentic Italian cuisine.\n\nWe are open Monday through Saturday, 11am to 10pm.\n\nReservations recommended for parties of 6 or more.\n' > /tmp/kb_demo_menu.txt

echo "==> Uploading the document (returns immediately with status=pending)"
curl -s -X POST "$BASE_URL/businesses/$BIZ_ID/documents" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@/tmp/kb_demo_menu.txt;type=text/plain" | tee /tmp/kb_upload.json
echo -e "\n"
DOC_ID=$(python3 -c "import json; print(json.load(open('/tmp/kb_upload.json'))['id'])")

echo "==> Polling status until parsing completes"
for i in $(seq 1 10); do
  STATUS_RESP=$(curl -s "$BASE_URL/businesses/$BIZ_ID/documents/$DOC_ID/status" -H "Authorization: Bearer $TOKEN")
  STATUS=$(echo "$STATUS_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin)['status'])")
  echo "  status: $STATUS"
  if [ "$STATUS" = "completed" ] || [ "$STATUS" = "failed" ]; then
    echo "$STATUS_RESP"
    break
  fi
  sleep 0.5
done
echo -e "\n"

echo "==> Listing documents for this business"
curl -s "$BASE_URL/businesses/$BIZ_ID/documents" -H "Authorization: Bearer $TOKEN"
echo -e "\n"

echo "==> Deleting the document"
curl -s -o /dev/null -w "HTTP %{http_code}\n" -X DELETE "$BASE_URL/businesses/$BIZ_ID/documents/$DOC_ID" \
  -H "Authorization: Bearer $TOKEN"
