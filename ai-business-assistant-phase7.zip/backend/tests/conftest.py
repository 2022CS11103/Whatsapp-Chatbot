"""Shared pytest fixtures."""

import pytest

from app.auth.jwt_handler import JWTHandler
from app.auth.password_hasher import PasswordHasher
from app.config.settings import Settings


@pytest.fixture
def settings() -> Settings:
    return Settings(
        DATABASE_URL="postgresql+asyncpg://test:test@localhost:5432/test",
        REDIS_URL="redis://localhost:6379/0",
        JWT_SECRET_KEY="test-secret-key-at-least-32-characters-long",
    )


@pytest.fixture
def jwt_handler(settings: Settings) -> JWTHandler:
    return JWTHandler(settings)


@pytest.fixture
def password_hasher() -> PasswordHasher:
    return PasswordHasher()
