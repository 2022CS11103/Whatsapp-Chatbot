"""Integration tests for /api/v1/businesses/* against real Postgres.

These specifically exercise RLS, not just the app-level ownership
check in BusinessService -- they prove that even if the service-layer
check were buggy, the database itself would refuse to return rows
across tenants.
"""

import pytest
from httpx import ASGITransport, AsyncClient

from app.database.base_class import Base
from app.database.session import engine
from app.main import app

pytestmark = pytest.mark.integration


@pytest.fixture(autouse=True)
async def _setup_database():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


async def _register_and_login(client: AsyncClient, email: str) -> str:
    await client.post("/api/v1/auth/register", json={"email": email, "password": "supersecure123"})
    login_resp = await client.post(
        "/api/v1/auth/login", json={"email": email, "password": "supersecure123"}
    )
    token: str = login_resp.json()["access_token"]
    return token


@pytest.mark.asyncio
async def test_create_business_creates_default_settings(client: AsyncClient) -> None:
    token = await _register_and_login(client, "create-test@example.com")
    headers = {"Authorization": f"Bearer {token}"}

    create_resp = await client.post(
        "/api/v1/businesses",
        json={"name": "Tasty Bites", "industry_type": "restaurant"},
        headers=headers,
    )
    assert create_resp.status_code == 201
    business_id = create_resp.json()["id"]
    assert create_resp.json()["status"] == "trial"

    settings_resp = await client.get(f"/api/v1/businesses/{business_id}/settings", headers=headers)
    assert settings_resp.status_code == 200
    assert settings_resp.json()["default_language"] == "en"
    assert settings_resp.json()["handoff_enabled"] is True


@pytest.mark.asyncio
async def test_owner_cannot_list_another_owners_business(client: AsyncClient) -> None:
    token_a = await _register_and_login(client, "owner-a@example.com")
    token_b = await _register_and_login(client, "owner-b@example.com")

    await client.post(
        "/api/v1/businesses",
        json={"name": "A's Gym", "industry_type": "gym"},
        headers={"Authorization": f"Bearer {token_a}"},
    )

    list_resp = await client.get(
        "/api/v1/businesses", headers={"Authorization": f"Bearer {token_b}"}
    )
    assert list_resp.status_code == 200
    assert list_resp.json()["total"] == 0
    assert list_resp.json()["items"] == []


@pytest.mark.asyncio
async def test_owner_cannot_fetch_another_owners_business_by_id(client: AsyncClient) -> None:
    token_a = await _register_and_login(client, "victim@example.com")
    token_b = await _register_and_login(client, "intruder@example.com")

    create_resp = await client.post(
        "/api/v1/businesses",
        json={"name": "Victim's Salon", "industry_type": "salon"},
        headers={"Authorization": f"Bearer {token_a}"},
    )
    business_id = create_resp.json()["id"]

    get_resp = await client.get(
        f"/api/v1/businesses/{business_id}", headers={"Authorization": f"Bearer {token_b}"}
    )
    assert get_resp.status_code == 403
    assert get_resp.json()["error_code"] == "permission_denied"


@pytest.mark.asyncio
async def test_owner_can_update_and_delete_own_business(client: AsyncClient) -> None:
    token = await _register_and_login(client, "self-manage@example.com")
    headers = {"Authorization": f"Bearer {token}"}

    create_resp = await client.post(
        "/api/v1/businesses",
        json={"name": "Old Name", "industry_type": "clinic"},
        headers=headers,
    )
    business_id = create_resp.json()["id"]

    update_resp = await client.patch(
        f"/api/v1/businesses/{business_id}", json={"name": "New Name"}, headers=headers
    )
    assert update_resp.status_code == 200
    assert update_resp.json()["name"] == "New Name"

    delete_resp = await client.delete(f"/api/v1/businesses/{business_id}", headers=headers)
    assert delete_resp.status_code == 204

    get_resp = await client.get(f"/api/v1/businesses/{business_id}", headers=headers)
    assert get_resp.status_code == 404


@pytest.mark.asyncio
async def test_create_business_without_token_returns_401(client: AsyncClient) -> None:
    resp = await client.post("/api/v1/businesses", json={"name": "No Auth", "industry_type": "gym"})
    assert resp.status_code == 401
